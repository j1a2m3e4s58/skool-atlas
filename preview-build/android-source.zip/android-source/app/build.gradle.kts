import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val ownerKeys = Properties()
val ownerKeysFile = rootProject.file("key.properties")
if (ownerKeysFile.exists()) ownerKeys.load(FileInputStream(ownerKeysFile))

android {
    namespace = "com.skoolatlas.app"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.skoolatlas.app"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        resValue("string", "app_name", "Skool Atlas")
    }

    signingConfigs {
        if (ownerKeysFile.exists()) {
            create("ownerRelease") {
                keyAlias = ownerKeys.getProperty("keyAlias")
                keyPassword = ownerKeys.getProperty("keyPassword")
                storeFile = file(ownerKeys.getProperty("storeFile"))
                storePassword = ownerKeys.getProperty("storePassword")
            }
        }
    }
    buildTypes {
        debug {
            applicationIdSuffix = ".preview"
            versionNameSuffix = "-preview"
            resValue("string", "app_name", "Skool Atlas Preview")
        }
        release {
            if (ownerKeysFile.exists()) signingConfig = signingConfigs.getByName("ownerRelease")
        }
    }
}

flutter {
    source = "../.."
}

gradle.taskGraph.whenReady {
    if (allTasks.any { it.name.contains("Release") } && !ownerKeysFile.exists()) {
        throw GradleException("Configure owner release signing in android/key.properties. Release builds never use debug signing.")
    }
}
