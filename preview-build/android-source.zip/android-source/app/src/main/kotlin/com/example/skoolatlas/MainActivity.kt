package com.skoolatlas.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
