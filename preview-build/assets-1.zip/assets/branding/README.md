# Skool Atlas app artwork

`original-logo.png` is the user-supplied full logo, preserved unchanged.
`launcher-master.png` is the reviewed launcher rendition made with image generation.

Prompt: Preserve the blue graduation cap, yellow tassel, white lowercase i and open blue/gold book from the supplied logo. Remove the bottom wordmark for launcher legibility, clean stray pixels, center on an opaque white square, with no new elements or rounded corners.

Run `python tools/generate_icons.py` with Pillow to reproduce Android legacy/adaptive, iOS/iPadOS and web PNG renditions. Adaptive and maskable versions use additional safe padding; the operating system supplies the final icon shape. iOS PNGs are opaque RGB.

The native app display name is Skool Atlas. Native iOS builds require macOS/Xcode. Android builds require a JDK and Android SDK. Icons in source do not mean an APK/IPA has been built or published.
