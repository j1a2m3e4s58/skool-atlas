"""Create an app-versioned offline shell after a successful Flutter web build."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/'build/web'
core=['/index.html','/offline-status.html','/flutter_bootstrap.js','/flutter.js','/main.dart.js','/manifest.json',
 '/assets/AssetManifest.bin.json','/assets/FontManifest.json','/assets/assets/schools/catalog.json',
 '/assets/assets/schools/reconciliation.json','/assets/assets/schools/support.json',
 '/assets/assets/schools/website_content.json','/assets/assets/schools/website_sources.json',
 '/assets/assets/branding/launcher-mark.png','/icons/Icon-192.png','/icons/Icon-512.png']
core=[p for p in core if (WEB/p.lstrip('/')).exists()]
for folder in ['canvaskit','assets/fonts','assets/assets/fonts','assets/packages/cupertino_icons']:
 for p in (WEB/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.js','.wasm','.ttf','.otf') and p.stat().st_size<12000000:core.append('/'+p.relative_to(WEB).as_posix())
template=(ROOT/'web/sw.template.js').read_text(encoding='utf-8')
hasher=hashlib.sha256(template.encode('utf-8'))
for p in sorted(core):hasher.update((WEB/p.lstrip('/')).read_bytes())
version=hasher.hexdigest()[:16]
(WEB/'sw.js').write_text(template.replace("__ATLAS_VERSION__",version).replace('__ATLAS_CORE__',json.dumps(core)),encoding='utf-8')
print(f'Offline shell {version}: {len(core)} core assets. School images cache when viewed; APIs and external media never cache.')
