import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/main.dart';

void main() {
  for (final width in [320.0, 1024.0]) {
    testWidgets('action styles and unpaired action use available width $width',
        (tester) async {
      tester.view.physicalSize = Size(width, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(MaterialApp(
        theme: atlasTheme(Brightness.dark),
        home: Scaffold(body: BalancedActions(children: [
          FilledButton(onPressed: () {}, child: const Text('First')),
          OutlinedButton(onPressed: () {}, child: const Text('Second')),
          TextButton(onPressed: () {}, child: const Text('Third')),
        ])),
      ));
      await tester.pump();
      final third = find.byType(TextButton);
      expect(tester.getSize(third).width, closeTo(width, .1));
      expect(tester.getSize(third).height, greaterThanOrEqualTo(52));
      final context = tester.element(find.byType(FilledButton));
      final style = FilledButtonTheme.of(context).style!;
      expect(style.alignment, Alignment.centerLeft);
      expect(style.minimumSize!.resolve({}), const Size(0, 52));
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('panel columns collapse when large text needs more room',
      (tester) async {
    tester.view.physicalSize = const Size(1024, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    Future<void> show(double scale) => tester.pumpWidget(MaterialApp(
      home: MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(scale)),
        child: const Scaffold(body: PanelGrid(children: [
          SizedBox(key: ValueKey('a'), height: 80),
          SizedBox(key: ValueKey('b'), height: 120),
        ])),
      ),
    ));
    await show(1);
    expect(tester.getTopLeft(find.byKey(const ValueKey('a'))).dy,
        tester.getTopLeft(find.byKey(const ValueKey('b'))).dy);
    await show(1.5);
    expect(tester.getTopLeft(find.byKey(const ValueKey('b'))).dy,
        greaterThan(tester.getBottomLeft(find.byKey(const ValueKey('a'))).dy));
    expect(tester.takeException(), isNull);
  });
}
