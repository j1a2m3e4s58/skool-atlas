import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/website_content.dart';

void main() {
  test(
    'website feed rejects unsafe destinations and unapproved identities',
    () {
      for (final url in [
        'javascript:alert(1)',
        'http://school.example/',
        'https://127.0.0.1/',
        'https://192.168.1.2/',
        'https://u:p@school.example/',
        'https://school.example:8443/',
      ]) {
        expect(publicHttpsLink(url), isFalse, reason: url);
      }
      final store = WebsiteContentStore()
        ..approved = {'school': 'school.example'};
      final safePhoto = {
        'url': 'https://cdn.example/photo.jpg',
        'source': 'https://school.example/gallery',
        'title': 'Campus',
      };
      final row = {
        'website': 'https://school.example/',
        'photos': [
          safePhoto,
          {...safePhoto, 'url': 'https://127.0.0.1/secret'},
          {...safePhoto, 'source': 'https://unrelated.example/gallery'},
        ],
        'videos': [],
        'resources': [],
      };
      final data = store.validate(
        jsonEncode({
          'schema': 1,
          'generatedAt': '2026-10-16T12:00:00Z',
          'schools': {'school': row, 'unreviewed-school': row},
        }),
      );
      expect((data['schools'] as Map).keys, ['school']);
      expect(data['schools']['school']['photos'], [safePhoto]);
      expect(
        () => store.validate('{"schema":2,"schools":{}}'),
        throwsFormatException,
      );
    },
  );
}
