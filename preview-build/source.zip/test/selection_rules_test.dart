import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/planning.dart';
import 'package:skoolatlas/school.dart';

void main() {
  late List<School> original;
  setUp(() {
    original = schools;
    schools = [
      for (final category in ['Category A', 'Category B', 'Category C'])
        for (var i = 0; i < 8; i++)
          School({
            'id': '$category-$i',
            'name': '$category school $i',
            'category': category,
            'region': 'Central',
            'location': 'Cape Coast',
            'gender': 'Mixed',
            'residency': 'Day/Boarding',
            'registerYear': 2026,
            'code': '$category-$i',
            'programs': ['General Science'],
            'images': <String>[],
            'sources': <Map<String, dynamic>>[],
          }),
    ];
  });
  tearDown(() => schools = original);
  test('WAEC Arabic can count among the best two other subjects', () {
    expect(otherSubjects, contains('Arabic'));
    expect(
      resultsAggregate({
        for (final subject in coreSubjects) subject: 2,
        'Arabic': 1,
        'Computing': 3,
        'French': 8,
      }),
      12,
    );
  });
  List<SchoolChoice> generate({String style = 'Balanced categories'}) =>
      buildSuggestedChoices(
        options: schools,
        programme: 'General Science',
        region: 'Central',
        town: 'Cape Coast',
        gender: 'Male',
        style: style,
      );
  List<ChoiceCheck> check(List<SchoolChoice> draft) => validateSchoolChoices(
    draft,
    gender: 'Male',
    town: 'Cape Coast',
    region: 'Central',
    now: DateTime(2026, 10, 16),
  );
  test('balanced draft meets official category and boarding maximums', () {
    expect(
      buildSuggestedChoices(
        options: schools,
        programme: 'General Science',
        region: 'Central',
        town: 'Cape Coast',
        gender: 'Not entered',
      ),
      isEmpty,
    );
    final draft = generate();
    expect(draft.length, 8);
    expect(draft.where((c) => c.selectionCategory == 'Category A').length, 2);
    expect(draft.where((c) => c.selectionCategory == 'Category B').length, 3);
    expect(draft.where((c) => c.selectionCategory == 'Category C').length, 3);
    expect(draft.where((c) => c.residence == 'Boarding').length, 5);
    expect(draft.where((c) => c.residence == 'Day').length, 3);
    expect(draft.map((c) => c.selectionCategory).toList(), [
      'Category A',
      'Category A',
      'Category B',
      'Category B',
      'Category B',
      'Category C',
      'Category C',
      'Category C',
    ]);
    expect(draft.map((c) => c.residence).toList(), [
      'Boarding',
      'Day',
      'Boarding',
      'Boarding',
      'Day',
      'Boarding',
      'Boarding',
      'Day',
    ]);
    expect(check(draft).where((c) => c.error).map((c) => c.code).toSet(), {
      'commute',
      'catchment',
    });
  });
  test('all eight category C and all Day are valid alternatives', () {
    final draft = generate(style: 'Category C focus');
    expect(draft.length, 8);
    expect(draft.every((c) => c.selectionCategory == 'Category C'), isTrue);
    final day = generate(style: 'Day-only draft');
    expect(day.length, 8);
    expect(day.every((c) => c.residence == 'Day'), isTrue);
    for (final choice in day) {
      choice.commuteConfirmed = true;
      choice.catchmentConfirmed = true;
    }
    expect(check(day).where((c) => c.error), isEmpty);
  });
  test('no compulsory A/B quota and Day is not a separate category', () {
    final draft = generate(style: 'Category C focus');
    for (final choice in draft) {
      choice.commuteConfirmed = true;
      choice.catchmentConfirmed = true;
    }
    expect(check(draft).where((c) => c.error), isEmpty);
    draft.firstWhere((c) => c.residence == 'Day').residence = 'Boarding';
    expect(check(draft).any((c) => c.code == 'boarding'), isTrue);
  });
  test('automatic Day choices never use region alone to fill the draft', () {
    for (final school in schools) {
      school.data['location'] = 'Distant town, Central, Ghana';
      school.data['district'] = 'Distant district';
    }
    final partial = generate();
    expect(partial.where((c) => c.residence == 'Day'), isEmpty);
    expect(partial.length, 5);
    expect(check(partial).any((c) => c.code == 'count'), isTrue);
    final local = buildSuggestedChoices(
      options: schools, programme: 'General Science', region: 'Central',
      town: 'Cape Coast', district: 'Distant district', gender: 'Male',
    );
    expect(local.where((c) => c.residence == 'Day').length, 3);
  });
  test(
    'builder skips ambiguous schools and does not invent extra Day choices',
    () {
      schools[0].data['identityNeedsReview'] = true;
      schools[1].data['registerCodeConflict'] = true;
      final draft = generate();
      expect(
        draft.any((c) => [schools[0].id, schools[1].id].contains(c.schoolId)),
        isFalse,
      );
      for (final school in schools) {
        school.data['residency'] = 'Boarding';
      }
      final incomplete = generate();
      expect(incomplete.length, 5);
      expect(check(incomplete).any((c) => c.code == 'count'), isTrue);
    },
  );
}
