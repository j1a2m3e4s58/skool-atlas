import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skoolatlas/planning.dart';
import 'package:skoolatlas/school.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await loadAtlas();
    await loadPlanningData();
  });

  test('aggregate uses four core subjects and the best two other subjects', () {
    final grades = {
      for (final s in coreSubjects) s: 2,
      'Computing': 1,
      'French': 3,
      'Career Technology': 9,
    };
    expect(resultsAggregate(grades), 12);
    grades.remove('Mathematics');
    expect(() => resultsAggregate(grades), throwsArgumentError);
  });

  test('eight category C day choices are allowed, with commute checks', () {
    final candidates = schools
        .where(
          (s) =>
              s.category == 'Category C' &&
              s.data['registerYear'] == 2026 &&
              s.residency.contains('Day') &&
              s.programs.isNotEmpty,
        )
        .take(8)
        .toList();
    expect(candidates.length, 8);
    final choices = candidates
        .map(
          (s) => SchoolChoice(
            schoolId: s.id,
            programme: s.programs.first,
            residence: 'Day',
            commuteConfirmed: true,
            catchmentConfirmed: true,
            codeConfirmed: true,
          ),
        )
        .toList();
    final checks = validateSchoolChoices(
      choices,
      gender: '',
      town: 'Accra',
      region: 'Greater Accra',
      now: DateTime(2026, 10, 16),
    );
    expect(checks.where((c) => c.error).map((c) => c.code), isEmpty);
    choices.first.commuteConfirmed = false;
    expect(
      validateSchoolChoices(
        choices,
        gender: '',
        town: 'Accra',
        region: 'Greater Accra',
      ).any((c) => c.error),
      isTrue,
    );
  });

  test('a duplicate school cannot satisfy the eight-school rule', () {
    final s = schools.firstWhere((s) => s.programs.isNotEmpty);
    final choices = List.generate(
      8,
      (_) => SchoolChoice(
        schoolId: s.id,
        programme: s.programs.first,
        residence: 'Day',
      ),
    );
    expect(
      validateSchoolChoices(
        choices,
        gender: '',
        town: 'Accra',
        region: 'Greater Accra',
      ).any((c) => c.code == 'duplicate'),
      isTrue,
    );
  });
}
