import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/school.dart';
import 'package:skoolatlas/planning.dart';
import 'package:skoolatlas/published_updates.dart';
import 'package:skoolatlas/website_content.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late PublishedUpdates store;
  setUp(() {
    schools = [
      School({
        'id': 'sample',
        'name': 'Sample School',
        'region': 'Central',
        'category': 'Category C',
        'ownership': 'Public',
        'kind': 'SHS',
        'gender': 'Mixed',
        'residency': 'Day',
        'location': 'Sample',
        'description': 'Original description',
        'website': '',
        'images': <String>[],
        'programs': ['General Science', 'Business'],
        'sources': <Map<String, dynamic>>[],
      }),
    ];
    supportData = {'schools': <String, dynamic>{}};
    store = PublishedUpdates();
  });
  tearDown(() => store.dispose());
  Map<String, dynamic> update(
    String field,
    Object value, {
    String source = 'https://school.example/academics',
  }) => {
    'school_id': 'sample',
    'field': field,
    'value': value,
    'source_url': source,
    'observed': '2026-10-16',
    'reviewed_at': '2026-10-16T12:00:00Z',
  };
  test(
    'approved programme removal changes available choices and has provenance',
    () {
      store.apply({
        'updates': [
          update('programs', ['Business']),
        ],
      });
      expect(schools.single.programs, ['Business']);
      expect(
        schools.single.sources.single['url'],
        'https://school.example/academics',
      );
      store.apply({'updates': []});
      expect(schools.single.programs, ['General Science', 'Business']);
    },
  );
  test(
    'private URLs and unknown school identities cannot change the catalogue',
    () {
      store.apply({
        'updates': [
          update('name', 'Wrong', source: 'https://192.168.1.1/'),
          {...update('name', 'Other'), 'school_id': 'unknown'},
        ],
      });
      expect(schools.single.name, 'Sample School');
    },
  );
  test(
    'repeated snapshots do not duplicate achievements or dated fee records',
    () {
      final response = {
        'updates': [
          update('achievement', {
            'title': 'Quiz finalist',
            'result': 'Finalist',
            'year': 2026,
          }),
          update('fees', {
            'title': 'Uniform',
            'detail': 'Confirm quotation',
            'period': '2026/2027',
          }),
        ],
      };
      store.apply(response);
      store.apply(response);
      expect(schools.single.achievements.length, 1);
      expect((supportData['schools']['sample'] as List).length, 1);
    },
  );
  test(
    'offline pack preserves exact ordered programme and residence without grades',
    () async {
      final choices = [
        SchoolChoice(
          schoolId: 'sample',
          programme: 'Business',
          residence: 'Day',
        ),
      ];
      final html = await offlineSchoolPack(
        schools,
        photos: false,
        choices: choices,
      );
      expect(
        html,
        contains(
          '<td>1</td><td>Sample School</td><td>Business</td><td>Day</td>',
        ),
      );
      expect(html, contains('not an official CSSPS'));
      expect(html, contains('Discussion notes'));
    },
  );
  test(
    'reviewed new website domains join the feed allowlist and withdrawals remove them',
    () {
      store.apply({
        'updates': [update('website', 'https://new-school.example/')],
      });
      expect(websiteContent.approved['sample'], 'new-school.example');
      store.apply({'updates': []});
      expect(websiteContent.approved.containsKey('sample'), isFalse);
    },
  );
}
