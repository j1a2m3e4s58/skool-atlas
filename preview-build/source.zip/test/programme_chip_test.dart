import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets(
    'programme labels fit card rows at normal and enlarged text sizes',
    (tester) async {
      tester.view.physicalSize = const Size(390, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      for (final brightness in Brightness.values) {
        for (final scale in [1.0, 1.4, 2.0]) {
          await tester.pumpWidget(
            MaterialApp(
              theme: atlasTheme(brightness),
              builder: (context, child) => MediaQuery(
                data: MediaQuery.of(
                  context,
                ).copyWith(textScaler: TextScaler.linear(scale)),
                child: child!,
              ),
              home: const Scaffold(
                body: ProgrammeStrip(
                  programmes: [
                    'Business',
                    'Home Economics',
                    'Visual Arts',
                    'General Arts',
                  ],
                ),
              ),
            ),
          );
          await tester.pump();
          final row = find.descendant(
            of: find.byType(ProgrammeStrip),
            matching: find.byType(SingleChildScrollView),
          );
          final chip = find
              .descendant(of: row, matching: find.byType(TagChip))
              .first;
          final label = find.descendant(of: chip, matching: find.byType(Text));
          final rowRect = tester.getRect(row);
          final labelRect = tester.getRect(label);
          expect(labelRect.top, greaterThanOrEqualTo(rowRect.top));
          expect(labelRect.bottom, lessThanOrEqualTo(rowRect.bottom));
          expect(
            tester.getSize(row).height,
            greaterThanOrEqualTo(tester.getSize(label).height + 14),
          );
          expect(
            tester.takeException(),
            isNull,
            reason: '$brightness / $scale',
          );
        }
      }
      await tester.pumpWidget(const SizedBox());
    },
  );
}
