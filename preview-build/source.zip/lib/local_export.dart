export 'local_export_stub.dart'
    if (dart.library.js_interop) 'local_export_web.dart';
