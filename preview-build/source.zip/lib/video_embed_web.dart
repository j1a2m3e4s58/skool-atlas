import 'dart:ui_web' as ui_web;
import 'package:flutter/material.dart';
import 'package:web/web.dart' as web;

class SchoolYouTube extends StatefulWidget {
  final String videoId;
  const SchoolYouTube({super.key, required this.videoId});
  @override
  State<SchoolYouTube> createState() => _SchoolYouTubeState();
}

class _SchoolYouTubeState extends State<SchoolYouTube> {
  static int serial = 0;
  late final String viewType;
  @override
  void initState() {
    super.initState();
    if (!RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(widget.videoId)) {
      throw ArgumentError('Invalid YouTube video ID');
    }
    viewType = 'school-youtube-${serial++}';
    ui_web.platformViewRegistry.registerViewFactory(
      viewType,
      (int id) => web.HTMLIFrameElement()
        ..src = 'https://www.youtube-nocookie.com/embed/${widget.videoId}?rel=0'
        ..title = 'School website video'
        ..allow = 'encrypted-media; picture-in-picture; fullscreen'
        ..allowFullscreen = true
        ..referrerPolicy = 'strict-origin-when-cross-origin'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%',
    );
  }

  @override
  Widget build(BuildContext context) => AspectRatio(
    aspectRatio: 16 / 9,
    child: HtmlElementView(viewType: viewType),
  );
}
