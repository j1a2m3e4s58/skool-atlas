import 'dart:convert';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'accounts.dart';
import 'school.dart';
import 'planning.dart';
import 'website_content.dart';

final publishedUpdates = PublishedUpdates();

class PublishedUpdates extends ChangeNotifier {
  Timer? timer;
  String? checkedAt, error;
  final Map<String, Map<String, dynamic>> _baseline = {};
  Map<String, String>? _baselineDomains;
  final Map<String, List<Map<String, dynamic>>> media = {};
  Future<void> load() async {
    for (final s in schools) {
      _baseline.putIfAbsent(s.id, () => jsonDecode(jsonEncode(s.data)));
    }
    try {
      final cached = (await SharedPreferences.getInstance()).getString(
        'atlas.published.v1',
      );
      if (cached != null) apply(jsonDecode(cached));
    } catch (_) {}
    await refresh();
    timer?.cancel();
    timer = Timer.periodic(const Duration(hours: 1), (_) => refresh());
  }

  Future<void> refresh() async {
    try {
      final response = await accounts.request('/catalogue/updates');
      apply(response);
      await (await SharedPreferences.getInstance()).setString(
        'atlas.published.v1',
        jsonEncode(response),
      );
      error = null;
    } catch (_) {
      error =
          'Live school updates unavailable; showing the last saved information.';
    }
    notifyListeners();
  }

  void apply(Map response) {
    if (response['updates'] is! List) return;
    _baselineDomains ??= Map<String, String>.from(websiteContent.approved);
    final domains = Map<String, String>.from(_baselineDomains!);
    for (final s in schools) {
      _baseline.putIfAbsent(s.id, () => jsonDecode(jsonEncode(s.data)));
    }
    for (final s in schools) {
      final original = _baseline[s.id];
      if (original != null) {
        s.data
          ..clear()
          ..addAll(jsonDecode(jsonEncode(original)));
      }
    }
    media.clear();
    final support = supportData['schools'] as Map? ?? {};
    for (final id in support.keys.toList()) {
      if (support[id] is List) {
        support[id] = (support[id] as List)
            .where((r) => r is! Map || r['moderated'] != true)
            .toList();
      }
    }
    for (final raw in (response['updates'] as List).whereType<Map>()) {
      final matches = schools.where(
        (s) =>
            s.id == raw['school_id'] ||
            (s.data['legacyIds'] as List? ?? []).contains(raw['school_id']),
      );
      if (matches.isEmpty || !publicHttpsLink('${raw['source_url']}')) continue;
      final school = matches.first,
          field = '${raw['field']}',
          value = raw['value'];
      final provenance = {
        'label': 'Reviewed school update · ${raw['observed']}',
        'url': raw['source_url'],
      };
      if ([
            'name',
            'description',
            'residency',
            'website',
            'location',
            'code',
            'category',
            'ownership',
            'gender',
            'region',
            'status',
          ].contains(field) &&
          value is String) {
        if (field != 'website' || publicHttpsLink(value)) {
          school.data[field] = value;
          if (field == 'website') domains[school.id] = linkHost(value);
          if (field == 'code') {
            school.data['registerCodeConflict'] = false;
            school.data['codeSource'] = raw['source_url'];
          }
        }
      } else if (field == 'programs' &&
          value is List &&
          value.every((v) => v is String)) {
        school.data[field] = List<String>.from(value);
        school.data['programsObserved'] = raw['observed'];
        school.data['programsSource'] = raw['source_url'];
      } else if (field == 'coordinates' &&
          value is Map &&
          value['latitude'] is num &&
          value['longitude'] is num) {
        school.data['coordinates'] = {
          ...value,
          'source': raw['source_url'],
          'observed': raw['observed'],
        };
      } else if (field == 'achievement' && value is Map) {
        school.data['achievements'] = [
          ...school.achievements,
          <String, dynamic>{
            ...Map<String, dynamic>.from(value),
            'source': raw['source_url'],
            'url': raw['source_url'],
            'kind': value['kind'] ?? 'School-published achievement',
            'result': value['result'] ?? value['detail'],
            'observed': raw['observed'],
          },
        ];
      } else if (field == 'media' &&
          value is Map &&
          publicHttpsLink('${value['url']}')) {
        if (value['kind'] == 'crest') school.data['remoteLogo'] = value['url'];
        media[school.id] = [
          ...(media[school.id] ?? []).where((m) => m['url'] != value['url']),
          {
            ...value,
            'source': raw['source_url'],
            'label': value['title'],
            'observed': raw['observed'],
          },
        ];
      } else if (value is Map) {
        final kind = {
          'contact': 'Contact',
          'fees': 'Fees',
          'scholarship': 'Scholarship',
          'prospectus': 'Prospectus',
          'catchment': 'Catchment',
        }[field];
        if (kind != null) {
          support[school.id] = [
            ...(support[school.id] as List? ?? []),
            {
              ...value,
              'kind': kind,
              'source': raw['source_url'],
              'url': value['url'] ?? raw['source_url'],
              'observed': raw['observed'],
              'moderated': true,
            },
          ];
        }
      }
      school.data['sources'] = [...school.sources, provenance];
      school.data['lastReviewedUpdate'] = raw['reviewed_at'];
    }
    supportData['schools'] = support;
    final domainsChanged = !mapEquals(websiteContent.approved, domains);
    websiteContent.useApprovedDomains(domains);
    if (domainsChanged) unawaited(websiteContent.refresh());
    checkedAt = '${response['generatedAt'] ?? ''}';
    notifyListeners();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }
}
