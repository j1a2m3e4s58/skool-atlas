part of 'main.dart';

void openPlanningTool(BuildContext context, Widget page, String title) {
  if (page is ResultsPlannerPage &&
      !page.resumeSaved &&
      atlasShellKey.currentState != null) {
    atlasShellKey.currentState!.navigate(8);
    return;
  }
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) =>
          Scaffold(appBar: atlasPageBar(context, title), body: page),
    ),
  );
}

class PlanningHub extends StatelessWidget {
  final bool includePlanner;
  const PlanningHub({super.key, this.includePlanner = true});
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const PanelHeading(
          icon: Icons.explore_outlined,
          title: 'Your school-choice toolkit',
        ),
        const SizedBox(height: 10),
        Text(
          'Explore study paths, check practical details, review evidence and take your choices offline.',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        const SizedBox(height: 18),
        BalancedActions(
          children: [
            if (includePlanner)
              FilledButton.icon(
                onPressed: () => openPlanningTool(
                  context,
                  const ResultsPlannerPage(),
                  'Results & school choices',
                ),
                icon: const Icon(Icons.auto_graph),
                label: const Text('Results & choice planner'),
              ),
            OutlinedButton.icon(
              onPressed: () => openPlanningTool(
                context,
                const CareerGuidancePage(),
                'Programme & career explorer',
              ),
              icon: const Icon(Icons.explore_outlined),
              label: const Text('Career pathways'),
            ),
            OutlinedButton.icon(
              onPressed: () => openPlanningTool(
                context,
                const SupportDirectoryPage(),
                'Fees, support & contacts',
              ),
              icon: const Icon(Icons.info_outline),
              label: const Text('Fees, support & contacts'),
            ),
            OutlinedButton.icon(
              onPressed: () => openPlanningTool(
                context,
                const OfflineChoicesPage(),
                'Offline & sharing',
              ),
              icon: const Icon(Icons.download_outlined),
              label: const Text('Offline & family sharing'),
            ),
          ],
        ),
      ],
    ),
  );
}

class CareerGuidancePage extends StatefulWidget {
  const CareerGuidancePage({super.key});
  @override
  State<CareerGuidancePage> createState() => _CareerGuidancePageState();
}

class _CareerGuidancePageState extends State<CareerGuidancePage> {
  CareerPath path = careerPaths.first;
  String region = 'All regions', residence = 'Any residence';
  int limit = 12;
  @override
  Widget build(BuildContext context) {
    final matches = explainMatches(path, region: region, residence: residence);
    return PageFrame(
      title: 'Discover a path that interests you',
      subtitle:
          'Start with what you enjoy. Then explore programmes and schools, with a clear reason for every match.',
      children: [
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final option in careerPaths)
                    ChoiceChip(
                      label: Text(option.title),
                      selected: path.id == option.id,
                      onSelected: (_) => setState(() {
                        path = option;
                        limit = 12;
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                path.description,
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [for (final p in path.programmes) TagChip(label: p)],
              ),
              const SizedBox(height: 12),
              Text(
                'Possible areas to explore: ${path.careers.join(', ')}.',
                style: const TextStyle(height: 1.6),
              ),
              const SizedBox(height: 8),
              Text(
                path.subjects,
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
              const SizedBox(height: 16),
              Text(
                'Try this: ${path.activity}',
                style: TextStyle(color: context.atlas.primary, height: 1.6),
              ),
              const SizedBox(height: 18),
              PanelGrid(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: DropdownButtonFormField<String>(
                      initialValue: region,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Preferred region',
                      ),
                      items:
                          [
                                'All regions',
                                ...(schools
                                    .map((s) => s.region)
                                    .toSet()
                                    .toList()
                                  ..sort()),
                              ]
                              .map(
                                (r) =>
                                    DropdownMenuItem(value: r, child: Text(r)),
                              )
                              .toList(),
                      onChanged: (value) => setState(() {
                        region = value!;
                        limit = 12;
                      }),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: DropdownButtonFormField<String>(
                      initialValue: residence,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Preferred residence',
                      ),
                      items: ['Any residence', 'Day', 'Boarding']
                          .map(
                            (r) => DropdownMenuItem(value: r, child: Text(r)),
                          )
                          .toList(),
                      onChanged: (value) => setState(() {
                        residence = value!;
                        limit = 12;
                      }),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Text(
          '${matches.length} programme matches',
          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 8),
        Text(
          'Shown alphabetically. These are study-path suggestions, not a school-quality ranking or an admission prediction. Confirm exact subject combinations and further-study entry requirements with your guidance teacher and the relevant institution.',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        const SizedBox(height: 18),
        if (matches.isEmpty)
          const Surface(
            child: Text(
              'No matching programmes were found with these preferences. Try another region or residence option.',
            ),
          ),
        for (final match in matches.take(limit))
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SchoolName(
                    school: match.school,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 12),
                  for (final reason in match.reasons)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        reason,
                        style: TextStyle(
                          color: context.atlas.muted,
                          height: 1.5,
                        ),
                      ),
                    ),
                  BalancedActions(
                    children: [
                      TextButton(
                        onPressed: () => showSchool(context, match.school),
                        child: const Text('Explore school'),
                      ),
                      TextButton(
                        onPressed: () =>
                            atlasStore.toggleSaved(match.school.id),
                        child: const Text('Save to shortlist'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        if (matches.length > limit)
          OutlinedButton(
            onPressed: () => setState(() => limit += 12),
            child: const Text('Show more matches'),
          ),
        TextButton(
          onPressed: () =>
              openLink(context, Uri.parse('https://nacca.gov.gh/')),
          child: const Text('Explore official curriculum information'),
        ),
      ],
    );
  }
}

class PracticalRecord extends StatelessWidget {
  final Map record;
  const PracticalRecord({super.key, required this.record});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 14),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: context.atlas.lightBg,
        border: Border.all(color: context.atlas.border),
        borderRadius: AtlasStyle.cardRadius,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              TagChip(label: '${record['kind']}'),
              if (record['status'] != null)
                TagChip(label: '${record['status']}'),
              if (needsFreshCheck('${record['observed']}', DateTime.now()))
                const TagChip(label: 'Needs a fresh check'),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            '${record['title']}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            '${record['detail']}',
            style: TextStyle(color: context.atlas.muted, height: 1.6),
          ),
          const SizedBox(height: 10),
          Text(
            '${record['period']}\nObserved ${record['observed']}${record.containsKey('deadline') ? '\nDeadline: ${record['deadline'] ?? 'not confirmed'}' : ''}',
            style: TextStyle(
              fontSize: 12,
              color: context.atlas.muted,
              height: 1.6,
            ),
          ),
          if (isEvidenceUrl('${record['url']}'))
            TextButton.icon(
              onPressed: () => openLink(context, Uri.parse('${record['url']}')),
              icon: const Icon(Icons.open_in_new, size: 16),
              label: const Text('Check the published source'),
            ),
          if (record['kind'] == 'Contact')
            TextButton.icon(
              onPressed: () async {
                await Clipboard.setData(
                  ClipboardData(
                    text:
                        '${record['title']}\n${record['detail']}\n${record['period']}\nSource: ${record['url']}',
                  ),
                );
                if (context.mounted) {
                  toast(context, 'Contact details and their source copied.');
                }
              },
              icon: const Icon(Icons.copy_outlined),
              label: const Text('Copy contact details'),
            ),
        ],
      ),
    ),
  );
}

class SchoolPracticalInfo extends StatelessWidget {
  final School school;
  const SchoolPracticalInfo({super.key, required this.school});
  @override
  Widget build(BuildContext context) {
    final records =
        ((supportData['schools'] as Map?)?[school.id] as List? ?? [])
            .cast<Map>();
    return Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Costs, contacts & residential information',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.w800,
              color: context.atlas.primaryDark,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Listed residence: ${school.residency}. ${school.data['residencyNote'] ?? ''}',
            style: const TextStyle(fontWeight: FontWeight.w700, height: 1.6),
          ),
          const SizedBox(height: 6),
          Text(
            school.data['registerYear'] == 2026
                ? 'Source: 2026 selection register, page ${school.data['registerPage']}. Bed availability is not confirmed.'
                : 'Residence comes from the directory snapshot; confirm it directly with the school.',
            style: TextStyle(
              color: context.atlas.muted,
              fontSize: 12,
              height: 1.5,
            ),
          ),
          for (final record in records) PracticalRecord(record: record),
          if (!records.any((r) => r['kind'] == 'Fees'))
            Padding(
              padding: EdgeInsets.only(top: 16),
              child: Text(
                'No reviewed fee quotation added yet. This does not mean that all costs are zero. Ask for a dated breakdown of tuition or applicable charges, boarding, uniform, materials and transport.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
            ),
          if (!records.any((r) => r['kind'] == 'Contact'))
            Padding(
              padding: EdgeInsets.only(top: 12),
              child: Text(
                'No reviewed direct contact added yet. Use the linked sources or your JHS guidance teacher to verify the school office.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
            ),
          const SizedBox(height: 12),
          BalancedActions(
            children: [
              TextButton.icon(
                onPressed: () => openPlanningTool(
                  context,
                  SchoolPortalPage(initialSchool: school),
                  'Suggest a school update',
                ),
                icon: const Icon(Icons.edit_note),
                label: const Text('Suggest a sourced update'),
              ),
              TextButton(
                onPressed: () => openPlanningTool(
                  context,
                  const SupportDirectoryPage(),
                  'Fees & financial support',
                ),
                child: const Text('Explore financial support'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SupportDirectoryPage extends StatefulWidget {
  const SupportDirectoryPage({super.key});
  @override
  State<SupportDirectoryPage> createState() => _SupportDirectoryPageState();
}

class _SupportDirectoryPageState extends State<SupportDirectoryPage> {
  String query = '';
  School? selected;
  @override
  Widget build(BuildContext context) => PageFrame(
    title: 'Plan the practical side',
    subtitle:
        'Dated source information for costs, contacts, residence and financial support. Confirm the complete current terms before making a commitment.',
    children: [
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: 'Find a school for practical information',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) => setState(() {
                query = value;
                selected = null;
              }),
            ),
            if (query.trim().length >= 2) ...[
              for (final school in searchSchools(query: query).take(8))
                ListTile(
                  title: Text(school.name),
                  subtitle: Text(school.region),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => setState(() => selected = school),
                ),
            ],
            if (query.isEmpty) ...[
              const SizedBox(height: 16),
              const Text(
                'Start with a school with published practical details:',
              ),
              BalancedActions(
                children: [
                  for (final school in schools.where(
                    (s) => ((supportData['schools'] as Map?) ?? {}).containsKey(
                      s.id,
                    ),
                  ))
                    TextButton(
                      onPressed: () => setState(() => selected = school),
                      child: Text(school.name),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
      if (selected != null) ...[
        const SizedBox(height: 18),
        SchoolName(
          school: selected!,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 12),
        SchoolPracticalInfo(school: selected!),
      ],
      const SizedBox(height: 24),
      const SectionTitle(
        title: 'Scholarships & support to enquire about',
        subtitle:
            'An information page is not proof that an application window is open or that you are eligible.',
      ),
      for (final record
          in (supportData['scholarships'] as List? ?? []).cast<Map>())
        PracticalRecord(record: record),
    ],
  );
}

class OfflineChoicesPage extends StatelessWidget {
  final List<School>? selected;
  const OfflineChoicesPage({super.key, this.selected});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: atlasStore,
    builder: (context, _) {
      final chosen =
          selected ??
          schools.where((s) => atlasStore.saved.contains(s.id)).toList();
      return PageFrame(
        maxWidth: 900,
        title: 'Your choices, ready to take with you',
        subtitle:
            'Keep a copy for home, a family discussion or a meeting with your guidance teacher.',
        children: [
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${chosen.length} ${selected == null ? 'saved schools' : 'schools in this pack'}',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Download an HTML pack with embedded school photos. It opens without internet and includes a Print / save as PDF button. External source and map links still need internet. Grades and your home location are not included.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                const SizedBox(height: 18),
                ExportChoiceActions(selected: chosen),
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (chosen.isEmpty)
            const Surface(
              child: Text(
                'Save some schools from the directory first, then return here to download your pack.',
              ),
            ),
          for (final school in chosen)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SchoolName(
                      school: school,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('${school.region} | ${school.residency}'),
                    TextButton(
                      onPressed: () => showSchool(context, school),
                      child: const Text('View profile'),
                    ),
                  ],
                ),
              ),
            ),
          Text(
            'Saved choices are local to this browser. Share the downloaded file using your usual messaging or email app. A localhost preview link cannot be opened from another device.',
            style: TextStyle(color: context.atlas.muted, height: 1.6),
          ),
        ],
      );
    },
  );
}

class ExportChoiceActions extends StatefulWidget {
  final List<School> selected;
  final List<SchoolChoice>? choices;
  final List<ChoiceCheck> checks;
  const ExportChoiceActions({
    super.key,
    required this.selected,
    this.choices,
    this.checks = const [],
  });
  @override
  State<ExportChoiceActions> createState() => _ExportChoiceActionsState();
}

class _ExportChoiceActionsState extends State<ExportChoiceActions> {
  bool busy = false;
  Future<void> download(bool photos) async {
    setState(() => busy = true);
    try {
      final html = await offlineSchoolPack(
        widget.selected,
        photos: photos,
        choices: widget.choices,
        requirements: widget.checks
            .where((c) => c.error)
            .map((c) => c.message)
            .toList(),
      );
      final ok = await saveTextFile(
        'skool-atlas-school-choices.html',
        html,
        'text/html',
      );
      if (mounted) {
        toast(
          context,
          ok
              ? 'Offline pack ready. Save or share it; open it to print or save as PDF.'
              : 'Sharing is unavailable on this device. Try the web download.',
        );
      }
    } catch (_) {
      if (mounted) {
        toast(
          context,
          'Could not create the pack. Try the smaller text-only pack.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      if (widget.choices != null)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            'Export status: unverified draft · ${widget.checks.where((c) => c.error).length} unresolved requirements. The downloaded pack includes the review warnings.',
            style: TextStyle(
              color: context.atlas.muted,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      BalancedActions(
        children: [
          FilledButton.icon(
            onPressed: busy || widget.selected.isEmpty
                ? null
                : () => download(true),
            icon: busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download),
            label: const Text('Save / share offline pack'),
          ),
          OutlinedButton(
            onPressed: busy || widget.selected.isEmpty
                ? null
                : () => download(false),
            child: const Text('Smaller text-only pack'),
          ),
          if (widget.choices != null && widget.choices!.isNotEmpty)
            FilledButton.tonalIcon(
              onPressed: () => openPlanningTool(
                context,
                PublishDraftPage(choices: widget.choices!),
                'Share an ordered draft',
              ),
              icon: const Icon(Icons.group_outlined),
              label: const Text('Invite family / teacher'),
            ),
          OutlinedButton.icon(
            onPressed: widget.selected.isEmpty
                ? null
                : () async {
                    await Clipboard.setData(
                      ClipboardData(text: schoolShareText(widget.selected)),
                    );
                    if (context.mounted) {
                      toast(
                        context,
                        'Family / teacher summary copied. Paste it into your message.',
                      );
                    }
                  },
            icon: const Icon(Icons.copy_outlined),
            label: const Text('Copy family / teacher summary'),
          ),
        ],
      ),
    ],
  );
}

class SchoolUpdatesPage extends StatefulWidget {
  final School? initialSchool;
  const SchoolUpdatesPage({super.key, this.initialSchool});
  @override
  State<SchoolUpdatesPage> createState() => _SchoolUpdatesPageState();
}

class _SchoolUpdatesPageState extends State<SchoolUpdatesPage> {
  int section = 0;
  String query = '', field = updateFields.first;
  School? selected;
  final form = GlobalKey<FormState>();
  final value = TextEditingController(),
      source = TextEditingController(),
      contributor = TextEditingController(),
      note = TextEditingController(),
      missingName = TextEditingController();
  late final observed = TextEditingController(text: dateLabel(DateTime.now()));
  @override
  void initState() {
    super.initState();
    selected = widget.initialSchool;
  }

  @override
  void dispose() {
    for (final c in [value, source, contributor, note, observed, missingName]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    if (!(form.currentState?.validate() ?? false)) return;
    if (field != 'Missing school' && selected == null) {
      toast(context, 'Choose the school this update is about.');
      return;
    }
    try {
      await planningStore.propose(
        schoolId: selected?.id ?? '',
        schoolName: field == 'Missing school'
            ? missingName.text
            : selected!.name,
        field: field,
        value: value.text,
        source: source.text,
        observed: observed.text,
        submitter: contributor.text,
        note: note.text,
      );
      value.clear();
      source.clear();
      note.clear();
      if (mounted) {
        setState(() => section = 1);
        toast(context, 'Proposal saved on this device for evidence review.');
      }
    } on ArgumentError catch (error) {
      if (mounted) toast(context, '${error.message}');
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: planningStore,
    builder: (context, _) => PageFrame(
      title: 'Help keep school information accurate',
      subtitle:
          'A local evidence-review workspace for school staff, contributors and the project owner.',
      children: [
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Local review workspace',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Text(
                'Proposals and review notes stay on this browser. Reviewer identities are not authenticated here, and reviews do not publish or change the shared catalogue. Export the review pack for controlled publication after source checking.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
              if (!planningStore.persistent)
                const Text(
                  'Device storage is unavailable. Export this session before closing it.',
                  style: TextStyle(color: Colors.deepOrange),
                ),
              const SizedBox(height: 18),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  ChoiceChip(
                    label: const Text('Suggest update'),
                    selected: section == 0,
                    onSelected: (_) => setState(() => section = 0),
                  ),
                  ChoiceChip(
                    label: Text(
                      'Review queue (${planningStore.proposals.length})',
                    ),
                    selected: section == 1,
                    onSelected: (_) => setState(() => section = 1),
                  ),
                  ChoiceChip(
                    label: const Text('Register reconciliation'),
                    selected: section == 2,
                    onSelected: (_) => setState(() => section = 2),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (section == 0)
          Surface(
            child: Form(
              key: form,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField<String>(
                    initialValue: field,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'What needs updating?',
                    ),
                    items: updateFields
                        .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                        .toList(),
                    onChanged: (f) => setState(() => field = f!),
                  ),
                  const SizedBox(height: 16),
                  if (field == 'Missing school')
                    TextFormField(
                      controller: missingName,
                      decoration: const InputDecoration(
                        labelText: 'Full name of the missing school',
                      ),
                      validator: (v) =>
                          v!.trim().isEmpty ? 'Enter the school name.' : null,
                    )
                  else if (selected != null)
                    Column(
                      children: [
                        SchoolName(
                          school: selected!,
                          style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        TextButton(
                          onPressed: () => setState(() => selected = null),
                          child: const Text('Choose a different school'),
                        ),
                      ],
                    )
                  else ...[
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Search for the school',
                        prefixIcon: Icon(Icons.search),
                      ),
                      onChanged: (v) => setState(() => query = v),
                    ),
                    if (query.trim().length >= 2)
                      for (final school in searchSchools(query: query).take(8))
                        ListTile(
                          title: Text(school.name),
                          subtitle: Text(
                            '${school.region} | ${school.data['code'] ?? 'Code unconfirmed'}',
                          ),
                          onTap: () => setState(() => selected = school),
                        ),
                  ],
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: value,
                    maxLength: 4000,
                    minLines: 3,
                    maxLines: 7,
                    decoration: InputDecoration(
                      labelText: 'Proposed $field information',
                      helperText:
                          'Include the academic year, amounts and what is included where relevant.',
                    ),
                    validator: (v) => v!.trim().isEmpty
                        ? 'Describe the proposed information.'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: source,
                    decoration: const InputDecoration(
                      labelText: 'HTTPS evidence link',
                      helperText:
                          'A public school page, dated notice or official register.',
                    ),
                    validator: (v) => isEvidenceUrl(v ?? '')
                        ? null
                        : 'Enter a complete HTTPS source link.',
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: observed,
                    decoration: const InputDecoration(
                      labelText: 'Date you checked the source (YYYY-MM-DD)',
                    ),
                    validator: (v) => isValidReviewDate(v ?? '', DateTime.now())
                        ? null
                        : 'Use a valid observation date, not a future date.',
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: contributor,
                    maxLength: 120,
                    decoration: const InputDecoration(
                      labelText: 'Contributor or school office',
                      helperText:
                          'Do not enter a student index number, PIN or private student details.',
                    ),
                    validator: (v) => v!.trim().isEmpty
                        ? 'Enter a contributor name or office.'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: note,
                    maxLength: 2000,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'Evidence note',
                      helperText:
                          'Explain where the information appears and any limitations.',
                    ),
                    validator: (v) => v!.trim().length < 10
                        ? 'Add an evidence note of at least 10 characters.'
                        : null,
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: submit,
                    icon: const Icon(Icons.add_task),
                    label: const Text('Save proposal for review'),
                  ),
                ],
              ),
            ),
          ),
        if (section == 1) ...[
          BalancedActions(
            children: [
              OutlinedButton.icon(
                onPressed: planningStore.proposals.isEmpty
                    ? null
                    : () async {
                        final ok = await saveTextFile(
                          'skool-atlas-review-pack.json',
                          planningStore.exportReviewPack(),
                          'application/json',
                        );
                        if (context.mounted) {
                          toast(
                            context,
                            ok
                                ? 'Review pack downloaded; no catalogue changes were published.'
                                : 'Use Copy review pack on this platform.',
                          );
                        }
                      },
                icon: const Icon(Icons.download),
                label: const Text('Export review pack'),
              ),
              TextButton(
                onPressed: planningStore.proposals.isEmpty
                    ? null
                    : () async {
                        await Clipboard.setData(
                          ClipboardData(text: planningStore.exportReviewPack()),
                        );
                        if (context.mounted) {
                          toast(context, 'Review pack copied.');
                        }
                      },
                child: const Text('Copy review pack'),
              ),
            ],
          ),
          if (planningStore.proposals.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 18),
              child: Surface(
                child: Text(
                  'No proposals yet. Add a sourced school update to start the review queue.',
                ),
              ),
            ),
          for (final item in planningStore.proposals.reversed)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        TagChip(label: '${item['status']}'),
                        TagChip(label: '${item['field']}'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '${item['schoolName']}',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${item['value']}',
                      style: const TextStyle(height: 1.6),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Contributor: ${item['submitter']} | Observed ${item['observed']}\n${item['note']}',
                      style: TextStyle(color: context.atlas.muted, height: 1.6),
                    ),
                    TextButton.icon(
                      onPressed: () =>
                          openLink(context, Uri.parse('${item['source']}')),
                      icon: const Icon(Icons.open_in_new, size: 16),
                      label: const Text('Review evidence source'),
                    ),
                    if (item['reviewNote'] != null)
                      Text(
                        'Local reviewer: ${item['reviewer']}\n${item['reviewNote']}\nNot published; reviewer identity is not authenticated.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          height: 1.6,
                        ),
                      ),
                    if (item['status'] == 'Pending review')
                      FilledButton.tonal(
                        onPressed: () => reviewProposal(context, item),
                        child: const Text('Record an evidence review'),
                      ),
                  ],
                ),
              ),
            ),
        ],
        if (section == 2) const RegisterReconciliationPanel(),
      ],
    ),
  );
}

Future<void> reviewProposal(
  BuildContext context,
  Map<String, dynamic> item,
) async {
  final reviewer = TextEditingController(), note = TextEditingController();
  bool checked = false;
  final form = GlobalKey<FormState>();
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        title: const Text('Record a local evidence review'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Form(
              key: form,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Check the source against the proposed value and academic period. This records a local review, not a verified staff identity or a publication.',
                  ),
                  const SizedBox(height: 18),
                  TextFormField(
                    controller: reviewer,
                    decoration: const InputDecoration(
                      labelText: 'Reviewer name or office',
                    ),
                    validator: (v) =>
                        v!.trim().isEmpty ? 'Enter the reviewer.' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: note,
                    minLines: 3,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      labelText: 'Review decision and evidence checked',
                    ),
                    validator: (v) => v!.trim().length < 10
                        ? 'Add a review note of at least 10 characters.'
                        : null,
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    value: checked,
                    onChanged: (v) => setState(() => checked = v!),
                    title: const Text(
                      'I checked this proposal and its linked evidence.',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          for (final accept in [false, true])
            TextButton(
              onPressed: () async {
                if (!(form.currentState?.validate() ?? false)) return;
                if (!checked) {
                  toast(context, 'Confirm that you checked the evidence.');
                  return;
                }
                await planningStore.review(
                  '${item['id']}',
                  accept: accept,
                  reviewer: reviewer.text,
                  note: note.text,
                  evidenceChecked: checked,
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: Text(accept ? 'Record local review' : 'Reject proposal'),
            ),
        ],
      ),
    ),
  );
  reviewer.dispose();
  note.dispose();
}

class RegisterReconciliationPanel extends StatelessWidget {
  const RegisterReconciliationPanel({super.key});
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Register reconciliation - 2026',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w800,
            color: context.atlas.primaryDark,
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 18,
          runSpacing: 16,
          children: [
            InfoBlock(
              title: 'Sourced register entries',
              value: '${reconciliation['registerCount'] ?? 'Pending'}',
            ),
            InfoBlock(
              title: 'Unrepresented entries',
              value: '${(reconciliation['missing'] as List? ?? []).length}',
            ),
            InfoBlock(
              title: 'Conflicting source codes',
              value:
                  '${(reconciliation['conflictingCodes'] as List? ?? []).length}',
            ),
            InfoBlock(
              title: 'Possible name matches to review',
              value:
                  '${(reconciliation['possibleDuplicates'] as List? ?? []).length}',
            ),
          ],
        ),
        const SizedBox(height: 18),
        Text(
          '${reconciliation['scopeNote'] ?? 'Reconciliation report is loading.'}',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        const SizedBox(height: 10),
        Text(
          'Code matches and unique names in the same region can be reconciled. Similar names and conflicting printed codes remain visible for human review. Private schools outside the pilot are not a complete national private-school register.',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        const SizedBox(height: 12),
        BalancedActions(
          children: [
            OutlinedButton(
              onPressed: () =>
                  openLink(context, Uri.parse('${reconciliation['source']}')),
              child: const Text('Open the sourced register'),
            ),
            OutlinedButton(
              onPressed: () async {
                await saveTextFile(
                  'skool-atlas-register-reconciliation.json',
                  const JsonEncoder.withIndent('  ').convert(reconciliation),
                  'application/json',
                );
              },
              child: const Text('Download full reconciliation report'),
            ),
          ],
        ),
        const SizedBox(height: 18),
        const Text(
          'Name matches needing review',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        for (final issue
            in (reconciliation['possibleDuplicates'] as List? ?? [])
                .take(30)
                .cast<Map>())
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              '${issue['name']} | Code ${issue['code']}\n${issue['reason']}\nCandidate IDs: ${(issue['ids'] as List).join(', ')}',
              style: TextStyle(color: context.atlas.muted, height: 1.5),
            ),
          ),
        const SizedBox(height: 12),
        Text(
          'The downloadable report contains every match, addition and unresolved issue. National completeness is not certified.',
          style: TextStyle(fontSize: 12, color: context.atlas.muted),
        ),
      ],
    ),
  );
}

class SharedChoicesPage extends StatelessWidget {
  final List<School> selected;
  const SharedChoicesPage({super.key, required this.selected});
  @override
  Widget build(BuildContext context) => PageFrame(
    title: 'School choices shared with you',
    subtitle:
        'Explore these schools together. Opening this page does not change your saved choices.',
    children: [
      ExportChoiceActions(selected: selected),
      const SizedBox(height: 20),
      for (final school in selected)
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SchoolName(
                  school: school,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  '${school.region} | ${school.residency}\n${school.programs.join(', ')}',
                  style: const TextStyle(height: 1.6),
                ),
                BalancedActions(
                  children: [
                    TextButton(
                      onPressed: () => showSchool(context, school),
                      child: const Text('View school'),
                    ),
                    TextButton(
                      onPressed: () => atlasStore.toggleSaved(school.id),
                      child: const Text('Save to my shortlist'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
    ],
  );
}
