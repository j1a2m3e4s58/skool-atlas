import 'package:flutter/material.dart';

class SchoolYouTube extends StatelessWidget {
  final String videoId;
  const SchoolYouTube({super.key, required this.videoId});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.all(24),
    child: Text(
      'Use Watch on source to play this YouTube video on your device.',
    ),
  );
}
