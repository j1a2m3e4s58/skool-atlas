import 'dart:convert';
import 'dart:typed_data';
import 'package:share_plus/share_plus.dart';

Future<bool> saveTextFile(String name, String text, String mime) async {
  return saveBinaryFile(name, Uint8List.fromList(utf8.encode(text)), mime);
}

Future<bool> saveBinaryFile(String name, Uint8List bytes, String mime) async {
  final result = await SharePlus.instance.share(
    ShareParams(
      title: 'Skool Atlas',
      files: [XFile.fromData(bytes, mimeType: mime)],
      fileNameOverrides: [name],
    ),
  );
  return result.status != ShareResultStatus.unavailable;
}
