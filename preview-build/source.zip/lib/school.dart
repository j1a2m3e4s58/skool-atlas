import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class School {
  final Map<String, dynamic> data;
  School(this.data);
  String get id => data['id'] as String;
  String get name => data['name'] as String;
  String get region => data['region'] as String;
  String get category => data['category'] as String;
  String get categoryNote => data['categoryNote'] as String? ?? '';
  String get categoryLabel => data['registerYear'] != null
      ? '$category (${data['registerYear']})'
      : category == 'Not confirmed'
      ? category
      : categoryNote.contains('2023')
      ? '$category (2023)'
      : categoryNote.contains('archive')
      ? '$category · archive'
      : category;
  String get ownership => data['ownership'] as String;
  String get kind => data['kind'] as String;
  String get gender => data['gender'] as String;
  String get residency => data['residency'] as String;
  String get location => data['location'] as String;
  String get description => data['description'] as String;
  String get website => data['website'] as String? ?? '';
  bool get identityNeedsReview => data['identityNeedsReview'] == true;
  String get selectionSignature {
    final sortedPrograms = programs..sort();
    return jsonEncode([
      data['code'],
      category,
      gender,
      residency,
      data['status'],
      data['registerCodeConflict'],
      sortedPrograms,
    ]);
  }

  bool get selectable =>
      data['status'] != 'Closed' && data['status'] != 'Under review';
  String get logo => data['logo'] as String? ?? '';
  String get remoteLogo => data['remoteLogo'] as String? ?? '';
  bool get hasCrest => logo.isNotEmpty || remoteLogo.isNotEmpty;
  String get type => '$gender · $residency';
  List<String> get programs => List<String>.from(data['programs'] as List);
  List<String> get images => List<String>.from(data['images'] as List);
  List<String> get facilities =>
      List<String>.from(data['facilities'] as List? ?? []);
  List<Map<String, dynamic>> get sources =>
      List<Map<String, dynamic>>.from(data['sources'] as List);
  List<Map<String, dynamic>> get achievements =>
      List<Map<String, dynamic>>.from(data['achievements'] as List? ?? []);
  Uri get mapUri => Uri.https('www.google.com', '/maps/search/', {
    'api': '1',
    'query': '$name, $location',
  });
  String get searchable =>
      '$name $region $location $category $gender $residency $kind $ownership ${programs.join(' ')} ${(data['searchAliases'] as List? ?? []).join(' ')}'
          .toLowerCase();
}

List<School> schools = [];
final atlasStore = AtlasStore();

String canonicalSchoolId(String id) {
  for (final school in schools) {
    if (school.id == id ||
        (school.data['legacyIds'] as List? ?? []).contains(id)) {
      return school.id;
    }
  }
  return id;
}

class AtlasStore extends ChangeNotifier {
  SharedPreferences? _preferences;
  final Set<String> saved = {};
  final List<String> compared = [];
  final Set<String> checklist = {};
  bool persistent = true;

  Future<void> applyCloudState(
    Set<String> cloudSaved,
    List<String> cloudCompared,
    Set<String> cloudChecklist, {
    bool merge = true,
  }) async {
    if (!merge) {
      saved.clear();
      compared.clear();
      checklist.clear();
    }
    saved.addAll(cloudSaved.map(canonicalSchoolId));
    checklist.addAll(cloudChecklist);
    for (final id in cloudCompared.map(canonicalSchoolId)) {
      if (!compared.contains(id) && compared.length < 3) compared.add(id);
    }
    await _write('atlas.saved.v1', saved.toList());
    await _write('atlas.compare.v1', compared);
    await _write('atlas.checklist.v1', checklist.toList());
    notifyListeners();
  }

  Future<void> load() async {
    try {
      _preferences = await SharedPreferences.getInstance();
      saved.addAll(_preferences!.getStringList('atlas.saved.v1') ?? []);
      compared.addAll(
        (_preferences!.getStringList('atlas.compare.v1') ?? []).take(3),
      );
      checklist.addAll(_preferences!.getStringList('atlas.checklist.v1') ?? []);
    } catch (_) {
      persistent = false;
    }
  }

  Future<void> _write(String key, Iterable<String> values) async {
    try {
      if (_preferences == null ||
          !await _preferences!.setStringList(key, values.toList())) {
        persistent = false;
      }
    } catch (_) {
      persistent = false;
    }
    notifyListeners();
  }

  Future<void> remapSchoolIds(Map<String, String> aliases) async {
    final nextSaved = saved.map((id) => aliases[id] ?? id).toSet();
    final nextCompared = compared
        .map((id) => aliases[id] ?? id)
        .toSet()
        .toList();
    if (!setEquals(saved, nextSaved)) {
      saved
        ..clear()
        ..addAll(nextSaved);
      await _write('atlas.saved.v1', saved);
    }
    if (!listEquals(compared, nextCompared)) {
      compared
        ..clear()
        ..addAll(nextCompared);
      await _write('atlas.compare.v1', compared);
    }
  }

  Future<void> toggleSaved(String id) async {
    saved.contains(id) ? saved.remove(id) : saved.add(id);
    notifyListeners();
    await _write('atlas.saved.v1', saved);
  }

  String addComparison(String id) {
    if (compared.contains(id)) {
      return 'This school is already in your comparison.';
    }
    if (compared.length >= 3) {
      return 'Compare up to three schools. Remove one to add another.';
    }
    compared.add(id);
    notifyListeners();
    _write('atlas.compare.v1', compared);
    return 'Added to your comparison.';
  }

  Future<void> removeComparison(String id) async {
    compared.remove(id);
    notifyListeners();
    await _write('atlas.compare.v1', compared);
  }

  Future<void> toggleChecklist(String id) async {
    checklist.contains(id) ? checklist.remove(id) : checklist.add(id);
    notifyListeners();
    await _write('atlas.checklist.v1', checklist);
  }
}

Future<void> loadAtlas() async {
  final raw =
      jsonDecode(await rootBundle.loadString('assets/schools/catalog.json'))
          as List;
  schools = raw
      .map((s) => School(Map<String, dynamic>.from(s as Map)))
      .toList();
  await atlasStore.load();
  await atlasStore.remapSchoolIds({
    for (final school in schools)
      for (final oldId in school.data['legacyIds'] as List? ?? [])
        oldId as String: school.id,
  });
}

List<School> searchSchools({
  String query = '',
  String region = 'All regions',
  String program = 'All programmes',
  String gender = 'All students',
  String residency = 'Any residence',
  String category = 'All categories',
  String group = 'All schools',
  bool savedOnly = false,
}) {
  final words = query
      .toLowerCase()
      .trim()
      .split(RegExp(r'\s+'))
      .where((s) => s.isNotEmpty);
  return schools
      .where(
        (s) =>
            words.every(s.searchable.contains) &&
            (region == 'All regions' || s.region == region) &&
            (program == 'All programmes' || s.programs.contains(program)) &&
            (gender == 'All students' || s.gender == gender) &&
            (residency == 'Any residence' || s.residency.contains(residency)) &&
            (category == 'All categories' || s.category == category) &&
            (group == 'All schools' ||
                (group == 'STEM'
                    ? s.kind == 'STEM'
                    : group == 'TVET / technical'
                    ? s.kind.toLowerCase().contains('technical')
                    : group == 'International'
                    ? s.kind.toLowerCase().contains('international')
                    : s.ownership == group)) &&
            (!savedOnly || atlasStore.saved.contains(s.id)),
      )
      .toList();
}
