export 'map_stub.dart' if (dart.library.js_interop) 'map_web.dart';
