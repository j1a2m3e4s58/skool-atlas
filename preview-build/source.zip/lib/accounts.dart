import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'api_transport.dart';
import 'school.dart';

final accounts = AtlasAccounts();

class ApiFailure implements Exception {
  final int status;
  final String message;
  ApiFailure(this.status, this.message);
  @override
  String toString() => message;
}

class AtlasAccounts extends ChangeNotifier {
  Future<({Uint8List bytes, String mime})> evidence(String id) async {
    final client = createApiTransport();
    try {
      final response = await client
          .get(
            Uri.parse('$baseUrl/api/evidence/${Uri.encodeComponent(id)}'),
            headers: {
              'X-Atlas-Client': 'skool-atlas',
              if (token != null) 'Authorization': 'Bearer $token',
            },
          )
          .timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) {
        throw ApiFailure(
          response.statusCode,
          'Private evidence is unavailable or access is not permitted.',
        );
      }
      return (
        bytes: response.bodyBytes,
        mime: response.headers['content-type'] ?? 'application/octet-stream',
      );
    } finally {
      client.close();
    }
  }

  static const configuredUrl = String.fromEnvironment('ATLAS_API_URL');
  String get baseUrl => configuredUrl.isNotEmpty
      ? configuredUrl
      : kIsWeb && ['127.0.0.1', 'localhost'].contains(Uri.base.host)
      ? 'http://${Uri.base.host}:8787'
      : kIsWeb
      ? Uri.base.origin
      : '';
  Map<String, dynamic>? user;
  Map<String, dynamic> config = {};
  List<dynamic> memberships = [];
  String? token;
  bool get signedIn => user != null;
  bool get isAdmin => user?['role'] == 'admin';
  int cloudVersion = 0;
  String? connectionError;
  Future<Map<String, dynamic>> request(
    String path, {
    String method = 'GET',
    Object? data,
    Map<String, String> extraHeaders = const {},
  }) async {
    if (baseUrl.isEmpty) {
      throw ApiFailure(
        503,
        'The account server is not configured for this build.',
      );
    }
    final client = createApiTransport();
    try {
      final uri = Uri.parse('$baseUrl/api$path');
      final headers = {
        'Content-Type': 'application/json',
        'X-Atlas-Client': 'skool-atlas',
        if (token != null) 'Authorization': 'Bearer $token',
        ...extraHeaders,
      };
      final response = await (switch (method) {
        'POST' => client.post(
          uri,
          headers: headers,
          body: jsonEncode(data ?? {}),
        ),
        'PUT' => client.put(
          uri,
          headers: headers,
          body: jsonEncode(data ?? {}),
        ),
        'DELETE' => client.delete(
          uri,
          headers: headers,
          body: jsonEncode(data ?? {}),
        ),
        _ => client.get(uri, headers: headers),
      }).timeout(const Duration(seconds: 15));
      Map<String, dynamic> result;
      try {
        result = Map<String, dynamic>.from(
          jsonDecode(utf8.decode(response.bodyBytes)) as Map,
        );
      } catch (_) {
        throw ApiFailure(
          503,
          'The account service is unavailable. Your device choices are still safe.',
        );
      }
      if (response.statusCode >= 400) {
        throw ApiFailure(
          response.statusCode,
          '${result['error'] ?? 'Request failed.'}',
        );
      }
      connectionError = null;
      return result;
    } on ApiFailure {
      rethrow;
    } catch (_) {
      throw ApiFailure(
        503,
        'Could not connect to the account service. You can continue using device-only choices.',
      );
    } finally {
      client.close();
    }
  }

  Future<String> uploadEvidence(List<int> bytes, String mime) async {
    final client = createApiTransport();
    try {
      final response = await client
          .post(
            Uri.parse('$baseUrl/api/evidence'),
            headers: {
              'Content-Type': mime,
              'X-Atlas-Client': 'skool-atlas',
              if (token != null) 'Authorization': 'Bearer $token',
            },
            body: bytes,
          )
          .timeout(const Duration(seconds: 30));
      final result = jsonDecode(response.body) as Map;
      if (response.statusCode >= 400) {
        throw ApiFailure(response.statusCode, '${result['error']}');
      }
      return '${result['id']}';
    } finally {
      client.close();
    }
  }

  Future<void> load() async {
    try {
      config = await request('/config');
      try {
        final result = await request('/me');
        user = Map<String, dynamic>.from(result['user']);
        memberships = result['schools'] as List;
      } on ApiFailure catch (e) {
        if (e.status != 401) rethrow;
        token = null;
        user = null;
        memberships = [];
        cloudVersion = 0;
      }
    } catch (e) {
      connectionError = '$e';
    }
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    final result = await request(
      '/auth/login',
      method: 'POST',
      data: {'email': email, 'password': password},
    );
    token = '${result['token']}';
    user = Map<String, dynamic>.from(result['user']);
    final profile = await request('/me');
    memberships = profile['schools'] as List;
    notifyListeners();
  }

  Future<void> signOut() async {
    try {
      await request('/auth/logout', method: 'POST');
    } on ApiFailure catch (e) {
      if (e.status != 401) rethrow;
    }
    token = null;
    user = null;
    memberships = [];
    cloudVersion = 0;
    notifyListeners();
  }

  Future<Map<String, dynamic>> cloudChoices() async {
    final result = await request('/state');
    cloudVersion = (result['version'] as num).toInt();
    return result;
  }

  Future<void> uploadChoices() async {
    // Read first to avoid an unintentional overwrite from a new device.
    final result = await request(
      '/state',
      method: 'PUT',
      data: {
        'version': cloudVersion,
        'state': {
          'saved': atlasStore.saved.toList(),
          'compared': atlasStore.compared,
          'checklist': atlasStore.checklist.toList(),
        },
      },
    );
    cloudVersion = (result['version'] as num).toInt();
    notifyListeners();
  }

  Future<void> importCloudChoices(Map data, {bool merge = true}) async {
    final known = schools.map((s) => s.id).toSet();
    final saved = (data['saved'] as List? ?? [])
        .cast<String>()
        .where(known.contains)
        .toSet();
    final compared = (data['compared'] as List? ?? [])
        .cast<String>()
        .where(known.contains)
        .toList();
    await atlasStore.applyCloudState(
      saved,
      compared,
      (data['checklist'] as List? ?? []).cast<String>().toSet(),
      merge: merge,
    );
  }
}
