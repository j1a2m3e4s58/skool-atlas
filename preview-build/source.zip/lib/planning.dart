import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'school.dart';

Map<String, dynamic> reconciliation = {};
Map<String, dynamic> supportData = {};
final planningStore = PlanningStore();

Future<void> loadPlanningData() async {
  reconciliation = Map<String, dynamic>.from(
    jsonDecode(
          await rootBundle.loadString('assets/schools/reconciliation.json'),
        )
        as Map,
  );
  supportData = Map<String, dynamic>.from(
    jsonDecode(await rootBundle.loadString('assets/schools/support.json'))
        as Map,
  );
  await planningStore.load();
  for (final school in schools) {
    school.data['identityNeedsReview'] =
        (reconciliation['possibleDuplicates'] as List? ?? []).any(
          (r) =>
              (r['ids'] as List? ?? []).contains(school.id) ||
              r['code'] == school.data['code'],
        );
  }
}

String dateLabel(DateTime date) => date.toIso8601String().substring(0, 10);
bool isEvidenceUrl(String value) {
  final uri = Uri.tryParse(value.trim());
  return uri != null &&
      uri.scheme == 'https' &&
      uri.host.contains('.') &&
      uri.userInfo.isEmpty;
}

bool isValidReviewDate(String value, DateTime now) {
  final parsed = DateTime.tryParse(value);
  return RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(value) &&
      parsed != null &&
      dateLabel(parsed) == value &&
      !parsed.isAfter(DateTime(now.year, now.month, now.day));
}

bool needsFreshCheck(String value, DateTime now) {
  final date = DateTime.tryParse(value);
  return date == null || now.difference(date).inDays > 90;
}

class CareerPath {
  final String id, title, description, subjects, activity;
  final List<String> programmes, careers;
  const CareerPath(
    this.id,
    this.title,
    this.description,
    this.programmes,
    this.careers,
    this.subjects,
    this.activity,
  );
}

const careerPaths = [
  CareerPath(
    'engineering',
    'Engineering & making things',
    'Explore how structures, machines and systems work.',
    ['General Science', 'Technical', 'STEM'],
    ['Engineering', 'Architecture', 'Technical design'],
    'Ask about Elective Mathematics, Physics and relevant technical subjects.',
    'Sketch a solution to a problem in your community and explain how it would work.',
  ),
  CareerPath(
    'health',
    'Health & life sciences',
    'Explore biology, care and scientific investigation.',
    ['General Science'],
    ['Health sciences', 'Laboratory science', 'Biological research'],
    'Ask about Biology, Chemistry, Physics and Elective Mathematics. Professional programmes have specific entry rules.',
    'Interview a health professional about their training and everyday work.',
  ),
  CareerPath(
    'digital',
    'Computing & digital technology',
    'Explore coding, information systems and digital problem solving.',
    ['General Science', 'Technical', 'STEM', 'Business'],
    ['Software development', 'IT support', 'Information systems'],
    'Build mathematics, communication and computing skills; check the exact subject combination for your intended further course.',
    'Try a small coding or spreadsheet project and describe what you learned.',
  ),
  CareerPath(
    'business',
    'Business & entrepreneurship',
    'Explore how organisations manage money, customers and operations.',
    ['Business', 'General Arts'],
    ['Accounting', 'Marketing', 'Entrepreneurship'],
    'Ask about Economics, Accounting, Business Management and mathematics options.',
    'Plan a small business budget, including costs, customers and risks.',
  ),
  CareerPath(
    'creative',
    'Design, media & creative arts',
    'Explore visual communication, creativity and making a portfolio.',
    ['Visual Arts', 'General Arts', 'Technical'],
    ['Design', 'Media production', 'Creative enterprise'],
    'Ask about art and design subjects, languages and portfolio expectations.',
    'Make three original pieces and explain the choices behind each one.',
  ),
  CareerPath(
    'community',
    'Law, teaching & society',
    'Explore people, public service, communication and social issues.',
    ['General Arts', 'Languages', 'Business'],
    ['Education', 'Public service', 'Law and social sciences'],
    'Ask about languages, Literature, History, Government, Geography and Economics options.',
    'Read an issue affecting your community and write a balanced explanation.',
  ),
  CareerPath(
    'agriculture',
    'Agriculture & the environment',
    'Explore food production, living systems and sustainable resources.',
    ['Agricultural Science', 'General Science'],
    ['Agriculture', 'Food science', 'Environmental work'],
    'Ask about agricultural subjects, Biology, Chemistry, Geography and mathematics options.',
    'Keep a short observation journal of a garden, farm or local ecosystem.',
  ),
  CareerPath(
    'hospitality',
    'Food, hospitality & fashion',
    'Explore practical skills, service, nutrition and creative production.',
    ['Home Economics', 'Technical', 'Visual Arts'],
    ['Hospitality', 'Fashion and textiles', 'Food and nutrition'],
    'Ask about Food and Nutrition, Clothing and Textiles, Management in Living and relevant technical pathways.',
    'Plan a menu, garment or service, including materials, time and costs.',
  ),
];

class SchoolMatch {
  final School school;
  final List<String> reasons;
  SchoolMatch(this.school, this.reasons);
}

List<SchoolMatch> explainMatches(
  CareerPath path, {
  String region = 'All regions',
  String residence = 'Any residence',
}) {
  final matches = <SchoolMatch>[];
  for (final school in schools) {
    if (!school.selectable) continue;
    final programmes = school.programs.where(path.programmes.contains).toList();
    if (programmes.isEmpty ||
        (region != 'All regions' && school.region != region) ||
        (residence != 'Any residence' &&
            !school.residency.contains(residence))) {
      continue;
    }
    matches.add(
      SchoolMatch(school, [
        'Lists ${programmes.join(', ')} for this pathway.',
        if (region != 'All regions') 'In your selected region: $region.',
        if (residence != 'Any residence')
          'Lists your preferred residence: $residence.',
        school.data['registerYear'] == 2026
            ? 'Listed in the sourced 2026 selection register.'
            : 'Programme evidence is partial; confirm the subject combination.',
      ]),
    );
  }
  matches.sort(
    (a, b) =>
        a.school.name.toLowerCase().compareTo(b.school.name.toLowerCase()),
  );
  return matches;
}

const updateFields = [
  'Programmes',
  'Residence',
  'Location',
  'Website',
  'Contact',
  'Fees',
  'Scholarship',
  'School identity',
  'Missing school',
];

class PlanningStore extends ChangeNotifier {
  SharedPreferences? _preferences;
  final List<Map<String, dynamic>> proposals = [];
  Map<String, dynamic>? savedPlan;
  bool persistent = true;
  Future<void> load() async {
    try {
      _preferences = await SharedPreferences.getInstance();
      final raw = _preferences!.getString('atlas.updates.v1');
      final plan = _preferences!.getString('atlas.choice-plan.v1');
      if (plan != null) {
        savedPlan = Map<String, dynamic>.from(jsonDecode(plan) as Map);
      }
      if (raw != null) {
        final parsed = jsonDecode(raw) as List;
        proposals
          ..clear()
          ..addAll(parsed.map((r) => Map<String, dynamic>.from(r as Map)));
      }
    } catch (_) {
      persistent = false;
    }
  }

  Future<void> _save() async {
    try {
      if (_preferences == null ||
          !await _preferences!.setString(
            'atlas.updates.v1',
            jsonEncode(proposals),
          )) {
        persistent = false;
      }
    } catch (_) {
      persistent = false;
    }
    notifyListeners();
  }

  Future<String> propose({
    required String schoolId,
    required String schoolName,
    required String field,
    required String value,
    required String source,
    required String observed,
    required String submitter,
    required String note,
    DateTime? now,
  }) async {
    final today = now ?? DateTime.now();
    if (!updateFields.contains(field) ||
        value.trim().isEmpty ||
        schoolName.trim().isEmpty ||
        submitter.trim().isEmpty ||
        note.trim().length < 10 ||
        !isEvidenceUrl(source) ||
        !isValidReviewDate(observed, today)) {
      throw ArgumentError(
        'Provide a school, value, HTTPS evidence link, valid observation date, contributor and a note of at least 10 characters.',
      );
    }
    if (field != 'Missing school' && !schools.any((s) => s.id == schoolId)) {
      throw ArgumentError(
        'Choose an existing school or report a missing school.',
      );
    }
    if (value.length > 4000 || note.length > 2000 || proposals.length >= 500) {
      throw ArgumentError(
        'The local review workspace limit has been reached. Export the review pack first.',
      );
    }
    final id = '${today.microsecondsSinceEpoch}-${proposals.length}';
    proposals.add({
      'id': id,
      'schoolId': schoolId,
      'schoolName': schoolName.trim(),
      'field': field,
      'value': value.trim(),
      'source': source.trim(),
      'observed': observed,
      'submitter': submitter.trim(),
      'note': note.trim(),
      'submitted': today.toIso8601String(),
      'status': 'Pending review',
    });
    await _save();
    return id;
  }

  Future<void> review(
    String id, {
    required bool accept,
    required String reviewer,
    required String note,
    required bool evidenceChecked,
    DateTime? now,
  }) async {
    final item = proposals.singleWhere((p) => p['id'] == id);
    if (item['status'] != 'Pending review') {
      throw StateError('This proposal already has a review record.');
    }
    if (!evidenceChecked ||
        reviewer.trim().isEmpty ||
        note.trim().length < 10) {
      throw ArgumentError(
        'Record the reviewer, evidence check and a review note of at least 10 characters.',
      );
    }
    item.addAll({
      'status': accept ? 'Locally reviewed' : 'Rejected',
      'reviewer': reviewer.trim(),
      'reviewNote': note.trim(),
      'reviewed': (now ?? DateTime.now()).toIso8601String(),
      'identityVerified': false,
      'published': false,
    });
    await _save();
  }

  String exportReviewPack() => const JsonEncoder.withIndent('  ').convert({
    'schema': 'skool-atlas-review-pack-v1',
    'exported': DateTime.now().toIso8601String(),
    'scope':
        'Local evidence-review records. Reviewer identity is not authenticated. Nothing in this file is automatically published.',
    'proposals': proposals,
  });
  Future<void> savePlan(Map<String, dynamic> plan) async {
    savedPlan = Map<String, dynamic>.from(jsonDecode(jsonEncode(plan)) as Map);
    try {
      if (_preferences == null ||
          !await _preferences!.setString(
            'atlas.choice-plan.v1',
            jsonEncode(plan),
          )) {
        persistent = false;
      }
    } catch (_) {
      persistent = false;
    }
    notifyListeners();
  }

  Future<void> forgetPlan() async {
    savedPlan = null;
    try {
      await _preferences?.remove('atlas.choice-plan.v1');
    } catch (_) {
      persistent = false;
    }
    notifyListeners();
  }
}

const coreSubjects = [
  'English Language',
  'Mathematics',
  'Science',
  'Social Studies',
];
const otherSubjects = [
  'Arabic',
  'Computing',
  'Religious & Moral Education',
  'Ghanaian Language',
  'French',
  'Creative Arts & Design',
  'Career Technology',
];
const selectionManualUrl =
    'https://www.cssps.gov.gh/index.php/candidate-manual';
const selectionRegisterUrl =
    'https://ghanaeducation.org/wp-content/uploads/2026/07/FINAL-2026-SENIOR-HIGH-SCHOOL-REGISTER.pdf';

int resultsAggregate(Map<String, int> grades) {
  if (!coreSubjects.every(grades.containsKey) ||
      grades.values.any((g) => g < 1 || g > 9)) {
    throw ArgumentError(
      'Enter grades 1-9 for all four core subjects and at least two other subjects.',
    );
  }
  final other =
      grades.entries
          .where((e) => otherSubjects.contains(e.key))
          .map((e) => e.value)
          .toList()
        ..sort();
  if (other.length < 2) {
    throw ArgumentError('Enter at least two other subject grades.');
  }
  return coreSubjects.map((s) => grades[s]!).reduce((a, b) => a + b) +
      other[0] +
      other[1];
}

List<({String programme, double average, List<String> subjects})>
gradeStudyPaths(Map<String, int> grades) {
  final groups = {
    'General Science': ['Mathematics', 'Science'],
    'Business': ['Mathematics', 'English Language', 'Social Studies'],
    'General Arts': ['English Language', 'Social Studies', 'Ghanaian Language'],
    'Visual Arts': ['Creative Arts & Design', 'English Language'],
    'Technical': ['Mathematics', 'Career Technology'],
    'Home Economics': ['Career Technology', 'Science'],
    'Agricultural Science': ['Science', 'Career Technology'],
  };
  final result =
      <({String programme, double average, List<String> subjects})>[];
  for (final entry in groups.entries) {
    final available = entry.value.where(grades.containsKey).toList();
    if (available.length < 2) continue;
    result.add((
      programme: entry.key,
      average:
          available.map((s) => grades[s]!).reduce((a, b) => a + b) /
          available.length,
      subjects: available,
    ));
  }
  result.sort((a, b) {
    final difference = a.average.compareTo(b.average);
    return difference == 0 ? a.programme.compareTo(b.programme) : difference;
  });
  return result;
}

bool townMatches(School school, String town) {
  if (town.trim().length < 2) return false;
  String normalise(String value) =>
      value.toLowerCase().trim().replaceAll(RegExp(r'\s+'), ' ');
  // Only the locality component can establish a town match. District/region
  // names later in the address must not make a distant school look nearby.
  return normalise(school.location.split(',').first) == normalise(town);
}

bool localDayCandidate(School school, String region, String town, String district) =>
    school.region == region &&
    school.residency.contains('Day') &&
    (townMatches(school, town) ||
        district.trim().isNotEmpty && school.data['district'] == district);

List<SchoolMatch> resultsSchoolOptions({
  required String programme,
  required String region,
  required String district,
  required String town,
  required String gender,
  String scope = 'Region & boarding',
  String query = '',
}) {
  final list = <SchoolMatch>[];
  for (final school in schools) {
    if (!school.selectable ||
        school.data['registerYear'] != 2026 ||
        !school.programs.contains(programme)) {
      continue;
    }
    if (gender == 'Male' && school.gender == 'Girls' ||
        gender == 'Female' && school.gender == 'Boys') {
      continue;
    }
    if (query.trim().isNotEmpty &&
        !query
            .toLowerCase()
            .trim()
            .split(RegExp(r'\s+'))
            .every(school.searchable.contains)) {
      continue;
    }
    final localTown = school.region == region && townMatches(school, town);
    final localDistrict =
        school.region == region &&
        district.isNotEmpty &&
        school.data['district'] == district;
    if (scope == 'Nearby day schools' &&
        (!school.residency.contains('Day') || !(localTown || localDistrict))) {
      continue;
    }
    if (scope == 'Day schools in my region' &&
        (!school.residency.contains('Day') || school.region != region)) {
      continue;
    }
    if (scope == 'Boarding across Ghana' &&
        !school.residency.contains('Boarding')) {
      continue;
    }
    if (scope == 'Region & boarding' &&
        school.region != region &&
        !school.residency.contains('Boarding')) {
      continue;
    }
    list.add(
      SchoolMatch(school, [
        'Lists $programme in the school programme data.',
        if (school.data['publicProgrammeReview'] is Map)
          'Official vacancy snapshot checked ${(school.data['publicProgrammeReview'] as Map)['observed']}; confirm the current programme and code on CSSPS. This snapshot is not a complete course register.',
        if (localTown)
          'The listed campus town matches your town; check the actual route.'
        else if (localDistrict)
          'In your selected district; daily travel still needs checking.'
        else if (school.region == region)
          'In your home region; proximity is not measured.'
        else
          'A boarding option outside your home region.',
        'Selection group: ${school.categoryLabel}. This is not a grade cut-off.',
        if (school.identityNeedsReview)
          'School identity is under review. Confirm the exact campus before choosing.',
        if (school.data['registerCodeConflict'] == true)
          'The printed code conflicts with another listing; ask your JHS to confirm it.',
        'Ordered by town/district/region match, then name; not by admission probability or school quality.',
      ]),
    );
  }
  int locality(School s) => s.region != region
      ? 3
      : townMatches(s, town)
      ? 0
      : s.data['district'] == district && district.isNotEmpty
      ? 1
      : 2;
  list.sort((a, b) {
    final compare = locality(a.school).compareTo(locality(b.school));
    return compare == 0
        ? a.school.name.toLowerCase().compareTo(b.school.name.toLowerCase())
        : compare;
  });
  return list;
}

class SchoolChoice {
  final String schoolId;
  String programme, residence, pilotCategory;
  bool commuteConfirmed, codeConfirmed, catchmentConfirmed;
  String reviewedSignature;
  SchoolChoice({
    required this.schoolId,
    required this.programme,
    required this.residence,
    this.pilotCategory = 'Category C',
    this.commuteConfirmed = false,
    this.catchmentConfirmed = false,
    this.codeConfirmed = false,
    this.reviewedSignature = '',
  });
  School? get school {
    for (final s in schools) {
      if (s.id == schoolId ||
          (s.data['legacyIds'] as List? ?? []).contains(schoolId)) {
        return s;
      }
    }
    return null;
  }

  String get selectionCategory => school?.category == 'Pilot private'
      ? pilotCategory
      : school?.category ?? 'Not confirmed';
  Map<String, dynamic> toJson() => {
    'schoolId': school?.id ?? schoolId,
    'programme': programme,
    'residence': residence,
    'pilotCategory': pilotCategory,
    'commuteConfirmed': commuteConfirmed,
    'catchmentConfirmed': catchmentConfirmed,
    'codeConfirmed': codeConfirmed,
    'reviewedSignature': reviewedSignature,
  };
  factory SchoolChoice.fromJson(Map data) => SchoolChoice(
    schoolId: '${data['schoolId']}',
    programme: '${data['programme']}',
    residence: '${data['residence']}',
    pilotCategory: '${data['pilotCategory'] ?? 'Category C'}',
    commuteConfirmed: data['commuteConfirmed'] == true,
    catchmentConfirmed: data['catchmentConfirmed'] == true,
    codeConfirmed: data['codeConfirmed'] == true,
    reviewedSignature: '${data['reviewedSignature'] ?? ''}',
  );
}

class ChoiceCheck {
  final String code, message;
  final bool error;
  ChoiceCheck(this.code, this.message, {this.error = true});
}

List<SchoolChoice> buildSuggestedChoices({
  required List<School> options,
  required String programme,
  required String region,
  required String town,
  required String gender,
  String district = '',
  String style = 'Balanced categories',
  String scope = 'Region & boarding',
}) {
  final draft = <SchoolChoice>[];
  if (!['Male', 'Female'].contains(gender)) return draft;
  final dayOnly =
      style == 'Day-only draft' || scope.toLowerCase().contains('day');
  final categories = style == 'Category C focus'
      ? ['Category C']
      : ['Category A', 'Category B', 'Category C'];
  final candidates = options
      .where(
        (s) =>
            s.selectable &&
            s.data['registerYear'] == 2026 &&
            s.programs.contains(programme) &&
            !s.identityNeedsReview &&
            s.data['registerCodeConflict'] != true &&
            categories.contains(s.category),
      )
      .toList();
  bool add(School school, String residence) {
    if (draft.length >= 8 ||
        draft.any((c) => c.schoolId == school.id) ||
        !school.residency.contains(residence) ||
        residence == 'Day' && !localDayCandidate(school, region, town, district)) {
      return false;
    }
    final choice = SchoolChoice(
      schoolId: school.id,
      programme: programme,
      residence: residence,
      reviewedSignature: school.selectionSignature,
    );
    const blocking = [
      'duplicate',
      'boarding',
      'category-a',
      'category-a-boarding',
      'category-b',
      'category-b-boarding',
      'gender',
      'programme',
      'residence',
    ];
    if (validateSchoolChoices(
      [...draft, choice],
      gender: gender,
      town: town,
      region: region,
    ).any((c) => c.error && blocking.contains(c.code))) {
      return false;
    }
    draft.add(choice);
    return true;
  }

  // Reserve local Day candidates; never fill a Day quota with distant schools
  // merely because they share the student's region. A partial draft is safer.
  for (final category in categories) {
    for (final school in candidates.where((s) => s.category == category)) {
      if (add(school, 'Day')) break;
    }
  }
  for (final school in candidates) {
    if (draft.length >= 3) break;
    add(school, 'Day');
  }
  if (!dayOnly) {
    for (final category in categories) {
      for (final school in candidates.where((s) => s.category == category)) {
        add(school, 'Boarding');
      }
    }
  }
  for (final school in candidates) {
    add(school, 'Day');
  }
  return arrangeSchoolChoices(draft);
}

List<SchoolChoice> arrangeSchoolChoices(List<SchoolChoice> choices) {
  const rank = {'Category A': 0, 'Category B': 1, 'Category C': 2};
  final indexed = choices.asMap().entries.toList();
  indexed.sort((a, b) {
    final category = (rank[a.value.selectionCategory] ?? 3).compareTo(
      rank[b.value.selectionCategory] ?? 3,
    );
    if (category != 0) return category;
    final residence = (a.value.residence == 'Day' ? 1 : 0).compareTo(
      b.value.residence == 'Day' ? 1 : 0,
    );
    return residence != 0 ? residence : a.key.compareTo(b.key);
  });
  return indexed.map((entry) => entry.value).toList();
}

List<ChoiceCheck> validateSchoolChoices(
  List<SchoolChoice> choices, {
  required String gender,
  required String town,
  required String region,
  String track = 'General',
  DateTime? now,
}) {
  final issues = <ChoiceCheck>[];
  if (choices.length != 8) {
    issues.add(
      ChoiceCheck(
        'count',
        'Choose exactly eight different schools. You currently have ${choices.length}.',
      ),
    );
  }
  if (choices.map((c) => c.school?.id ?? c.schoolId).toSet().length !=
      choices.length) {
    issues.add(
      ChoiceCheck(
        'duplicate',
        'A school can appear only once, even with a different programme or residence.',
      ),
    );
  }
  if (choices.where((c) => c.residence == 'Boarding').length > 5) {
    issues.add(
      ChoiceCheck(
        'boarding',
        'Choose at most five Boarding options. All eight choices may be Day.',
      ),
    );
  }
  if (choices.where((c) => c.selectionCategory == 'Category A').length > 2) {
    issues.add(
      ChoiceCheck('category-a', 'Choose at most two Category A schools.'),
    );
  }
  if (choices
          .where(
            (c) =>
                c.selectionCategory == 'Category A' &&
                c.residence == 'Boarding',
          )
          .length >
      1) {
    issues.add(
      ChoiceCheck(
        'category-a-boarding',
        'Choose at most one Category A Boarding option.',
      ),
    );
  }
  if (choices.where((c) => c.selectionCategory == 'Category B').length > 3) {
    issues.add(
      ChoiceCheck('category-b', 'Choose at most three Category B schools.'),
    );
  }
  if (choices
          .where(
            (c) =>
                c.selectionCategory == 'Category B' &&
                c.residence == 'Boarding',
          )
          .length >
      2) {
    issues.add(
      ChoiceCheck(
        'category-b-boarding',
        'Choose at most two Category B Boarding options.',
      ),
    );
  }
  if (town.trim().isEmpty || region.isEmpty) {
    issues.add(
      ChoiceCheck(
        'location',
        'Enter your home town and region so you can review day-school travel.',
      ),
    );
  }
  for (var i = 0; i < choices.length; i++) {
    final choice = choices[i], school = choices[i].school;
    final prefix = 'Choice ${i + 1}';
    if (school == null) {
      issues.add(
        ChoiceCheck(
          'unknown-school',
          '$prefix: this school is no longer in the current catalogue.',
        ),
      );
      continue;
    }
    if (!school.selectable) {
      issues.add(
        ChoiceCheck(
          'school-status',
          '$prefix: this school is marked ${school.data['status']}. Confirm its current operation before selecting it.',
        ),
      );
    }
    if (school.data['registerYear'] != 2026) {
      // An archive listing alone is not current selection evidence.
      issues.add(
        ChoiceCheck(
          'register',
          '$prefix: confirm this school is eligible on the current official selection form.',
        ),
      );
    }
    if (choice.reviewedSignature.isNotEmpty &&
        choice.reviewedSignature != school.selectionSignature) {
      issues.add(
        ChoiceCheck(
          'school-changed',
          '$prefix: school programmes, code, category, residence or eligibility changed since you reviewed this choice. Review the current details again.',
        ),
      );
    }
    if (school.identityNeedsReview) {
      issues.add(
        ChoiceCheck(
          'identity-review',
          '$prefix: the campus identity needs source review. Ask your JHS to confirm the exact school.',
          error: false,
        ),
      );
    }
    if (!school.programs.contains(choice.programme)) {
      issues.add(
        ChoiceCheck(
          'programme',
          '$prefix: the chosen programme is not listed for this school.',
        ),
      );
    }
    if (!['Day', 'Boarding'].contains(choice.residence) ||
        !school.residency.contains(choice.residence)) {
      issues.add(
        ChoiceCheck(
          'residence',
          '$prefix: the chosen residence is not listed for this school.',
        ),
      );
    }
    if (choice.residence == 'Day' && !choice.commuteConfirmed) {
      issues.add(
        ChoiceCheck(
          'commute',
          '$prefix: confirm with your guardian that daily travel is realistic. Town/district matching alone does not prove catchment eligibility.',
        ),
      );
    }
    if (choice.residence == 'Day' && !choice.catchmentConfirmed) {
      issues.add(
        ChoiceCheck(
          'catchment',
          '$prefix: ask your JHS or the school office to confirm the current Day/catchment eligibility. A map route or matching town name is not official confirmation.',
        ),
      );
    }
    if (school.category == 'Pilot private' &&
        (choice.residence != 'Day' ||
            !['Category B', 'Category C'].contains(choice.pilotCategory))) {
      issues.add(
        ChoiceCheck(
          'pilot-private',
          '$prefix: the sourced register allows pilot private selections as Category B/C Day.',
        ),
      );
    }
    if (![
      'Category A',
      'Category B',
      'Category C',
    ].contains(choice.selectionCategory)) {
      issues.add(
        ChoiceCheck(
          'category',
          '$prefix: the selection category needs confirmation.',
        ),
      );
    }
    if (gender == 'Male' && school.gender == 'Girls' ||
        gender == 'Female' && school.gender == 'Boys') {
      issues.add(
        ChoiceCheck(
          'gender',
          '$prefix: the school gender does not match the candidate record you entered.',
        ),
      );
    }
    if (school.data['registerCodeConflict'] == true && !choice.codeConfirmed) {
      issues.add(
        ChoiceCheck(
          'code',
          '$prefix: the sourced register has a code conflict. Confirm the exact school code with your JHS / school office.',
        ),
      );
    }
    if (track == 'TVET only' && school.kind != 'TVET / technical') {
      issues.add(
        ChoiceCheck(
          'tvet-track',
          '$prefix: a purely TVET plan must use TVET institutions.',
        ),
      );
    }
    if (track == 'Science / STEM' &&
        !['General Science', 'STEM'].contains(choice.programme)) {
      issues.add(
        ChoiceCheck(
          'stem-track',
          '$prefix: the sourced Science / STEM track requires Science / STEM programme choices.',
        ),
      );
    }
  }
  if (gender == 'Not entered') {
    issues.add(
      ChoiceCheck(
        'gender-unconfirmed',
        'Confirm school gender eligibility against the official candidate record.',
        error: false,
      ),
    );
  }
  final today = now ?? DateTime.now();
  if (today.year != 2026 || needsFreshCheck('2026-10-16', today)) {
    issues.add(
      ChoiceCheck(
        'rules-age',
        'These are the rules checked on 16 October 2026. Recheck the current CSSPS manual before using this plan.',
        error: false,
      ),
    );
  }
  return issues;
}

String schoolShareText(List<School> selected, {Uri? base}) {
  final origin = base ?? Uri.base;
  final link = origin
      .replace(
        path: '/',
        queryParameters: {
          'compare': selected.take(3).map((s) => s.id).join(','),
        },
        fragment: '',
      )
      .toString();
  return 'Our Skool Atlas choices\n\n${selected.map((s) => '${s.name}\n${s.region} | ${s.residency}\nProgrammes: ${s.programs.join(', ')}').join('\n\n')}\n\nDiscuss subject combinations, travel, costs and support with your family and guidance teacher.\n${origin.host == '127.0.0.1' || origin.host == 'localhost' ? 'This preview link only works on the hosting computer. Share the downloaded HTML/PDF file with other people.' : 'View up to three choices: $link'}\nSnapshot: ${dateLabel(DateTime.now())}. Confirm current details with each school.';
}

String htmlEscape(Object? value) =>
    const HtmlEscape(HtmlEscapeMode.element).convert('$value');
String htmlAttribute(Object? value) =>
    const HtmlEscape(HtmlEscapeMode.attribute).convert('$value');
Future<String> offlineSchoolPack(
  List<School> selected, {
  bool photos = true,
  List<SchoolChoice>? choices,
  List<String> requirements = const [],
}) async {
  final cards = <String>[];
  for (final school in selected) {
    String image = '';
    if (photos && school.images.isNotEmpty) {
      final bytes = await rootBundle.load(school.images.first);
      image =
          '<img alt="${htmlAttribute(school.name)} photograph" src="data:${school.images.first.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg'};base64,${base64Encode(bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes))}">';
    }
    final details =
        ((supportData['schools'] as Map?)?[school.id] as List? ?? [])
            .cast<Map>();
    cards.add(
      '<article>$image<h2>${htmlEscape(school.name)}</h2><p>${htmlEscape(school.region)} | ${htmlEscape(school.ownership)} | ${htmlEscape(school.categoryLabel)}</p><dl><dt>Location</dt><dd>${htmlEscape(school.location)}</dd><dt>Residence</dt><dd>${htmlEscape(school.residency)} (${htmlEscape(school.data['residencyNote'] ?? 'Confirm current availability')})</dd><dt>Programmes</dt><dd>${htmlEscape(school.programs.join(', '))}</dd></dl><p>${htmlEscape(school.description)}</p><h3>Practical information</h3>${details.isEmpty ? '<p>No dated fee or contact records added yet. Ask the school directly.</p>' : details.map((d) => '<p><strong>${htmlEscape(d['title'])}</strong>: ${htmlEscape(d['detail'])}<br>Observed ${htmlEscape(d['observed'])}; ${htmlEscape(d['period'])}</p>').join()}<h3>Achievements & participation</h3>${school.achievements.isEmpty ? '<p>No reviewed achievement records added yet.</p>' : school.achievements.map((a) => '<p>${htmlEscape(a['year'])}: ${htmlEscape(a['title'])} - ${htmlEscape(a['result'])}</p>').join()}<h3>Discussion notes</h3><textarea aria-label="Discussion notes for ${htmlAttribute(school.name)}" placeholder="Questions about subjects, residence, costs, travel and learning support"></textarea><h3>Sources (internet needed to open)</h3><ul>${school.sources.where((s) => isEvidenceUrl('${s['url']}')).map((s) => '<li><a href="${htmlAttribute(s['url'])}" rel="noopener noreferrer">${htmlEscape(s['label'])}</a></li>').join()}</ul></article>',
    );
  }
  final ordered = choices == null
      ? ''
      : '<article><h2>Ordered school-choice draft</h2><p>Order matters. Confirm programme, residence, category and school code with the current CSSPS guidance.</p><table><thead><tr><th>Choice</th><th>School</th><th>Programme</th><th>Residence</th></tr></thead><tbody>${choices.asMap().entries.map((e) => '<tr><td>${e.key + 1}</td><td>${htmlEscape(e.value.school?.name ?? e.value.schoolId)}</td><td>${htmlEscape(e.value.programme)}</td><td>${htmlEscape(e.value.residence)}</td></tr>').join()}</tbody></table></article>';
  final reviewNotice = choices == null
      ? ''
      : '<article><h2>Unverified planning draft</h2><p>This file is not an official selection form or admission decision. Review current school codes, programmes, catchment and all requirements with your JHS/guardian before official submission.</p>${requirements.isEmpty ? '<p>No outstanding coded requirements were supplied. Official checks are still required.</p>' : '<ul>${requirements.map((r) => '<li>${htmlEscape(r)}</li>').join()}</ul>'}</article>';
  return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Skool Atlas | Our school choices</title><style>body{font:16px/1.6 Arial,sans-serif;margin:0;background:#f4f6f8;color:#162b66}header,main{max-width:1050px;margin:auto;padding:24px}header{background:#162b66;color:white;max-width:none}header div{max-width:1050px;margin:auto}article{background:white;border:1px solid #dce3ef;border-radius:18px;padding:24px;margin:20px 0;break-inside:avoid}h1,h2,h3{line-height:1.25}img{width:100%;max-height:280px;object-fit:cover;border-radius:12px}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px;border-bottom:1px solid #ccd5e5}dt{font-weight:bold}dd{margin:0 0 12px}textarea{box-sizing:border-box;width:100%;min-height:110px;font:inherit;border:1px solid #ccd5e5;padding:12px}button{padding:12px 18px;border:0;border-radius:10px;background:white;color:#162b66;font-weight:bold;cursor:pointer}@media print{body{background:white}header{background:white;color:#162b66}button{display:none}article{border-color:#bbb}a{color:#162b66}}</style></head><body><header><div><h1>Our school choices</h1><p>Skool Atlas | ${selected.length} schools | Snapshot ${dateLabel(DateTime.now())}</p><p>This saved file works offline, including the embedded photographs. External source links need internet. Information can change; confirm with the school.</p><button onclick="window.print()">Print / save as PDF</button></div></header><main>$reviewNotice$ordered${cards.join()}<p>For discussion with family and guidance teachers. This is not an official CSSPS selection form or an admission prediction. No student credentials are included.</p></main></body></html>';
}
