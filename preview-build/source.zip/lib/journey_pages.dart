part of 'main.dart';

class LaunchReadinessPage extends StatefulWidget {
  const LaunchReadinessPage({super.key});
  @override
  State<LaunchReadinessPage> createState() => _LaunchReadinessPageState();
}

class _LaunchReadinessPageState extends State<LaunchReadinessPage> {
  late Future<Map<String, dynamic>> health = accounts.request('/health');
  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
    title: 'Launch readiness',
    subtitle:
        'A healthy local service is not proof of a finished public release.',
    children: [
      FutureBuilder<Map<String, dynamic>>(
        future: health,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return InfoPanel(
              title: 'Readiness service unavailable',
              text:
                  'Check the local API connection and retry. No launch approval can be inferred while this check is unavailable.',
            );
          }
          if (!snapshot.hasData) {
            return const Surface(
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final data = snapshot.data!;
          return Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data['productionReady'] == true
                      ? 'Recorded service gates pass'
                      : 'Public launch is not ready',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Text('Service mode: ${data['mode']}'),
                const SizedBox(height: 12),
                for (final missing in data['missing'] as List? ?? [])
                  ListTile(
                    leading: const Icon(Icons.pending_outlined),
                    title: Text('$missing'),
                  ),
                const SizedBox(height: 12),
                const Text(
                  'These are configuration/evidence checks. The owner must retain the actual device, restore, support and pilot reports; entering a date does not perform a test. School identity conflicts and store approval are checked separately in the release report.',
                ),
              ],
            ),
          );
        },
      ),
      OutlinedButton.icon(
        onPressed: () => setState(() => health = accounts.request('/health')),
        icon: const Icon(Icons.refresh),
        label: const Text('Refresh readiness'),
      ),
    ],
  );
}

class DraftProgressPanel extends StatelessWidget {
  final List<SchoolChoice> choices;
  final List<ChoiceCheck> checks;
  const DraftProgressPanel({
    super.key,
    required this.choices,
    required this.checks,
  });
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${choices.length} of 8 choices',
          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 12),
        LinearProgressIndicator(
          value: (choices.length / 8).clamp(0, 1),
          minHeight: 7,
          borderRadius: BorderRadius.circular(8),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final category in ['Category A', 'Category B', 'Category C'])
              TagChip(
                label:
                    '$category: ${choices.where((c) => c.selectionCategory == category).length}',
              ),
            TagChip(
              label:
                  'Day: ${choices.where((c) => c.residence == 'Day').length}',
            ),
            TagChip(
              label:
                  'Boarding: ${choices.where((c) => c.residence == 'Boarding').length}',
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          '${checks.where((c) => c.error).length} requirements need review. Exporting saves an unverified draft; it does not submit choices or confirm admission.',
          style: TextStyle(color: context.atlas.muted),
        ),
      ],
    ),
  );
}

class AtlasPrimaryNavigation extends StatelessWidget {
  final int selectedPage;
  final ValueChanged<int> onNavigate;
  const AtlasPrimaryNavigation({
    super.key,
    required this.selectedPage,
    required this.onNavigate,
  });
  static const pages = [0, 1, 9, 8];
  @override
  Widget build(BuildContext context) => NavigationBar(
    selectedIndex: pages.contains(selectedPage)
        ? pages.indexOf(selectedPage)
        : [2, 6, 7].contains(selectedPage)
        ? 2
        : 0,
    onDestinationSelected: (i) => onNavigate(pages[i]),
    labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    destinations: const [
      NavigationDestination(
        icon: Icon(Icons.home_outlined),
        selectedIcon: Icon(Icons.home_rounded),
        label: 'Home',
      ),
      NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Explore'),
      NavigationDestination(
        icon: Icon(Icons.bookmarks_outlined),
        label: 'My choices',
      ),
      NavigationDestination(
        icon: Icon(Icons.calculate_outlined),
        label: 'Results',
      ),
    ],
  );
}

class MyChoicesHub extends StatelessWidget {
  final VoidCallback onExplore, onResults;
  const MyChoicesHub({
    super.key,
    required this.onExplore,
    required this.onResults,
  });
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([atlasStore, planningStore]),
    builder: (context, _) => PageFrame(
      title: 'Your school choices',
      subtitle: 'Keep your shortlist, comparison and ordered draft together.',
      children: [
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PanelHeading(
                icon: Icons.bookmarks_outlined,
                title: '${atlasStore.saved.length} saved schools',
              ),
              const SizedBox(height: 12),
              const Text(
                'Save schools you like and compare up to three. Your shortlist is separate from your eight-choice plan.',
              ),
              const SizedBox(height: 16),
              BalancedActions(
                key: const ValueKey('shortlist-actions'),
                children: [
                  FilledButton.icon(
                    onPressed: () => openPlanningTool(
                      context,
                      const ExplorePage(savedOnly: true),
                      'Saved schools',
                    ),
                    icon: const Icon(Icons.bookmark_outline),
                    label: const Text('Open shortlist'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => openPlanningTool(
                      context,
                      ComparePage(
                        onAddMore: () {
                          Navigator.pop(context);
                          onExplore();
                        },
                      ),
                      'Compare schools',
                    ),
                    icon: const Icon(Icons.compare_arrows),
                    label: const Text('Compare schools'),
                  ),
                ],
              ),
            ],
          ),
        ),
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PanelHeading(
                icon: Icons.checklist_rounded,
                title: 'Your eight-choice draft',
              ),
              const SizedBox(height: 10),
              Text(
                planningStore.savedPlan == null
                    ? 'No draft saved on this device yet. Start with your grades or browse programmes.'
                    : 'A draft is saved on this device. Recheck current programmes and all outstanding requirements before using it.',
              ),
              const SizedBox(height: 16),
              BalancedActions(
                children: [
                  FilledButton.icon(
                    onPressed: onResults,
                    icon: const Icon(Icons.calculate_outlined),
                    label: const Text('Open results planner'),
                  ),
                  if (planningStore.savedPlan != null)
                    OutlinedButton.icon(
                      onPressed: () => openPlanningTool(
                        context,
                        const ResultsPlannerPage(resumeSaved: true),
                        'Resume saved draft',
                      ),
                      icon: const Icon(Icons.restore_rounded),
                      label: const Text('Resume saved draft'),
                    ),
                ],
              ),
            ],
          ),
        ),
        const PlanningHub(includePlanner: false),
      ],
    ),
  );
}

class ToolsWorkspacePage extends StatelessWidget {
  const ToolsWorkspacePage({super.key});
  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
    title: 'Help & tools',
    subtitle:
        'Guides for families, with school-management tools kept in their own workspace.',
    children: [
      Surface(
        child: Column(
          children: [
            for (final item in <(String, IconData, Widget)>[
              (
                'Guides & checklist',
                Icons.menu_book_outlined,
                const GuidesPage(),
              ),
              (
                'Official resources & pilot',
                Icons.folder_outlined,
                const ResourcesPage(),
              ),
              (
                'BECE & placement',
                Icons.verified_outlined,
                const PlacementCheckerPage(),
              ),
              (
                'Account & sync',
                Icons.account_circle_outlined,
                const AccountPage(),
              ),
              (
                'Privacy, terms & help',
                Icons.privacy_tip_outlined,
                const PrivacyHelpPage(),
              ),
            ])
              ListTile(
                leading: Icon(item.$2),
                title: Text(item.$1),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => openPlanningTool(context, item.$3, item.$1),
              ),
          ],
        ),
      ),
      Surface(
        child: ExpansionTile(
          title: const Text('School & administrator workspace'),
          subtitle: const Text(
            'Source review and school submissions; restricted actions still require approved accounts.',
          ),
          children: [
            ListTile(
              title: const Text('Launch readiness'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => openPlanningTool(
                context,
                const LaunchReadinessPage(),
                'Launch readiness',
              ),
            ),
            ListTile(
              title: const Text('Source coverage'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => openPlanningTool(
                context,
                const SourceCoveragePage(),
                'Source coverage',
              ),
            ),
            ListTile(
              title: const Text('School updates & register review'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => openPlanningTool(
                context,
                const SchoolPortalPage(),
                'School workspace',
              ),
            ),
          ],
        ),
      ),
    ],
  );
}
