import 'dart:math' as math;
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'school.dart';
import 'map_preview.dart';
import 'planning.dart';
import 'local_export.dart';
import 'website_content.dart';
import 'package:video_player/video_player.dart';
import 'video_embed.dart';
import 'accounts.dart';
import 'published_updates.dart';
import 'package:file_selector/file_selector.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'appearance.dart';

part 'app_pages.dart';
part 'planning_pages.dart';
part 'results_planner.dart';
part 'website_pages.dart';
part 'account_pages.dart';
part 'sharing_pages.dart';
part 'media_pages.dart';
part 'school_quality.dart';
part 'pilot_pages.dart';
part 'journey_pages.dart';

final atlasShellKey = GlobalKey<_MainShellState>();

void returnToAtlasHome(BuildContext context) {
  atlasShellKey.currentState?.navigate(0);
  Navigator.of(context).popUntil((route) => route.isFirst);
}

AppBar atlasPageBar(BuildContext context, String title) => AppBar(
  automaticallyImplyLeading: true,
  actions: const [AppearanceButton(), SizedBox(width: 8)],
  title: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisSize: MainAxisSize.min,
    children: [
      InkWell(
        onTap: () => returnToAtlasHome(context),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/branding/launcher-mark.png',
                width: 25,
                height: 25,
                excludeFromSemantics: true,
              ),
              const SizedBox(width: 7),
              const Text(
                'Skool Atlas',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
      Text(
        title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 12, color: AppColors.muted),
      ),
    ],
  ),
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  PaintingBinding.instance.imageCache
    ..maximumSize = 120
    ..maximumSizeBytes = 48 * 1024 * 1024;
  await atlasAppearance.load();
  runApp(const SkoolAtlasApp());
}

class SkoolAtlasApp extends StatelessWidget {
  const SkoolAtlasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: atlasAppearance,
      builder: (context, _) => MaterialApp(
        title: 'Skool Atlas',
        debugShowCheckedModeBanner: false,
        theme: atlasTheme(Brightness.light),
        darkTheme: atlasTheme(Brightness.dark),
        themeMode: atlasAppearance.mode,
        home: const AtlasBootstrap(),
      ),
    );
  }
}

class AppColors {
  // Main navy colors
  static const primary = Color(0xFF1E3A8A);
  static const primaryDark = Color(0xFF162B66);
  static const primarySoft = Color(0xFFE8EDFA);

  // Extra accents
  static const accent = Color(0xFF3B82F6);
  static const success = Color(0xFF2563EB);
  static const danger = Color(0xFFDC2626);

  // Neutrals
  static const dark = Color(0xFF0F172A);
  static const muted = Color(0xFF64748B);
  static const border = Color(0xFFE2E8F0);
  static const chipBg = Color(0xFFEAF1FF);
  static const cardBg = Colors.white;
  static const lightBg = Color(0xFFF8FAFC);
}

class HoverLift extends StatefulWidget {
  final Widget child;
  final double translateY;
  final Duration duration;

  const HoverLift({
    super.key,
    required this.child,
    this.translateY = -6,
    this.duration = const Duration(milliseconds: 180),
  });

  @override
  State<HoverLift> createState() => _HoverLiftState();
}

class _HoverLiftState extends State<HoverLift> {
  bool isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          isHovered = true;
        });
      },
      onExit: (_) {
        setState(() {
          isHovered = false;
        });
      },
      child: AnimatedContainer(
        duration: widget.duration,
        transform: Matrix4.identity()
          ..translateByDouble(
            0.0,
            isHovered ? widget.translateY : 0.0,
            0.0,
            1.0,
          ),
        child: widget.child,
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedPage = 0, homeRevision = 0;
  final pageHistory = <int>[];
  final visitedPages = <int>{0};
  @override
  void initState() {
    super.initState();
    final planId = Uri.base.queryParameters['plan'];
    final requestedTool = Uri.base.queryParameters['tool'];
    if (planId == null && ['results', 'pilot'].contains(requestedTool)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          openPlanningTool(
            context,
            requestedTool == 'pilot'
                ? const PilotFeedbackPage()
                : const ResultsPlannerPage(),
            requestedTool == 'pilot'
                ? 'Pilot tasks & feedback'
                : 'Find schools with my grades',
          );
        }
      });
    }
    if (planId != null) {
      final keys = Uri.splitQueryString(Uri.base.fragment);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          openPlanningTool(
            context,
            SharedOnlinePlanPage(
              id: planId,
              access: keys['access'] ?? '',
              review: keys['review'],
            ),
            'Shared school draft',
          );
        }
      });
    }
    final ids = (Uri.base.queryParameters['compare'] ?? '')
        .split(',')
        .take(3)
        .toSet();
    final shared = schools.where((s) => ids.contains(s.id)).toList();
    if (shared.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          openPlanningTool(
            context,
            SharedChoicesPage(selected: shared),
            'Shared school choices',
          );
        }
      });
    }
  }

  void navigate(int page) => setState(() {
    if (page == 0) {
      pageHistory.clear();
      homeRevision++;
    } else if (page != selectedPage) {
      pageHistory.add(selectedPage);
    }
    selectedPage = page;
    visitedPages.add(page);
  });
  void goBack() => setState(() {
    selectedPage = pageHistory.isNotEmpty ? pageHistory.removeLast() : 0;
  });
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: atlasStore,
      builder: (context, _) => PopScope(
        canPop: selectedPage == 0,
        onPopInvokedWithResult: (didPop, result) {
          if (!didPop && selectedPage != 0) goBack();
        },
        child: Scaffold(
          bottomNavigationBar: AtlasPrimaryNavigation(
            selectedPage: selectedPage,
            onNavigate: navigate,
          ),
          body: SafeArea(
            child: Column(
              children: [
                PremiumNavBar(
                  selectedIndex: selectedPage,
                  onBack: selectedPage == 0 ? null : goBack,
                  onItemTap: navigate,
                  onSignInTap: () => navigate(6),
                  onSignUpTap: () => navigate(7),
                ),
                if (!atlasStore.persistent)
                  const MaterialBanner(
                    content: Text(
                      'Device storage is unavailable. Your choices will last for this session only.',
                    ),
                    actions: [SizedBox.shrink()],
                  ),
                Expanded(
                  child: IndexedStack(
                    index: selectedPage,
                    children:
                        <Widget>[
                              HomePage(
                                key: ValueKey(homeRevision),
                                onExploreTap: () => navigate(1),
                              ),
                              const ExplorePage(),
                              ComparePage(onAddMore: () => navigate(1)),
                              const GuidesPage(),
                              const ResourcesPage(),
                              const PlacementCheckerPage(),
                              const ExplorePage(savedOnly: true),
                              const GuidesPage(checklistOnly: true),
                              const ResultsPlannerPage(),
                              MyChoicesHub(
                                onExplore: () => navigate(1),
                                onResults: () => navigate(8),
                              ),
                            ].indexed
                            .map(
                              (entry) => visitedPages.contains(entry.$1)
                                  ? entry.$2
                                  : const SizedBox.shrink(),
                            )
                            .toList(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AtlasBrand extends StatelessWidget {
  final VoidCallback onTap;
  const AtlasBrand({super.key, required this.onTap});
  @override
  Widget build(BuildContext context) => Semantics(
    button: true,
    label: 'Skool Atlas home',
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                'assets/branding/launcher-mark.png',
                width: 36,
                height: 36,
                excludeFromSemantics: true,
              ),
            ),
            const SizedBox(width: 9),
            Flexible(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Skool Atlas',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: MediaQuery.sizeOf(context).width < 440
                          ? 14
                          : 16,
                      fontWeight: FontWeight.w800,
                      color: context.atlas.primaryDark,
                      letterSpacing: .3,
                    ),
                  ),
                  if (MediaQuery.sizeOf(context).width >= 440)
                    const SizedBox(height: 2),
                  if (MediaQuery.sizeOf(context).width >= 440)
                    Text(
                      'Discover your next school',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 10,
                        color: context.atlas.muted,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class PremiumNavBar extends StatelessWidget {
  final int selectedIndex;
  final VoidCallback? onBack;
  final Function(int) onItemTap;
  final VoidCallback onSignInTap;
  final VoidCallback onSignUpTap;

  const PremiumNavBar({
    super.key,
    required this.selectedIndex,
    this.onBack,
    required this.onItemTap,
    required this.onSignInTap,
    required this.onSignUpTap,
  });
  PopupMenuItem<int> _buildMenuItem({
    required BuildContext context,
    required int value,
    required IconData icon,
    required String text,
  }) {
    return PopupMenuItem<int>(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18, color: context.atlas.primaryDark),
          const SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: context.atlas.dark,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 1400;

    return Container(
      color: context.atlas.canvas,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 1320),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: context.atlas.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: context.atlas.border),
            boxShadow: const [
              BoxShadow(
                color: Color(0x12000000),
                blurRadius: 28,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            children: [
              if (onBack != null)
                IconButton(
                  onPressed: onBack,
                  tooltip: 'Go back',
                  icon: const Icon(Icons.arrow_back_rounded),
                  color: context.atlas.primaryDark,
                ),
              if (isMobile)
                Expanded(child: AtlasBrand(onTap: () => onItemTap(0)))
              else
                SizedBox(
                  width: 205,
                  child: AtlasBrand(onTap: () => onItemTap(0)),
                ),
              if (width >= 600)
                IconButton(
                  tooltip: 'Account & sync',
                  icon: const Icon(Icons.account_circle_outlined),
                  onPressed: () => openPlanningTool(
                    context,
                    const AccountPage(),
                    'Account & sync',
                  ),
                ),
              const AppearanceButton(),
              if (width >= 600)
                IconButton(
                  tooltip: 'Help & tools',
                  icon: const Icon(Icons.apps_rounded),
                  onPressed: () => openPlanningTool(
                    context,
                    const ToolsWorkspacePage(),
                    'Help & tools',
                  ),
                ),
              const SizedBox(width: 12),
              if (!isMobile) ...[
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      PremiumNavItem(
                        title: "Home",
                        selected: selectedIndex == 0,
                        onTap: () => onItemTap(0),
                        icon: Icons.home_rounded,
                      ),
                      PremiumNavItem(
                        title: "Explore Schools",
                        selected: selectedIndex == 1,
                        onTap: () => onItemTap(1),
                        icon: Icons.travel_explore_rounded,
                      ),
                      PremiumNavItem(
                        title: 'My choices',
                        selected: selectedIndex == 9,
                        onTap: () => onItemTap(9),
                        icon: Icons.bookmarks_outlined,
                      ),
                      PremiumNavItem(
                        title: 'Results planner',
                        selected: selectedIndex == 8,
                        onTap: () => onItemTap(8),
                        icon: Icons.calculate_outlined,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: onSignInTap,
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 48),
                    foregroundColor: context.atlas.primaryDark,
                    side: BorderSide(color: context.atlas.border),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    "Saved schools",
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: onSignUpTap,
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(0, 48),
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    "My checklist",
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
              ],
              if (isMobile)
                PopupMenuButton<int>(
                  tooltip: "Open menu",
                  icon: Icon(
                    Icons.menu_rounded,
                    size: 30,
                    color: context.atlas.dark,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  color: context.atlas.surface,
                  elevation: 12,
                  onSelected: (value) {
                    if (value == 9) {
                      openPlanningTool(
                        context,
                        const ToolsWorkspacePage(),
                        'Help & tools',
                      );
                    } else if (value == 6) {
                      onSignInTap();
                    } else if (value == 7) {
                      onSignUpTap();
                    } else if (value == 8) {
                      openPlanningTool(
                        context,
                        const AccountPage(),
                        'Account & sync',
                      );
                    } else {
                      onItemTap(value);
                    }
                  },
                  itemBuilder: (context) => [
                    _buildMenuItem(
                      context: context,
                      value: 9,
                      icon: Icons.apps_outlined,
                      text: 'Help & tools',
                    ),
                    if (width < 600)
                      _buildMenuItem(
                        context: context,
                        value: 8,
                        icon: Icons.account_circle_outlined,
                        text: 'Account & sync',
                      ),
                    _buildMenuItem(
                      context: context,
                      value: 0,
                      icon: Icons.home_rounded,
                      text: "Home",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 1,
                      icon: Icons.travel_explore_rounded,
                      text: "Explore Schools",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 2,
                      icon: Icons.compare_arrows_rounded,
                      text: "Compare",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 3,
                      icon: Icons.menu_book_rounded,
                      text: "Guides",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 4,
                      icon: Icons.folder_copy_rounded,
                      text: "Resources",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 5,
                      icon: Icons.verified_user_rounded,
                      text: "BECE & placement",
                    ),
                    const PopupMenuDivider(),
                    _buildMenuItem(
                      context: context,
                      value: 6,
                      icon: Icons.bookmark_rounded,
                      text: "Saved schools",
                    ),
                    _buildMenuItem(
                      context: context,
                      value: 7,
                      icon: Icons.checklist_rounded,
                      text: "My checklist",
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class PremiumNavItem extends StatelessWidget {
  final String title;
  final bool selected;
  final VoidCallback? onTap;
  final IconData icon;

  const PremiumNavItem({
    super.key,
    required this.title,
    this.selected = false,
    this.onTap,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: selected ? context.atlas.primarySoft : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: selected
                ? Border.all(color: context.atlas.border)
                : Border.all(color: Colors.transparent),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 16,
                color: selected ? AppColors.primary : context.atlas.dark,
              ),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  fontSize: 13.5,
                  color: selected ? AppColors.primary : context.atlas.dark,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onExploreTap;

  const HomePage({super.key, required this.onExploreTap});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 980;

    return SingleChildScrollView(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1320),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isMobile ? 18 : 22,
              vertical: 18,
            ),
            child: Column(
              children: [
                const GradePlannerEntry(),
                const SizedBox(height: 24),
                isMobile
                    ? Column(
                        children: [
                          const SchoolCarousel(),
                          const SizedBox(height: 24),
                          HeroPremiumSection(onExploreTap: onExploreTap),
                          const SizedBox(height: 24),
                          HomeQuickActions(onExploreTap: onExploreTap),
                        ],
                      )
                    : Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 6,
                            child: HeroPremiumSection(
                              onExploreTap: onExploreTap,
                            ),
                          ),
                          const SizedBox(width: 24),
                          const Expanded(flex: 5, child: SchoolCarousel()),
                        ],
                      ),
                const SizedBox(height: 30),
                if (!isMobile) ...[
                  HomeQuickActions(onExploreTap: onExploreTap),
                  const SizedBox(height: 30),
                ],
                const SchoolSpotlight(),
                const SizedBox(height: 30),
                const SectionTitle(
                  title: "A clearer path from JHS to SHS",
                  subtitle:
                      "Explore your options, discuss your shortlist and prepare for your next step.",
                ),
                const SizedBox(height: 22),
                isMobile
                    ? const Column(
                        children: [
                          FeatureCard(
                            icon: Icons.account_tree_rounded,
                            title: "Structured school discovery",
                            text:
                                "Browse strong school options by region, type, category, and available programs with confidence.",
                          ),
                          SizedBox(height: 16),
                          FeatureCard(
                            icon: Icons.auto_graph_rounded,
                            title: "Side-by-side comparison",
                            text:
                                "Compare programmes, school type, region and residential options side by side.",
                          ),
                          SizedBox(height: 16),
                          FeatureCard(
                            icon: Icons.workspace_premium_rounded,
                            title: "Prepare together",
                            text:
                                "Use the choice checklist and printable planner to talk through your options with your family.",
                          ),
                        ],
                      )
                    : const IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: FeatureCard(
                                icon: Icons.account_tree_rounded,
                                title: "Structured school discovery",
                                text:
                                    "Browse strong school options by region, type, category, and available programs with confidence.",
                              ),
                            ),
                            SizedBox(width: 18),
                            Expanded(
                              child: FeatureCard(
                                icon: Icons.auto_graph_rounded,
                                title: "Side-by-side comparison",
                                text:
                                    "Compare programmes, school type, region and residential options side by side.",
                              ),
                            ),
                            SizedBox(width: 18),
                            Expanded(
                              child: FeatureCard(
                                icon: Icons.workspace_premium_rounded,
                                title: "Prepare together",
                                text:
                                    "Use the choice checklist and printable planner to talk through your options with your family.",
                              ),
                            ),
                          ],
                        ),
                      ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HeroPremiumSection extends StatelessWidget {
  final VoidCallback onExploreTap;

  const HeroPremiumSection({super.key, required this.onExploreTap});

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final isSmall = constraints.maxWidth < 600;

      return Container(
        padding: EdgeInsets.all(isSmall ? 24 : 34),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primaryDark, AppColors.primary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(28),
          boxShadow: const [
            BoxShadow(
              color: Color(0x26162B66),
              blurRadius: 28,
              offset: Offset(0, 14),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white24),
              ),
              child: const Text(
                "Made for JHS students & families",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 22),
            Text(
              "Your next chapter starts with the right school.",
              style: TextStyle(
                fontSize: isSmall ? 34 : 52,
                height: 1.1,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "Discover public, private and STEM schools across Ghana. Explore campus photos, compare programmes and build a shortlist with your family.",
              style: TextStyle(
                fontSize: isSmall ? 16 : 19,
                height: 1.7,
                color: const Color(0xFFEAF6EE),
              ),
            ),
            const SizedBox(height: 28),
            isSmall
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      ElevatedButton(
                        onPressed: onExploreTap,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: context.atlas.surface,
                          foregroundColor: context.atlas.primaryDark,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 28,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          "Start School Search",
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton(
                        onPressed: () => showGuides(context),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white54),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          "How it works",
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  )
                : Wrap(
                    spacing: 14,
                    runSpacing: 12,
                    children: [
                      ElevatedButton(
                        onPressed: onExploreTap,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: context.atlas.surface,
                          foregroundColor: context.atlas.primaryDark,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 28,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          "Start School Search",
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () => showGuides(context),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white54),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          "How it works",
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
            const SizedBox(height: 28),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                HeroStatCard(
                  value: "${schools.length}",
                  label: "School Profiles",
                ),
                HeroStatCard(
                  value: "${schools.map((s) => s.region).toSet().length}",
                  label: "Regions Covered",
                ),
                const HeroStatCard(value: "3", label: "Compare Together"),
              ],
            ),
          ],
        ),
      );
    },
  );
}

class HeroStatCard extends StatelessWidget {
  final String value;
  final String label;

  const HeroStatCard({super.key, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width < 760
          ? (MediaQuery.sizeOf(context).width - 110) / 3
          : 155,
      padding: EdgeInsets.all(MediaQuery.sizeOf(context).width < 760 ? 10 : 16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: Color(0xFFEAF6EE),
              fontSize: MediaQuery.sizeOf(context).width < 760 ? 11 : 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class InfoBlock extends StatelessWidget {
  final String title;
  final String value;
  final Color? valueColor;

  const InfoBlock({
    super.key,
    required this.title,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: context.atlas.lightBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: context.atlas.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: context.atlas.muted,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? context.atlas.dark,
              fontWeight: FontWeight.w800,
              fontSize: 17,
            ),
          ),
        ],
      ),
    );
  }
}

class TagChip extends StatelessWidget {
  final String label;

  const TagChip({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: context.atlas.chipBg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: context.atlas.primaryDark,
          fontWeight: FontWeight.w700,
          fontSize: 13,
          height: 1.3,
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const SectionTitle({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: MediaQuery.sizeOf(context).width < 600 ? 26 : 32,
            fontWeight: FontWeight.w800,
            color: context.atlas.dark,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 17,
            color: context.atlas.muted,
            height: 1.7,
          ),
        ),
      ],
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const FeatureCard({
    super.key,
    required this.icon,
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return HoverLift(
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: atlasPanelDecoration(context),
        child: Column(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: context.atlas.primarySoft,
              child: Icon(icon, color: context.atlas.primary, size: 28),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w800,
                color: context.atlas.dark,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 15,
                height: 1.7,
                color: context.atlas.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
