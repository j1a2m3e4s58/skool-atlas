part of 'main.dart';

class GradePlannerEntry extends StatelessWidget {
  const GradePlannerEntry({super.key});
  @override
  Widget build(BuildContext context) => Surface(
    child: LayoutBuilder(
      builder: (context, constraints) {
        final introduction = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PanelHeading(
              icon: Icons.auto_awesome_outlined,
              title: 'Find schools with my grades',
            ),
            const SizedBox(height: 10),
            Text(
              'Use your BECE grades and home town to build a balanced eight-school draft.',
              style: TextStyle(color: context.atlas.muted),
            ),
            const SizedBox(height: 8),
            Text(
              'Guidance only; suggestions do not confirm CSSPS placement.',
              style: TextStyle(fontSize: 12, color: context.atlas.muted),
            ),
          ],
        );
        final action = FilledButton.icon(
          onPressed: () => openPlanningTool(
            context,
            const ResultsPlannerPage(),
            'Find schools with my grades',
          ),
          icon: const Icon(Icons.calculate_outlined),
          label: const Text('Enter grades & find schools'),
        );
        if (constraints.maxWidth >=
            900 * MediaQuery.textScalerOf(context).scale(14) / 14) {
          return Row(
            children: [
              Expanded(child: introduction),
              const SizedBox(width: 28),
              action,
            ],
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [introduction, const SizedBox(height: 16), action],
        );
      },
    ),
  );
}

class AtlasBootstrap extends StatefulWidget {
  const AtlasBootstrap({super.key});
  @override
  State<AtlasBootstrap> createState() => _AtlasBootstrapState();
}

class _AtlasBootstrapState extends State<AtlasBootstrap> {
  Future<void> bootstrap() async {
    await loadAtlas();
    await loadPlanningData();
    await websiteContent.load();
    unawaited(websiteContent.refresh());
    unawaited(accounts.load());
    unawaited(publishedUpdates.load());
  }

  late Future<void> ready = bootstrap();
  @override
  Widget build(BuildContext context) => FutureBuilder<void>(
    future: ready,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('We could not load the school directory.'),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => setState(() => ready = bootstrap()),
                  child: const Text('Try again'),
                ),
              ],
            ),
          ),
        );
      }
      if (snapshot.connectionState != ConnectionState.done) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(semanticsLabel: 'Loading schools'),
          ),
        );
      }
      return MainShell(key: atlasShellKey);
    },
  );
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

Future<void> openLink(BuildContext context, Uri uri) async {
  if (!['http', 'https'].contains(uri.scheme)) return;
  try {
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) &&
        context.mounted) {
      toast(context, 'Could not open this link. Please try again.');
    }
  } catch (_) {
    if (context.mounted) {
      toast(context, 'Could not open this link. Please try again.');
    }
  }
}

const resultsCheckerShopUrl = 'https://linctechgh.com/buy-data?network=checker';

class ResultsCheckerCard extends StatelessWidget {
  final bool compact;
  const ResultsCheckerCard({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) => compact
      ? Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const PanelHeading(
                icon: Icons.confirmation_number_outlined,
                title: 'Need a results checker?',
              ),
              const SizedBox(height: 10),
              const Text(
                'Buy through LINCTECH GH, then return with your grades. Keep your checker PIN private.',
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () =>
                    openLink(context, Uri.parse(resultsCheckerShopUrl)),
                icon: const Icon(Icons.open_in_new, size: 18),
                label: const Text('Buy a results checker'),
              ),
              const SizedBox(height: 8),
              Text(
                'External website · purchases handled by linctechgh.com',
                style: TextStyle(fontSize: 12, color: context.atlas.muted),
              ),
            ],
          ),
        )
      : Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.primaryDark, Color(0xFF254A97)],
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(
                Icons.confirmation_number_outlined,
                color: Color(0xFFFFD166),
                size: 32,
              ),
              const SizedBox(height: 12),
              const Text(
                'Need a results checker?',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Visit LINCTECH GH to buy a checker, then return here with your grades to plan your school choices.',
                style: TextStyle(color: Color(0xFFE5ECFC), height: 1.6),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFFFD166),
                    foregroundColor: AppColors.primaryDark,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 18,
                    ),
                    textStyle: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  onPressed: () =>
                      openLink(context, Uri.parse(resultsCheckerShopUrl)),
                  icon: const Icon(Icons.open_in_new, size: 20),
                  label: const Text('Buy a results checker'),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Opens linctechgh.com. Purchases are handled on that website. Keep your checker PIN private; Skool Atlas does not collect it.',
                style: TextStyle(
                  color: Color(0xFFE5ECFC),
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ],
          ),
        );
}

void showSchool(BuildContext context, School school) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => SchoolDetailsPage(school: school)),
  );
}

void showGuides(BuildContext context) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => Scaffold(
        appBar: atlasPageBar(context, 'Student & parent guides'),
        body: const GuidesPage(),
      ),
    ),
  );
}

Iterable<Widget> _spacedSections(List<Widget> children) sync* {
  var first = true;
  for (final child in children) {
    if (child is SizedBox &&
        child.child == null &&
        child.width == null &&
        child.height != null) {
      continue;
    }
    if (!first) yield const SizedBox(height: 20);
    yield child;
    first = false;
  }
}

class PageFrame extends StatelessWidget {
  final String title, subtitle;
  final List<Widget> children;
  final Widget? titleWidget;
  final double maxWidth;
  const PageFrame({
    super.key,
    required this.title,
    required this.subtitle,
    required this.children,
    this.titleWidget,
    this.maxWidth = 1200,
  });
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    child: Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            MediaQuery.sizeOf(context).width < 600 ? 18 : 32,
            28,
            MediaQuery.sizeOf(context).width < 600 ? 18 : 32,
            32,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PremiumPageHeader(
                title: title,
                subtitle: subtitle,
                titleWidget: titleWidget,
              ),
              const SizedBox(height: 24),
              ..._spacedSections(children),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    ),
  );
}

class PremiumPageHeader extends StatelessWidget {
  final String title, subtitle;
  final Widget? titleWidget;
  const PremiumPageHeader({
    super.key,
    required this.title,
    required this.subtitle,
    this.titleWidget,
  });
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      titleWidget ??
          Text(
            title,
            style: TextStyle(
              fontSize: MediaQuery.sizeOf(context).width < 600 ? 28 : 36,
              height: 1.15,
              color: context.atlas.primaryDark,
              fontWeight: FontWeight.w800,
            ),
          ),
      const SizedBox(height: 10),
      Text(
        subtitle,
        style: TextStyle(color: context.atlas.muted, height: 1.6, fontSize: 15),
      ),
    ],
  );
}

/// Action groups share one alignment and adapt to available label space.
class BalancedActions extends StatelessWidget {
  final List<Widget> children;
  const BalancedActions({super.key, required this.children});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final scale = MediaQuery.textScalerOf(context).scale(14) / 14;
      final columns = constraints.maxWidth >= 620 * scale ? 2 : 1;
      final style = ButtonStyle(
        alignment: Alignment.centerLeft,
        minimumSize: const WidgetStatePropertyAll(Size(0, 52)),
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      );
      return FilledButtonTheme(
        data: FilledButtonThemeData(
          style: style.merge(FilledButtonTheme.of(context).style),
        ),
        child: OutlinedButtonTheme(
          data: OutlinedButtonThemeData(
            style: style.merge(OutlinedButtonTheme.of(context).style),
          ),
          child: TextButtonTheme(
            data: TextButtonThemeData(
              style: style.merge(TextButtonTheme.of(context).style),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < children.length; i += columns) ...[
                  if (i > 0) const SizedBox(height: 12),
                  if (columns == 1 || i + 1 == children.length)
                    children[i]
                  else
                    IntrinsicHeight(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(child: children[i]),
                          const SizedBox(width: 12),
                          Expanded(
                            child: i + 1 < children.length
                                ? children[i + 1]
                                : const SizedBox(),
                          ),
                        ],
                      ),
                    ),
                ],
              ],
            ),
          ),
        ),
      );
    },
  );
}

/// Balanced content rows without fixed heights, including enlarged text.
class PanelGrid extends StatelessWidget {
  final List<Widget> children;
  const PanelGrid({super.key, required this.children});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final scale = MediaQuery.textScalerOf(context).scale(14) / 14;
      final columns = constraints.maxWidth >= 760 * scale ? 2 : 1;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (var i = 0; i < children.length; i += columns) ...[
            if (i > 0) const SizedBox(height: 20),
            if (columns == 1 || i + 1 == children.length)
              children[i]
            else
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(child: children[i]),
                    const SizedBox(width: 20),
                    Expanded(child: children[i + 1]),
                  ],
                ),
              ),
          ],
        ],
      );
    },
  );
}

class PanelHeading extends StatelessWidget {
  final IconData icon;
  final String title;
  const PanelHeading({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: context.atlas.primarySoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, size: 23, color: context.atlas.primary),
      ),
      const SizedBox(width: 14),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 22,
              height: 1.25,
              fontWeight: FontWeight.w800,
              color: context.atlas.primaryDark,
            ),
          ),
        ),
      ),
    ],
  );
}

class Surface extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const Surface({super.key, required this.child, this.padding});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding:
        padding ??
        EdgeInsets.all(MediaQuery.sizeOf(context).width < 600 ? 18 : 24),
    decoration: atlasPanelDecoration(context),
    child: Material(color: Colors.transparent, child: child),
  );
}

class SchoolBadge extends StatelessWidget {
  final School school;
  final double size;
  const SchoolBadge({super.key, required this.school, this.size = 42});
  String get initials {
    const ignored = {
      'senior',
      'high',
      'school',
      'technical',
      'shs',
      'shts',
      'the',
    };
    final words = school.name
        .replaceAll(RegExp(r'[^a-zA-Z0-9 ]'), ' ')
        .split(' ')
        .where(
          (word) => word.isNotEmpty && !ignored.contains(word.toLowerCase()),
        )
        .take(3);
    return words.map((word) => word[0]).join().toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    Widget fallback() => Center(
      child: Text(
        initials,
        style: TextStyle(
          color: context.atlas.primary,
          fontSize: size * .27,
          fontWeight: FontWeight.w800,
          letterSpacing: .3,
        ),
      ),
    );
    return Semantics(
      image: true,
      label: !school.hasCrest
          ? '${school.name} initials badge; crest not available'
          : '${school.name} crest',
      child: Tooltip(
        message: !school.hasCrest
            ? 'School initials; crest not available'
            : '${school.name} crest',
        child: Container(
          width: size,
          height: size,
          padding: EdgeInsets.all(size * .10),
          decoration: BoxDecoration(
            color: context.atlas.surface,
            borderRadius: BorderRadius.circular(size * .25),
            border: Border.all(color: context.atlas.border),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0D162B66),
                blurRadius: 6,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: school.logo.isEmpty
              ? school.remoteLogo.isEmpty
                    ? fallback()
                    : Image.network(
                        school.remoteLogo,
                        fit: BoxFit.contain,
                        webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
                        excludeFromSemantics: true,
                        errorBuilder: (_, _, _) => fallback(),
                      )
              : Image.asset(
                  school.logo,
                  fit: BoxFit.contain,
                  cacheWidth: 160,
                  excludeFromSemantics: true,
                  errorBuilder: (_, _, _) => fallback(),
                ),
        ),
      ),
    );
  }
}

class SchoolName extends StatelessWidget {
  final School school;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final double badgeSize;
  const SchoolName({
    super.key,
    required this.school,
    this.style,
    this.maxLines = 2,
    this.overflow = TextOverflow.ellipsis,
    this.badgeSize = 38,
  });
  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SchoolBadge(school: school, size: badgeSize),
      const SizedBox(width: 10),
      Expanded(
        child: Text(
          school.name,
          style: style,
          maxLines: maxLines,
          overflow: overflow,
        ),
      ),
    ],
  );
}

class Photo extends StatelessWidget {
  final School school;
  final String? path;
  final double height;
  final BoxFit fit;
  const Photo({
    super.key,
    required this.school,
    this.path,
    this.height = 180,
    this.fit = BoxFit.cover,
  });
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([websiteContent, publishedUpdates]),
    builder: (context, _) => buildImage(context),
  );

  Widget buildImage(BuildContext context) {
    final asset = path ?? (school.images.isNotEmpty ? school.images.first : '');
    final linked = [
      ...websiteContent.items(school.id, 'photos'),
      ...(publishedUpdates.media[school.id] ?? []).where(
        (m) => m['kind'] == 'photo',
      ),
    ];
    Widget placeholder() => Container(
      height: height,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [context.atlas.primarySoft, context.atlas.lightBg],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            school.kind == 'STEM'
                ? Icons.science_outlined
                : Icons.school_outlined,
            color: context.atlas.primary,
            size: 42,
          ),
          if (height >= 140) ...[
            const SizedBox(height: 10),
            Text(
              'Campus photos to follow',
              textAlign: TextAlign.center,
              style: TextStyle(color: context.atlas.primaryDark),
            ),
          ],
        ],
      ),
    );
    if (asset.isEmpty) {
      return linked.isNotEmpty
          ? WebsitePhoto(photo: linked.first, height: height, fit: fit)
          : placeholder();
    }
    return Image.asset(
      asset,
      height: height,
      width: double.infinity,
      fit: fit,
      cacheWidth: height > 250
          ? 1400
          : height < 110
          ? 280
          : 640,
      filterQuality: FilterQuality.low,
      semanticLabel: '${school.name} — school photograph',
      errorBuilder: (_, _, _) => path == null && linked.isNotEmpty
          ? WebsitePhoto(photo: linked.first, height: height, fit: fit)
          : placeholder(),
    );
  }
}

class SaveButton extends StatelessWidget {
  final School school;
  const SaveButton({super.key, required this.school});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: atlasStore,
    builder: (context, _) {
      final saved = atlasStore.saved.contains(school.id);
      return IconButton.filledTonal(
        tooltip: saved ? 'Remove saved school' : 'Save school',
        isSelected: saved,
        icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border),
        onPressed: () => atlasStore.toggleSaved(school.id),
      );
    },
  );
}

class RecommendationPanel extends StatelessWidget {
  const RecommendationPanel({super.key});
  @override
  Widget build(BuildContext context) {
    final selected =
        ['bawjiase-community-senior-high', 'abomosu-stem', 'prempeh-college']
            .map((id) => schools.where((s) => s.id == id).firstOrNull)
            .whereType<School>()
            .toList();
    return Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Find your next chapter',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: context.atlas.primaryDark,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Different schools. Different possibilities.',
            style: TextStyle(color: context.atlas.muted),
          ),
          const SizedBox(height: 20),
          for (final school in selected)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => showSchool(context, school),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: SizedBox(
                        width: 78,
                        child: Photo(school: school, height: 80),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SchoolName(
                            school: school,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: context.atlas.dark,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${school.region} · ${school.kind}',
                            style: TextStyle(
                              color: context.atlas.muted,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_rounded,
                      color: context.atlas.primary,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          const Divider(),
          const SizedBox(height: 8),
          Text(
            '${schools.where((s) => s.images.isNotEmpty).length} profiles with school photos',
            style: TextStyle(
              color: context.atlas.primary,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Save a shortlist, explore programmes, and decide together.',
            style: TextStyle(color: context.atlas.muted, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class SchoolCarousel extends StatefulWidget {
  const SchoolCarousel({super.key});
  @override
  State<SchoolCarousel> createState() => _SchoolCarouselState();
}

class _SchoolCarouselState extends State<SchoolCarousel> {
  final controller = PageController();
  Timer? timer;
  int current = 0;
  bool paused = false;
  late final List<School> featured;
  @override
  void initState() {
    super.initState();
    featured = [
      schools.firstWhere((s) => s.id == 'bawjiase-community-senior-high'),
      schools.firstWhere((s) => s.id == 'abomosu-stem'),
      schools.firstWhere(
        (s) => s.ownership == 'Private' && s.images.isNotEmpty,
      ),
      ...schools
          .where((s) => s.images.isNotEmpty && s.name.contains('Girls'))
          .take(2),
    ].where((s) => s.images.isNotEmpty).toList();
    timer = Timer.periodic(const Duration(seconds: 7), (_) {
      if (!mounted ||
          paused ||
          !controller.hasClients ||
          MediaQuery.disableAnimationsOf(context) ||
          !(ModalRoute.of(context)?.isCurrent ?? true)) {
        return;
      }
      move(1);
    });
  }

  void move(int direction) => controller.animateToPage(
    (current + direction + featured.length) % featured.length,
    duration: const Duration(milliseconds: 650),
    curve: Curves.easeInOutCubic,
  );
  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mobile = MediaQuery.sizeOf(context).width < 760;
    return Container(
      height: mobile ? 430 : 590,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: context.atlas.primaryDark,
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Color(0x22162B66),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Stack(
        children: [
          PageView.builder(
            controller: controller,
            itemCount: featured.length,
            onPageChanged: (value) => setState(() => current = value),
            itemBuilder: (context, index) {
              final school = featured[index];
              return Stack(
                fit: StackFit.expand,
                children: [
                  Photo(school: school, height: mobile ? 430 : 590),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        stops: [0, .35, 1],
                        colors: [
                          Color(0x44000000),
                          Colors.transparent,
                          Color(0xF0162B66),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 24,
                    right: 24,
                    bottom: 84,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${school.region.toUpperCase()}  /  ${school.kind}',
                          style: const TextStyle(
                            color: Color(0xFFBFDBFE),
                            letterSpacing: 1.8,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 12),
                        SchoolName(
                          school: school,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: mobile ? 27 : 34,
                            height: 1.15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextButton.icon(
                          onPressed: () => showSchool(context, school),
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.zero,
                          ),
                          label: const Text(
                            'Explore this school',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          icon: const Icon(Icons.arrow_outward, size: 18),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
          Positioned(
            top: 22,
            left: 24,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xAA162B66),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.white30),
              ),
              child: const Text(
                'CAMPUS SPOTLIGHT',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          Positioned(
            left: 20,
            right: 20,
            bottom: 20,
            child: LayoutBuilder(
              builder: (context, constraints) => Row(
                children: [
                  if (constraints.maxWidth >= featured.length * 20 + 154) ...[
                    for (var i = 0; i < featured.length; i++)
                      Semantics(
                        label: 'Show school ${i + 1}',
                        button: true,
                        selected: current == i,
                        child: InkWell(
                          onTap: () => controller.animateToPage(
                            i,
                            duration: const Duration(milliseconds: 450),
                            curve: Curves.easeInOut,
                          ),
                          child: SizedBox(
                            height: 44,
                            width: current == i ? 30 : 20,
                            child: Center(
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 250),
                                width: current == i ? 24 : 7,
                                height: 7,
                                decoration: BoxDecoration(
                                  color: current == i
                                      ? Colors.white
                                      : Colors.white38,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ] else
                    Text(
                      '${current + 1} / ${featured.length}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  const Spacer(),
                  IconButton(
                    tooltip: paused ? 'Play slideshow' : 'Pause slideshow',
                    onPressed: () => setState(() => paused = !paused),
                    icon: Icon(
                      paused ? Icons.play_arrow_rounded : Icons.pause_rounded,
                    ),
                    color: Colors.white,
                  ),
                  IconButton(
                    tooltip: 'Previous school',
                    onPressed: () => move(-1),
                    icon: const Icon(Icons.chevron_left_rounded),
                    color: Colors.white,
                  ),
                  IconButton(
                    tooltip: 'Next school',
                    onPressed: () => move(1),
                    icon: const Icon(Icons.chevron_right_rounded),
                    color: Colors.white,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomeQuickActions extends StatelessWidget {
  final VoidCallback onExploreTap;
  const HomeQuickActions({super.key, required this.onExploreTap});
  @override
  Widget build(BuildContext context) {
    void open(Widget page, String title) => Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            Scaffold(appBar: atlasPageBar(context, title), body: page),
      ),
    );
    final actions =
        <({IconData icon, String title, String subtitle, VoidCallback tap})>[
          (
            icon: Icons.search_rounded,
            title: 'Find a school',
            subtitle: 'Explore all 16 regions',
            tap: onExploreTap,
          ),
          (
            icon: Icons.auto_graph,
            title: 'Results & choices',
            subtitle: 'Grades to an eight-choice draft',
            tap: () =>
                open(const ResultsPlannerPage(), 'Results & school choices'),
          ),
          (
            icon: Icons.favorite_border_rounded,
            title: 'My shortlist',
            subtitle: 'Pick up where you left off',
            tap: () =>
                open(const ExplorePage(savedOnly: true), 'Saved schools'),
          ),
          (
            icon: Icons.compare_arrows_rounded,
            title: 'Compare schools',
            subtitle: 'See your choices side by side',
            tap: () => open(
              ComparePage(
                onAddMore: () {
                  Navigator.pop(context);
                  onExploreTap();
                },
              ),
              'Compare schools',
            ),
          ),
          (
            icon: Icons.fact_check_outlined,
            title: 'Plan my choices',
            subtitle: 'A checklist for your next step',
            tap: () => open(
              const GuidesPage(checklistOnly: true),
              'My choice checklist',
            ),
          ),
          (
            icon: Icons.explore_outlined,
            title: 'Career pathways',
            subtitle: 'Subjects and explained matches',
            tap: () =>
                open(const CareerGuidancePage(), 'Programme & career explorer'),
          ),
          (
            icon: Icons.info_outline,
            title: 'Fees & support',
            subtitle: 'Dated sources and contacts',
            tap: () =>
                open(const SupportDirectoryPage(), 'Fees, support & contacts'),
          ),
          (
            icon: Icons.video_library_outlined,
            title: 'Campus stories',
            subtitle: 'Photos, videos & school life',
            tap: () => open(const CampusStoriesPage(), 'Discover campus life'),
          ),
        ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 4,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: context.atlas.primary,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        Text(
          'What would you like to do?',
          style: TextStyle(
            fontSize: 23,
            fontWeight: FontWeight.w800,
            color: context.atlas.dark,
          ),
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (context, constraints) => Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (final action in actions)
                SizedBox(
                  width:
                      (constraints.maxWidth -
                          (constraints.maxWidth >= 900 ? 36 : 12)) /
                      (constraints.maxWidth >= 900 ? 4 : 2),
                  child: Material(
                    color: context.atlas.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: context.atlas.border),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: action.tap,
                      child: Container(
                        constraints: BoxConstraints(
                          minHeight:
                              164 *
                              MediaQuery.textScalerOf(context).scale(14) /
                              14,
                        ),
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: context.atlas.primarySoft,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                action.icon,
                                color: context.atlas.primary,
                              ),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              action.title,
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                                color: context.atlas.dark,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              action.subtitle,
                              style: TextStyle(
                                color: context.atlas.muted,
                                fontSize: 12,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class SchoolSpotlight extends StatelessWidget {
  const SchoolSpotlight({super.key});
  @override
  Widget build(BuildContext context) {
    final featured = [
      schools.firstWhere((s) => s.id == 'bawjiase-community-senior-high'),
      schools.firstWhere((s) => s.id == 'abomosu-stem'),
      schools.firstWhere(
        (s) => s.ownership == 'Private' && s.images.isNotEmpty,
      ),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle(
          title: 'Different pathways. One bright future.',
          subtitle:
              'Take a closer look at public, STEM and private school options.',
        ),
        const SizedBox(height: 18),
        LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 760;
            final cards = featured
                .map(
                  (school) => SizedBox(
                    width: compact
                        ? constraints.maxWidth * .86
                        : (constraints.maxWidth - 32) / 3,
                    child: Material(
                      color: context.atlas.surface,
                      borderRadius: BorderRadius.circular(22),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () => showSchool(context, school),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              children: [
                                Photo(school: school, height: 190),
                                Positioned(
                                  left: 14,
                                  bottom: 14,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryDark,
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                    child: Text(
                                      school.kind == 'STEM'
                                          ? 'STEM pathway'
                                          : school.ownership == 'Private'
                                          ? 'Private school'
                                          : 'Public school',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SchoolName(
                                    school: school,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 18,
                                      height: 1.3,
                                      fontWeight: FontWeight.w800,
                                      color: context.atlas.dark,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          school.region,
                                          style: TextStyle(
                                            color: context.atlas.muted,
                                          ),
                                        ),
                                      ),
                                      Icon(
                                        Icons.arrow_forward_rounded,
                                        size: 20,
                                        color: context.atlas.primary,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
                .toList();
            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    if (i > 0) const SizedBox(width: 16),
                    cards[i],
                  ],
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}

class ExplorePage extends StatefulWidget {
  final bool savedOnly;
  const ExplorePage({super.key, this.savedOnly = false});
  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  final search = TextEditingController();
  Timer? searchDebounce;
  bool touched = false;
  String get filterKey =>
      widget.savedOnly ? 'atlas.saved.filters.v1' : 'atlas.explore.filters.v1';
  @override
  void initState() {
    super.initState();
    unawaited(restoreFilters());
  }

  Future<void> restoreFilters() async {
    try {
      final raw = (await SharedPreferences.getInstance()).getString(filterKey);
      if (!mounted || touched || raw == null) return;
      final values = jsonDecode(raw) as Map;
      setState(() {
        search.text = '${values['query'] ?? ''}';
        if (schools.any((s) => s.region == values['region'])) {
          region = '${values['region']}';
        }
        if (schools.any((s) => s.programs.contains(values['program']))) {
          program = '${values['program']}';
        }
        if ([
          'All students',
          'Boys',
          'Girls',
          'Mixed',
        ].contains(values['gender'])) {
          gender = '${values['gender']}';
        }
        if ([
          'Any residence',
          'Day',
          'Boarding',
        ].contains(values['residency'])) {
          residency = '${values['residency']}';
        }
        if ([
          'All categories',
          'Category A',
          'Category B',
          'Category C',
          'Not confirmed',
        ].contains(values['category'])) {
          category = '${values['category']}';
        }
        if ([
          'All schools',
          'Public / government',
          'Private',
          'STEM',
          'TVET / technical',
          'International',
        ].contains(values['group'])) {
          group = '${values['group']}';
        }
        if (['Photos first', 'A–Z', 'Region'].contains(values['sort'])) {
          sort = '${values['sort']}';
        }
      });
    } catch (_) {
      /* Browsing remains available if device storage is unavailable. */
    }
  }

  Future<void> persistFilters() async {
    touched = true;
    try {
      await (await SharedPreferences.getInstance()).setString(
        filterKey,
        jsonEncode({
          'query': search.text,
          'region': region,
          'program': program,
          'gender': gender,
          'residency': residency,
          'category': category,
          'group': group,
          'sort': sort,
        }),
      );
    } catch (_) {}
  }

  void searchChanged(String _) {
    touched = true;
    searchDebounce?.cancel();
    searchDebounce = Timer(const Duration(milliseconds: 250), () {
      if (mounted) {
        setState(() {});
        unawaited(persistFilters());
      }
    });
  }

  String region = 'All regions',
      program = 'All programmes',
      gender = 'All students',
      residency = 'Any residence',
      category = 'All categories',
      group = 'All schools',
      sort = 'Photos first';
  bool showFilters = false;
  @override
  void dispose() {
    searchDebounce?.cancel();
    search.dispose();
    super.dispose();
  }

  void reset() {
    setState(() {
      search.clear();
      region = 'All regions';
      program = 'All programmes';
      gender = 'All students';
      residency = 'Any residence';
      category = 'All categories';
      group = 'All schools';
      sort = 'Photos first';
    });
    unawaited(persistFilters());
  }

  Widget dropdown(
    String label,
    String value,
    List<String> values,
    ValueChanged<String> changed, {
    double width = 250,
  }) => SizedBox(
    width: width,
    child: DropdownButtonFormField<String>(
      key: ValueKey('$label:$value'),
      initialValue: value,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      items: values
          .map(
            (v) => DropdownMenuItem(
              value: v,
              child: Text(v, overflow: TextOverflow.ellipsis),
            ),
          )
          .toList(),
      onChanged: (v) {
        if (v != null) {
          setState(() => changed(v));
          unawaited(persistFilters());
        }
      },
    ),
  );

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([atlasStore, websiteContent, publishedUpdates]),
    builder: (context, _) {
      final results = searchSchools(
        query: search.text,
        region: region,
        program: program,
        gender: gender,
        residency: residency,
        category: category,
        group: group,
        savedOnly: widget.savedOnly,
      );
      results.sort((a, b) {
        final aHasPhotos =
            a.images.isNotEmpty ||
            websiteContent.items(a.id, 'photos').isNotEmpty;
        final bHasPhotos =
            b.images.isNotEmpty ||
            websiteContent.items(b.id, 'photos').isNotEmpty;
        if (sort == 'Photos first' && aHasPhotos != bHasPhotos) {
          return aHasPhotos ? -1 : 1;
        }
        if (sort == 'Region') {
          final order = a.region.compareTo(b.region);
          if (order != 0) return order;
        }
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
      final wide = MediaQuery.sizeOf(context).width >= 900;
      final regionValues = schools.map((s) => s.region).toSet().toList()
        ..sort();
      final programValues = schools.expand((s) => s.programs).toSet().toList()
        ..sort();
      return Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1320),
          child: CustomScrollView(
            key: PageStorageKey(
              widget.savedOnly ? 'saved-scroll' : 'explore-scroll',
            ),
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 12),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      PremiumPageHeader(
                        title: widget.savedOnly
                            ? 'Your saved schools'
                            : 'Explore schools',
                        subtitle: widget.savedOnly
                            ? 'Your shortlist stays on this device. Share it with your family and guidance teacher.'
                            : 'Discover your options across Ghana. Look beyond the name — find a place where you can grow.',
                      ),
                      if (widget.savedOnly) ...[
                        const SizedBox(height: 16),
                        OutlinedButton.icon(
                          onPressed: () => openPlanningTool(
                            context,
                            const OfflineChoicesPage(),
                            'Offline & family sharing',
                          ),
                          icon: const Icon(Icons.download_outlined),
                          label: const Text('Offline pack & family sharing'),
                        ),
                      ],
                      const SizedBox(height: 20),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            for (final label in [
                              'All schools',
                              'Public / government',
                              'Private',
                              'STEM',
                              'TVET / technical',
                              'International',
                            ])
                              Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: ChoiceChip(
                                  label: Text(label),
                                  selected: group == label,
                                  onSelected: (_) => setState(() {
                                    group = label;
                                    unawaited(persistFilters());
                                  }),
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: search,
                        onChanged: searchChanged,
                        decoration: InputDecoration(
                          labelText: 'Search schools',
                          hintText: 'School, town, region or programme',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: context.atlas.surface,
                          suffixIcon: search.text.isEmpty
                              ? null
                              : IconButton(
                                  tooltip: 'Clear search',
                                  icon: const Icon(Icons.close),
                                  onPressed: () {
                                    setState(search.clear);
                                    unawaited(persistFilters());
                                  },
                                ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 12,
                        runSpacing: 10,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          TextButton.icon(
                            onPressed: () =>
                                setState(() => showFilters = !showFilters),
                            icon: const Icon(Icons.tune),
                            label: Text(
                              showFilters || wide ? 'Filters' : 'Show filters',
                            ),
                          ),
                          TextButton(
                            onPressed: reset,
                            child: const Text('Reset all'),
                          ),
                          Text(
                            '${results.length} ${results.length == 1 ? 'school' : 'schools'}',
                            style: TextStyle(
                              color: context.atlas.primaryDark,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          dropdown('Sort by', sort, [
                            'Photos first',
                            'A–Z',
                            'Region',
                          ], (v) => sort = v, width: MediaQuery.sizeOf(context).width < 600 ? MediaQuery.sizeOf(context).width - 40 : 250),
                        ],
                      ),
                      if (showFilters || wide)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: Surface(
                            child: PanelGrid(
                              children: [
                                dropdown('Region', region, [
                                  'All regions',
                                  ...regionValues,
                                ], (v) => region = v, width: double.infinity),
                                dropdown('Programme', program, [
                                  'All programmes',
                                  ...programValues,
                                ], (v) => program = v, width: double.infinity),
                                dropdown('Students', gender, [
                                  'All students',
                                  'Boys',
                                  'Girls',
                                  'Mixed',
                                ], (v) => gender = v, width: double.infinity),
                                dropdown('Residence', residency, [
                                  'Any residence',
                                  'Day',
                                  'Boarding',
                                ], (v) => residency = v, width: double.infinity),
                                dropdown('Selection category', category, [
                                  'All categories',
                                  'Category A',
                                  'Category B',
                                  'Category C',
                                  'Not confirmed',
                                ], (v) => category = v, width: double.infinity),
                              ],
                            ),
                          ),
                        ),
                      const SizedBox(height: 8),
                      Text(
                        'Coverage is growing across all 16 regions; this is not yet a complete national register. Categories are selection groups, not school rankings. Confirm current programmes and admissions with the school.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          height: 1.5,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (results.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          widget.savedOnly
                              ? Icons.bookmarks_outlined
                              : Icons.search_off,
                          size: 56,
                          color: context.atlas.primary,
                        ),
                        const SizedBox(height: 18),
                        Text(
                          widget.savedOnly && atlasStore.saved.isEmpty
                              ? 'Start your shortlist'
                              : 'No schools match these filters',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.savedOnly && atlasStore.saved.isEmpty
                              ? 'Tap the bookmark on any school to save it here.'
                              : 'Try a different name or reset your filters.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        OutlinedButton(
                          onPressed: reset,
                          child: const Text('Reset filters'),
                        ),
                      ],
                    ),
                  ),
                ),
              if (results.isNotEmpty)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
                  sliver: SliverLayoutBuilder(
                    builder: (context, constraints) {
                      final columns = constraints.crossAxisExtent >= 1100
                          ? 3
                          : constraints.crossAxisExtent >= 680
                          ? 2
                          : 1;
                      return SliverGrid.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          mainAxisExtent:
                              416 +
                              math.max(
                                    0,
                                    MediaQuery.textScalerOf(context).scale(14) -
                                        14,
                                  ) *
                                  14,
                          crossAxisSpacing: 18,
                          mainAxisSpacing: 18,
                        ),
                        itemCount: results.length,
                        itemBuilder: (context, i) => ExploreSchoolCard(
                          key: ValueKey(results[i].id),
                          school: results[i],
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      );
    },
  );
}

class ExploreSchoolCard extends StatelessWidget {
  final School school;
  const ExploreSchoolCard({super.key, required this.school});
  @override
  Widget build(BuildContext context) => Container(
    clipBehavior: Clip.antiAlias,
    decoration: atlasPanelDecoration(context),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            InkWell(
              onTap: () => showSchool(context, school),
              child: Photo(school: school, height: 170),
            ),
            Positioned(top: 10, right: 10, child: SaveButton(school: school)),
            Positioned(
              bottom: 10,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: context.atlas.surface,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${school.kind} · ${school.ownership == 'Public / government'
                      ? 'Public'
                      : school.ownership == 'Private'
                      ? 'Private'
                      : 'Directory'}',
                  style: TextStyle(
                    color: context.atlas.primaryDark,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SchoolName(
                  school: school,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 19,
                    height: 1.2,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.dark,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(
                      Icons.location_on_outlined,
                      size: 15,
                      color: context.atlas.muted,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        '${school.region} · ${school.gender}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: context.atlas.muted,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
                Text(
                  '${school.residency} · ${school.categoryLabel}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: context.atlas.primary, fontSize: 12),
                ),
                const SizedBox(height: 12),
                ProgrammeStrip(programmes: school.programs),
                const Spacer(),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => showSchool(context, school),
                        child: const Text('View school'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () =>
                            toast(context, atlasStore.addComparison(school.id)),
                        icon: const Icon(Icons.compare_arrows, size: 18),
                        label: const Text('Compare'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

class SchoolAchievements extends StatelessWidget {
  final School school;
  const SchoolAchievements({super.key, required this.school});
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.emoji_events_outlined,
              color: context.atlas.primary,
              size: 28,
            ),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Achievements & participation',
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w800,
                  color: context.atlas.primaryDark,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          'A selected, source-linked history. Competition results do not measure every school strength or guarantee admission.',
          style: TextStyle(color: context.atlas.muted, height: 1.5),
        ),
        if (school.achievements.isEmpty) ...[
          const SizedBox(height: 18),
          Text(
            'No reviewed achievement records added yet.',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: context.atlas.dark,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'This does not mean the school has no achievements. Ask about academic results, sports, arts, debate, robotics and community projects during your visit.',
            style: TextStyle(color: context.atlas.muted, height: 1.5),
          ),
        ] else ...[
          for (final item in school.achievements)
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: context.atlas.lightBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: context.atlas.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        TagChip(label: '${item['year']}'),
                        TagChip(label: '${item['kind']}'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '${item['title']}',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                        color: context.atlas.dark,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${item['result']}',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: context.atlas.primary,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${item['detail']}',
                      style: TextStyle(color: context.atlas.muted, height: 1.6),
                    ),
                    const SizedBox(height: 8),
                    TextButton.icon(
                      onPressed: () =>
                          openLink(context, Uri.parse('${item['url']}')),
                      icon: const Icon(Icons.open_in_new, size: 16),
                      label: Text('${item['sourceLabel']}', softWrap: true),
                    ),
                    Text(
                      'Source reviewed ${item['reviewed']}',
                      style: TextStyle(
                        color: context.atlas.muted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ],
    ),
  );
}

class SchoolDetailsPage extends StatefulWidget {
  final School school;
  const SchoolDetailsPage({super.key, required this.school});
  @override
  State<SchoolDetailsPage> createState() => _SchoolDetailsPageState();
}

class _SchoolDetailsPageState extends State<SchoolDetailsPage> {
  School get school => widget.school;
  final sectionKeys = List.generate(6, (_) => GlobalKey());
  bool mapVisible = false;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: publishedUpdates,
    builder: (context, _) => Scaffold(
      appBar: AppBar(
        title: SchoolName(school: school, style: const TextStyle(fontSize: 18)),
        actions: [
          SaveButton(school: school),
          const AppearanceButton(),
          IconButton(
            onPressed: () => returnToAtlasHome(context),
            tooltip: 'Go home',
            icon: const Icon(Icons.home_outlined),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: PageFrame(
        title: school.name,
        titleWidget: SchoolName(
          school: school,
          badgeSize: 64,
          maxLines: null,
          overflow: TextOverflow.visible,
          style: TextStyle(
            fontSize: MediaQuery.sizeOf(context).width < 600 ? 26 : 36,
            height: 1.2,
            fontWeight: FontWeight.w800,
            color: context.atlas.primaryDark,
          ),
        ),
        subtitle: '${school.location}\n${school.gender} · ${school.residency}',
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final scale = MediaQuery.textScalerOf(context).scale(14) / 14;
              final columns = constraints.maxWidth >= 880 * scale
                  ? 6
                  : constraints.maxWidth >= 420 * scale
                  ? 3
                  : 2;
              return Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < 6; i++)
                    SizedBox(
                      width:
                          (constraints.maxWidth - (columns - 1) * 8) / columns,
                      child: ActionChip(
                        label: Text(
                          [
                            'Overview',
                            'Programmes',
                            'Gallery',
                            'Achievements',
                            'Practical details',
                            'Location',
                          ][i],
                        ),
                        onPressed: () {
                          final target = sectionKeys[i].currentContext;
                          if (target != null) {
                            Scrollable.ensureVisible(
                              target,
                              duration: const Duration(milliseconds: 250),
                            );
                          }
                        },
                      ),
                    ),
                ],
              );
            },
          ),

          if (school.data['status'] != null && school.data['status'] != 'Open')
            InfoPanel(
              title: 'School operation status',
              text:
                  '${school.data['status']}. Confirm current operation with the school and official selection service.',
            ),
          if (school.data['photoNote'] != null)
            InfoPanel(
              title: 'About these photographs',
              text: '${school.data['photoNote']}',
            ),
          if (school.data['locationNote'] != null)
            InfoPanel(
              title: 'Location source note',
              text: '${school.data['locationNote']}',
            ),
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: GestureDetector(
              onTap: () {
                if (school.images.isNotEmpty) {
                  showGallery(context, school, 0);
                } else {
                  final linked = [
                    ...websiteContent.items(school.id, 'photos'),
                    ...(publishedUpdates.media[school.id] ?? []).where(
                      (m) => m['kind'] == 'photo',
                    ),
                  ];
                  if (linked.isNotEmpty) {
                    openWebsiteGallery(context, school, linked, 0);
                  }
                }
              },
              child: Photo(
                school: school,
                height: MediaQuery.sizeOf(context).width < 600 ? 230 : 380,
              ),
            ),
          ),
          const SizedBox(height: 22),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              TagChip(label: school.ownership),
              TagChip(label: school.kind),
              TagChip(label: school.categoryLabel),
            ],
          ),
          const SizedBox(height: 20),
          if (school.categoryNote.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Text(
                school.categoryNote,
                style: TextStyle(
                  color: context.atlas.muted,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ),
          BalancedActions(
            children: [
              FilledButton.icon(
                onPressed: () =>
                    toast(context, atlasStore.addComparison(school.id)),
                icon: const Icon(Icons.compare_arrows),
                label: const Text('Add to comparison'),
              ),
              OutlinedButton.icon(
                onPressed: () => openLink(context, school.mapUri),
                icon: const Icon(Icons.map_outlined),
                label: const Text('Find on map'),
              ),
              if (school.website.isNotEmpty)
                OutlinedButton.icon(
                  onPressed: () => openLink(context, Uri.parse(school.website)),
                  icon: const Icon(Icons.open_in_new),
                  label: Text(
                    [
                          'gna.org.gh',
                          'mofep.gov.gh',
                        ].contains(linkHost(school.website))
                        ? 'Reference page'
                        : 'School website',
                  ),
                ),
              OutlinedButton.icon(
                onPressed: () async {
                  await Clipboard.setData(
                    ClipboardData(text: schoolSummary(school)),
                  );
                  if (context.mounted) {
                    toast(
                      context,
                      'School information copied. Share it with your family.',
                    );
                  }
                },
                icon: const Icon(Icons.copy_outlined),
                label: const Text('Copy school info'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SchoolInformationStatus(school: school),
          const SizedBox(height: 18),

          const SizedBox(height: 18),
          Surface(
            key: sectionKeys[0],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Overview',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  school.description,
                  style: TextStyle(height: 1.7, color: context.atlas.muted),
                ),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 32,
                  runSpacing: 18,
                  children: [
                    InfoBlock(title: 'Region', value: school.region),
                    InfoBlock(title: 'Students', value: school.gender),
                    InfoBlock(title: 'Residence', value: school.residency),
                    InfoBlock(title: 'School group', value: school.ownership),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Surface(
            key: sectionKeys[1],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Programmes & pathways',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: school.programs
                      .map((p) => TagChip(label: p))
                      .toList(),
                ),
                const SizedBox(height: 14),
                Text(
                  school.data['programsObserved'] != null
                      ? 'Programme source observed ${school.data['programsObserved']}. Ask the school about current intake and exact subject combinations.'
                      : school.data['registerYear'] != null
                      ? 'Source: ${school.data['registerYear']} selection register, page ${school.data['registerPage']}. Ask the school about current intake and exact subject combinations.'
                      : 'Archive programme listing; current availability is not yet verified. Ask the school for its current programmes and subject combinations.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
                if (school.facilities.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  const Text(
                    'Facilities listed by the school',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  for (final item in school.facilities)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text('• $item'),
                    ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (school.data['publicProgrammeReview'] != null) ...[
            const SizedBox(height: 18),
            OfficialProgrammeReview(school: school),
          ],
          Text(
            'Gallery & videos',
            key: sectionKeys[2],
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
          ),
          if (school.images.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              'Tap a photo to explore the gallery',
              style: TextStyle(color: context.atlas.muted, fontSize: 12),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 92,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: school.images.length,
                separatorBuilder: (_, _) => const SizedBox(width: 10),
                itemBuilder: (context, i) => Semantics(
                  button: true,
                  label: 'Open school photo ${i + 1}',
                  child: InkWell(
                    onTap: () => showGallery(context, school, i),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: SizedBox(
                        width: 140,
                        child: Photo(
                          school: school,
                          path: school.images[i],
                          height: 92,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
          SchoolWebsiteSection(school: school),
          const SizedBox(height: 18),
          SchoolAchievements(key: sectionKeys[3], school: school),
          const SizedBox(height: 18),
          SchoolPracticalInfo(key: sectionKeys[4], school: school),

          const SizedBox(height: 18),

          const SizedBox(height: 18),
          Surface(
            key: sectionKeys[5],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.location_on_outlined,
                  color: context.atlas.primary,
                  size: 32,
                ),
                const SizedBox(height: 8),
                Text(
                  'Plan a school visit',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  school.location,
                  style: TextStyle(color: context.atlas.muted),
                ),
                const SizedBox(height: 12),
                Text(
                  'Open the school search on Google Maps to check the campus pin and directions before travelling. Map results require an internet connection.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () => setState(() => mapVisible = !mapVisible),
                  icon: const Icon(Icons.map_outlined),
                  label: Text(mapVisible ? 'Hide map' : 'Show interactive map'),
                ),
                if (mapVisible) ...[
                  SchoolDistancePanel(school: school),
                  const SizedBox(height: 16),
                  SchoolMap(query: '${school.name}, ${school.location}'),
                ],
                OutlinedButton.icon(
                  onPressed: () => openLink(context, school.mapUri),
                  icon: const Icon(Icons.directions),
                  label: const Text('Open map & directions'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Before you choose',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Confirm current programmes, residence availability, selection category, fees and admission requirements with the school or your JHS guidance teacher. A listed programme or category does not guarantee placement.',
                  style: TextStyle(color: context.atlas.muted, height: 1.7),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Questions to ask',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Which subjects can I combine?\nIs my preferred residence available?\nWhat support is available for new students?\nWhat documents and costs should my family prepare?',
                  style: TextStyle(height: 1.8),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Information & photo sources',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                for (final source in school.sources)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if ('${source['url'] ?? ''}'.isNotEmpty)
                          TextButton.icon(
                            onPressed: () => openLink(
                              context,
                              Uri.parse('${source['url']}'),
                            ),
                            icon: const Icon(Icons.open_in_new, size: 16),
                            label: Text(
                              '${source['label'] ?? 'Published source'}',
                            ),
                          )
                        else
                          Text(
                            '${source['label'] ?? 'Published source'}',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        if ('${source['note'] ?? ''}'.isNotEmpty)
                          Text(
                            '${source['note']}',
                            style: TextStyle(
                              color: context.atlas.muted,
                              fontSize: 12,
                              height: 1.5,
                            ),
                          ),
                      ],
                    ),
                  ),
                if (school.images.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'Photos are from the supplied archive or the linked school/directory sources. Their original owners retain rights.',
                      style: TextStyle(
                        color: context.atlas.muted,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

String schoolSummary(School s) =>
    '${s.name}\n${s.region} · ${s.type}\n${s.kind} · ${s.ownership}\nProgrammes: ${s.programs.join(', ')}\nMap: ${s.mapUri}\n${s.website.isEmpty ? '' : 'Website: ${s.website}\n'}Confirm current admission details with the school. Prepared with Skool Atlas.';

void showGallery(BuildContext context, School school, int index) =>
    showDialog<void>(
      context: context,
      builder: (_) => GalleryDialog(school: school, initialIndex: index),
    );

class GalleryDialog extends StatefulWidget {
  final School school;
  final int initialIndex;
  const GalleryDialog({
    super.key,
    required this.school,
    required this.initialIndex,
  });
  @override
  State<GalleryDialog> createState() => _GalleryDialogState();
}

class _GalleryDialogState extends State<GalleryDialog> {
  late int index = widget.initialIndex;
  @override
  Widget build(BuildContext context) => Dialog(
    insetPadding: const EdgeInsets.all(16),
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 1000),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const SizedBox(width: 16),
              SchoolBadge(school: widget.school, size: 32),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '${widget.school.name} · ${index + 1}/${widget.school.images.length}',
                  maxLines: 2,
                ),
              ),
              IconButton(
                tooltip: 'Close gallery',
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          Flexible(
            child: InteractiveViewer(
              child: Photo(
                school: widget.school,
                path: widget.school.images[index],
                height: math.min(MediaQuery.sizeOf(context).height * .65, 600),
                fit: BoxFit.contain,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                tooltip: 'Previous photo',
                onPressed: index > 0 ? () => setState(() => index--) : null,
                icon: const Icon(Icons.chevron_left),
              ),
              Text('${index + 1} of ${widget.school.images.length}'),
              IconButton(
                tooltip: 'Next photo',
                onPressed: index < widget.school.images.length - 1
                    ? () => setState(() => index++)
                    : null,
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

class ComparePage extends StatelessWidget {
  final VoidCallback onAddMore;
  const ComparePage({super.key, required this.onAddMore});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: atlasStore,
    builder: (context, _) {
      final compared = atlasStore.compared
          .map((id) => schools.where((s) => s.id == id).firstOrNull)
          .whereType<School>()
          .toList();
      return PageFrame(
        title: 'Compare your possibilities',
        subtitle:
            'Up to three schools, side by side. Focus on the programme and daily experience that fit you.',
        children: [
          BalancedActions(
            children: [
              FilledButton.icon(
                onPressed: onAddMore,
                icon: const Icon(Icons.add),
                label: const Text('Explore more schools'),
              ),
              if (compared.isNotEmpty)
                OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(
                      ClipboardData(
                        text: compared.map(schoolSummary).join('\n\n'),
                      ),
                    );
                    if (context.mounted) toast(context, 'Comparison copied.');
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy comparison'),
                ),
            ],
          ),
          const SizedBox(height: 20),
          if (compared.isNotEmpty) ...[
            ExportChoiceActions(selected: compared),
            const SizedBox(height: 20),
          ],
          if (compared.isEmpty)
            Surface(
              child: Column(
                children: [
                  Icon(
                    Icons.compare_arrows,
                    color: context.atlas.primary,
                    size: 52,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Which schools feel right for you?',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Choose Compare on a school card to start your comparison.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          else
            LayoutBuilder(
              builder: (context, constraints) {
                final width = math.max(
                  260.0,
                  (constraints.maxWidth - 32) / compared.length,
                );
                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final s in compared)
                        Padding(
                          padding: const EdgeInsets.only(right: 16),
                          child: SizedBox(
                            width: width,
                            child: Surface(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(16),
                                    child: Photo(school: s, height: 160),
                                  ),
                                  const SizedBox(height: 14),
                                  SizedBox(
                                    height: 64,
                                    child: SchoolName(
                                      school: s,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                        color: context.atlas.primaryDark,
                                      ),
                                    ),
                                  ),
                                  comparisonField(context, 'Region', s.region),
                                  comparisonField(
                                    context,
                                    'Students',
                                    s.gender,
                                  ),
                                  comparisonField(
                                    context,
                                    'Residence',
                                    s.residency,
                                  ),
                                  comparisonField(
                                    context,
                                    'School group',
                                    s.ownership,
                                  ),
                                  comparisonField(context, 'Pathway', s.kind),
                                  comparisonField(
                                    context,
                                    'Category',
                                    s.categoryLabel,
                                  ),
                                  SizedBox(
                                    height: 185,
                                    child: SingleChildScrollView(
                                      child: comparisonField(
                                        context,
                                        'Listed programmes',
                                        s.programs.join('\n'),
                                      ),
                                    ),
                                  ),
                                  OutlinedButton(
                                    onPressed: () => showSchool(context, s),
                                    child: const Text('View full profile'),
                                  ),
                                  TextButton.icon(
                                    onPressed: () =>
                                        atlasStore.removeComparison(s.id),
                                    icon: const Icon(Icons.close),
                                    label: const Text('Remove'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          const SizedBox(height: 18),
          Text(
            'Placement depends on official selection rules, results, programme and available spaces. Skool Atlas does not predict admission or publish unverified cut-off scores.',
            style: TextStyle(color: context.atlas.muted, height: 1.6),
          ),
        ],
      );
    },
  );
  Widget comparisonField(BuildContext context, String label, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(color: context.atlas.muted, fontSize: 12),
            ),
            const SizedBox(height: 5),
            Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5),
            ),
          ],
        ),
      );
}

const choiceChecklist = <String, String>{
  'interests': 'I know the subjects and career areas I enjoy.',
  'programmes': 'I have confirmed my preferred programmes with each school.',
  'residence':
      'My family and I have checked residence and travel arrangements.',
  'visit': 'We have looked at the campus or arranged a school visit.',
  'rules': 'My guidance teacher has checked the current selection rules.',
  'budget': 'We have discussed required documents, support and possible costs.',
  'review':
      'My parent or guardian and I have reviewed the final choices together.',
};

class GuidesPage extends StatelessWidget {
  final bool checklistOnly;
  const GuidesPage({super.key, this.checklistOnly = false});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: atlasStore,
    builder: (context, _) => PageFrame(
      title: checklistOnly
          ? 'Your school-choice checklist'
          : 'A little guidance. A clearer choice.',
      subtitle: 'For JHS students and the families supporting their next step.',
      children: [
        if (!checklistOnly) ...[
          PanelGrid(
            children: [
              for (final step in [
                (
                  '01',
                  'Start with what you enjoy',
                  'Think about the subjects you like and the kind of work you would love to do. Explore Science, Arts, Business, Home Economics, Agriculture, technical and STEM pathways.',
                ),
                (
                  '02',
                  'Look at everyday school life',
                  'Consider the journey, day or boarding arrangements, learning support and school environment. A famous name is only one part of the decision.',
                ),
                (
                  '03',
                  'Build a balanced shortlist',
                  'Save schools, compare their programmes and discuss them with your family. Category A, B and C are selection groups, not a ranking of teaching quality.',
                ),
                (
                  '04',
                  'Check this year’s official rules',
                  'Selection limits, deadlines and availability can change. Ask your JHS guidance teacher to review the current GES/CSSPS instructions before you submit anything.',
                ),
              ])
                Padding(
                  padding: EdgeInsets.zero,
                  child: Surface(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundColor: context.atlas.primarySoft,
                          child: Text(
                            step.$1,
                            style: TextStyle(color: context.atlas.primary),
                          ),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                step.$2,
                                style: TextStyle(
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                  color: context.atlas.primaryDark,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                step.$3,
                                style: TextStyle(
                                  color: context.atlas.muted,
                                  height: 1.6,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ],
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Ready to choose?',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: context.atlas.primaryDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${choiceChecklist.keys.where(atlasStore.checklist.contains).length} of ${choiceChecklist.length} steps completed · saved on this device',
                style: TextStyle(color: context.atlas.muted),
              ),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value:
                    choiceChecklist.keys
                        .where(atlasStore.checklist.contains)
                        .length /
                    choiceChecklist.length,
              ),
              const SizedBox(height: 12),
              for (final entry in choiceChecklist.entries)
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: atlasStore.checklist.contains(entry.key),
                  onChanged: (_) => atlasStore.toggleChecklist(entry.key),
                  title: Text(entry.value),
                ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        if (!checklistOnly)
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Questions students ask',
                  style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
                ),
                for (final item in [
                  (
                    'Does saving a school apply to it?',
                    'No. Your saved schools and comparisons are planning tools. Submit your actual choices through your school and the official selection process.',
                  ),
                  (
                    'Can I switch from day to boarding after admission?',
                    'Do not plan on a switch. Confirm your preferred residence during selection and ask the school about its current rules.',
                  ),
                  (
                    'Does a good aggregate guarantee a school?',
                    'No. Placement also depends on programme, residence, available spaces and the official selection process. We do not predict placement.',
                  ),
                  (
                    'Are private and international schools the same?',
                    'No. Private schools can offer WASSCE, international curricula or both. Check the pathway on the profile and confirm the admission process with the school.',
                  ),
                  (
                    'Will my shortlist appear on another phone?',
                    'Currently it is saved only in this browser or device. Copy your comparison to share it. Clearing browser data may remove saved choices.',
                  ),
                ])
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    title: Text(item.$1),
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: Text(
                          item.$2,
                          style: TextStyle(
                            height: 1.7,
                            color: context.atlas.muted,
                          ),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
      ],
    ),
  );
}

class ResourcesPage extends StatelessWidget {
  const ResourcesPage({super.key});
  @override
  Widget build(BuildContext context) => PageFrame(
    title: 'Useful resources, all in one place',
    subtitle: 'Practical tools for planning your next step with confidence.',
    children: [
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Help test Skool Atlas',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'A guided student-and-parent test with sample data and feedback you choose whether to share.',
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => openPlanningTool(
                context,
                const PilotFeedbackPage(),
                'Pilot tasks & feedback',
              ),
              icon: const Icon(Icons.checklist_outlined),
              label: const Text('Open pilot tasks & feedback'),
            ),
          ],
        ),
      ),
      const PlanningHub(),
      const SizedBox(height: 18),
      PanelGrid(
        children: [
          for (final resource in [
            (
              'Official CSSPS portal',
              'Use the official service for placement information and current notices.',
              'https://www.cssps.gov.gh/',
            ),
            (
              'Ghana Education Service',
              'Read official education notices and find school information.',
              'https://ges.gov.gh/',
            ),
            (
              'Ghana TVET Service',
              'Explore technical and vocational education and training.',
              'https://gtvets.gov.gh/',
            ),
            (
              'Printable choice planner',
              'A simple sheet to fill in with your parent or guidance teacher. Print it or save it as PDF.',
              Uri.base.resolve('choice-planner.html').toString(),
            ),
          ])
            Padding(
              padding: EdgeInsets.zero,
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      resource.$1,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: context.atlas.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      resource.$2,
                      style: TextStyle(color: context.atlas.muted, height: 1.6),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () =>
                          openLink(context, Uri.parse(resource.$3)),
                      icon: const Icon(Icons.open_in_new, size: 18),
                      label: const Text('Open resource'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Your privacy matters',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Text(
              'You can browse without an account. Bookmarks, comparisons and checklist progress are stored on this device. Skool Atlas does not ask for your index number, placement PIN, password or payment details. External websites have their own privacy practices.',
              style: TextStyle(color: context.atlas.muted, height: 1.7),
            ),
          ],
        ),
      ),
    ],
  );
}

int beceAggregate(List<int> core, List<int> electives) {
  if (core.length != 4 ||
      electives.length < 2 ||
      [...core, ...electives].any((v) => v < 1 || v > 9)) {
    throw ArgumentError(
      'Use four core subject grades and at least two elective grades, each between 1 and 9.',
    );
  }
  final sorted = [...electives]..sort();
  return core.reduce((a, b) => a + b) + sorted[0] + sorted[1];
}

class PlacementCheckerPage extends StatefulWidget {
  const PlacementCheckerPage({super.key});
  @override
  State<PlacementCheckerPage> createState() => _PlacementCheckerPageState();
}

class _PlacementCheckerPageState extends State<PlacementCheckerPage> {
  final grades = List<int?>.filled(8, null);
  int? aggregate;
  String? error;
  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
      title: 'BECE planning & official placement',
    subtitle:
        'Understand your grades, then use CSSPS for your real placement result.',
    children: [
      const ResultsCheckerCard(),
      const SizedBox(height: 18),
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Use your results to build an eight-choice draft',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Enter grades and your home town, explore explained school options, check current selection caps and review daily travel.',
              style: TextStyle(color: context.atlas.muted, height: 1.6),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => openPlanningTool(
                context,
                const ResultsPlannerPage(),
                'Results & school choices',
              ),
              icon: const Icon(Icons.auto_graph),
              label: const Text('Open results & choice planner'),
            ),
          ],
        ),
      ),
      const SizedBox(height: 18),
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              Icons.verified_user_outlined,
              size: 38,
              color: context.atlas.primary,
            ),
            const SizedBox(height: 12),
            Text(
              'Check your real placement securely',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Your placement result comes from CSSPS. Open the official portal and follow the current instructions there. Keep your index number and PIN private; you do not need to enter them in Skool Atlas.',
              style: TextStyle(color: context.atlas.muted, height: 1.7),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () =>
                  openLink(context, Uri.parse('https://www.cssps.gov.gh/')),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Open official CSSPS portal'),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Estimate your six-subject aggregate',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Planning tool: four core subjects plus your best two elective grades. Enter grades from your results slip (1–9). This is not an official score, eligibility decision or placement prediction.',
              style: TextStyle(color: context.atlas.muted, height: 1.7),
            ),
            const SizedBox(height: 20),
            PanelGrid(
              children: [
                for (final pair in [
                  'English Language',
                  'Mathematics',
                  'Integrated Science',
                  'Social Studies',
                  'Elective 1',
                  'Elective 2',
                  'Elective 3 (optional)',
                  'Elective 4 (optional)',
                ].indexed)
                  SizedBox(
                    width: double.infinity,
                    child: DropdownButtonFormField<int>(
                      initialValue: grades[pair.$1],
                      isExpanded: true,
                      decoration: InputDecoration(
                        labelText: pair.$2,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      items: [
                        for (var i = 1; i <= 9; i++)
                          DropdownMenuItem(value: i, child: Text('Grade $i')),
                      ],
                      onChanged: (v) => setState(() {
                        grades[pair.$1] = v;
                        aggregate = null;
                        error = null;
                      }),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => setState(() {
                if (grades.take(4).any((g) => g == null) ||
                    grades.skip(4).whereType<int>().length < 2) {
                  error =
                      'Please enter all four core grades and at least two elective grades.';
                  aggregate = null;
                } else {
                  aggregate = beceAggregate(
                    grades.take(4).cast<int>().toList(),
                    grades.skip(4).whereType<int>().toList(),
                  );
                  error = null;
                }
              }),
              child: const Text('Calculate aggregate'),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Semantics(
                  liveRegion: true,
                  child: Text(
                    error!,
                    style: TextStyle(color: context.atlas.danger),
                  ),
                ),
              ),
            if (aggregate != null)
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Semantics(
                  liveRegion: true,
                  child: Surface(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Planning aggregate: $aggregate',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w800,
                            color: context.atlas.primary,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Lower totals indicate stronger grades in this calculation. Discuss these results with your guidance teacher. Selection rules and programme requirements must be checked separately.',
                          style: TextStyle(
                            height: 1.6,
                            color: context.atlas.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    ],
  );
}

/// A content-sized programme row; never constrains scaled text to a fixed height.
class ProgrammeStrip extends StatelessWidget {
  final List<String> programmes;
  const ProgrammeStrip({super.key, required this.programmes});
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: Row(
      children: [
        for (final programme in programmes.take(3))
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: TagChip(label: programme),
          ),
        if (programmes.length > 3) TagChip(label: '+${programmes.length - 3}'),
      ],
    ),
  );
}
