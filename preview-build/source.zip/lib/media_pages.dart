part of 'main.dart';

class CampusStoriesPage extends StatefulWidget {
  const CampusStoriesPage({super.key});
  @override
  State<CampusStoriesPage> createState() => _CampusStoriesPageState();
}

class _CampusStoriesPageState extends State<CampusStoriesPage> {
  String query = '', kind = 'All';
  int limit = 12;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([websiteContent, publishedUpdates]),
    builder: (context, _) {
      final connected = schools
          .where(
            (s) =>
                websiteContent.school(s.id) != null &&
                (websiteContent.items(s.id, 'photos').isNotEmpty ||
                    websiteContent.items(s.id, 'videos').isNotEmpty),
          )
          .toList();
      final matching = connected
          .where(
            (s) =>
                s.searchable.contains(query.trim().toLowerCase()) &&
                (kind != 'Videos' ||
                    websiteContent.items(s.id, 'videos').isNotEmpty) &&
                (kind != 'Photos' ||
                    websiteContent.items(s.id, 'photos').isNotEmpty),
          )
          .toList();
      return PageFrame(
        title: 'Discover campus life',
        subtitle:
            'School-published photos, videos, activities and resources. Open a school to explore its full gallery. Videos play only when you choose them.',
        children: [
          OutlinedButton.icon(
            onPressed: () => Future.wait([
              publishedUpdates.refresh(),
              websiteContent.refresh(),
              accounts.load(),
            ]),
            icon: const Icon(Icons.refresh),
            label: const Text('Check latest school updates'),
          ),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  onChanged: (v) => setState(() {
                    query = v;
                    limit = 12;
                  }),
                  decoration: const InputDecoration(
                    labelText: 'Find a school or region',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final v in ['All', 'Photos', 'Videos'])
                      ChoiceChip(
                        label: Text(v),
                        selected: kind == v,
                        onSelected: (_) => setState(() {
                          kind = v;
                          limit = 12;
                        }),
                      ),
                    ActionChip(
                      label: const Text('Connection coverage'),
                      avatar: const Icon(Icons.fact_check_outlined),
                      onPressed: () => openPlanningTool(
                        context,
                        const SourceCoveragePage(),
                        'Website connections',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (websiteContent.error != null)
            InfoPanel(title: 'Saved content', text: websiteContent.error!),
          Text(
            '${matching.length} connected schools match',
            style: TextStyle(color: context.atlas.muted),
          ),
          PanelGrid(children: [
          for (final school in matching.take(limit))
            Padding(
              padding: EdgeInsets.zero,
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: AtlasStyle.cardRadius,
                      child: Photo(school: school, height: 220),
                    ),
                    const SizedBox(height: 14),
                    SchoolName(school: school),
                    const SizedBox(height: 8),
                    Text(
                      '${school.region} · ${websiteContent.items(school.id, 'photos').length} linked photos · ${websiteContent.items(school.id, 'videos').length} videos',
                      style: TextStyle(color: context.atlas.muted),
                    ),
                    const SizedBox(height: 10),
                    BalancedActions(
                      children: [
                        FilledButton.tonalIcon(
                          onPressed: () => showSchool(context, school),
                          icon: const Icon(Icons.photo_library_outlined),
                          label: const Text('Explore school & gallery'),
                        ),
                        for (final video
                            in websiteContent
                                .items(school.id, 'videos')
                                .take(2))
                          OutlinedButton.icon(
                            onPressed: () => openPlanningTool(
                              context,
                              SchoolVideoPage(video: video),
                              'School video',
                            ),
                            icon: const Icon(Icons.play_circle_outline),
                            label: Text(
                              '${video['title']}'.length > 35
                                  ? 'Watch school video'
                                  : '${video['title']}',
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ]),
          if (matching.isEmpty)
            const InfoPanel(
              title: 'More school stories to come',
              text:
                  'No connected source matches this filter yet. Suggest the school’s public website through the school-update portal.',
            ),
          if (matching.length > limit)
            OutlinedButton(
              onPressed: () => setState(() => limit += 12),
              child: const Text('Show more schools'),
            ),
        ],
      );
    },
  );
}

class SourceCoveragePage extends StatefulWidget {
  const SourceCoveragePage({super.key});
  @override
  State<SourceCoveragePage> createState() => _SourceCoveragePageState();
}

class _SourceCoveragePageState extends State<SourceCoveragePage> {
  String query = '';
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: websiteContent,
    builder: (context, _) {
      final rows = schools
          .where((s) => s.searchable.contains(query.trim().toLowerCase()))
          .take(query.trim().length >= 2 ? 30 : 0);
      return PageFrame(
        maxWidth: 900,
        title: 'School sources & coverage',
        subtitle:
            'See what is connected, what was checked and what still needs evidence. Coverage is never a school ranking.',
        children: [
          InfoPanel(
            title:
                '${websiteContent.approved.length} reviewed website connections',
            text:
                '${schools.length} catalogue profiles across Ghana. Some schools have no identifiable website; others are inaccessible or outdated. A connected website does not prove that every page or photograph is current.',
          ),
          if (publishedUpdates.checkedAt != null)
            InfoPanel(
              title: 'Reviewed catalogue updates',
              text:
                  'Last feed check: ${publishedUpdates.checkedAt}. ${publishedUpdates.error ?? 'Administrator-approved facts are applied with their source and observation date.'}',
            ),
          Surface(
            child: Column(
              children: [
                TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: const InputDecoration(
                    labelText: 'Check any school’s connection',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                for (final s in rows)
                  ListTile(
                    title: Text(s.name),
                    subtitle: Text(
                      websiteContent.school(s.id) == null
                          ? 'No reviewed website connection yet'
                          : '${websiteContent.school(s.id)!['status']} · checked ${websiteContent.school(s.id)!['checkedAt']}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => showSchool(context, s),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () => openPlanningTool(
              context,
              const SchoolPortalPage(),
              'Suggest a source',
            ),
            icon: const Icon(Icons.add_link),
            label: const Text('Suggest a school website / correction'),
          ),
          const InfoPanel(
            title: 'How updates work',
            text:
                'A scheduled scanner checks reviewed public pages for images, video links, documents and changes. Removed or inaccessible pages keep their last available content with a warning. Programme and achievement changes require factual review before they change recommendations. Hosting and scheduler activation remain launch tasks.',
          ),
        ],
      );
    },
  );
}

class SchoolDistancePanel extends StatefulWidget {
  final School school;
  const SchoolDistancePanel({super.key, required this.school});
  @override
  State<SchoolDistancePanel> createState() => _SchoolDistancePanelState();
}

class _SchoolDistancePanelState extends State<SchoolDistancePanel> {
  final latitude = TextEditingController(), longitude = TextEditingController();
  double? km;
  String? error;
  @override
  void dispose() {
    latitude.dispose();
    longitude.dispose();
    super.dispose();
  }

  void calculate() {
    final lat = double.tryParse(latitude.text),
        lon = double.tryParse(longitude.text),
        pin = widget.school.data['coordinates'] as Map?;
    if (lat == null ||
        lon == null ||
        !lat.isFinite ||
        !lon.isFinite ||
        lat < 4 ||
        lat > 12 ||
        lon < -4 ||
        lon > 2 ||
        pin == null) {
      setState(
        () => error =
            'Enter a valid approximate Ghana location and use a school with sourced coordinates.',
      );
      return;
    }
    final p1 = lat * math.pi / 180,
        p2 = (pin['latitude'] as num) * math.pi / 180,
        dp = p2 - p1,
        dl = ((pin['longitude'] as num) - lon) * math.pi / 180;
    final a =
        math.pow(math.sin(dp / 2), 2) +
        math.cos(p1) * math.cos(p2) * math.pow(math.sin(dl / 2), 2);
    setState(() {
      km =
          6371 *
          2 *
          math.atan2(math.sqrt(a.clamp(0, 1)), math.sqrt((1 - a).clamp(0, 1)));
      error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pin = widget.school.data['coordinates'] as Map?;
    return Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Plan your day-school journey',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Text(
            pin == null
                ? 'Verified campus coordinates have not been added. Use the map and confirm the route and catchment with the school.'
                : 'Campus pin checked ${pin['observed']}. An optional approximate starting point can calculate straight-line distance. It stays on this screen and is not saved or sent.',
          ),
          if (pin != null) ...[
            const SizedBox(height: 12),
            TextField(
              controller: latitude,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
                signed: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Approximate starting latitude',
              ),
            ),
            TextField(
              controller: longitude,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
                signed: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Approximate starting longitude',
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton(
              onPressed: calculate,
              child: const Text('Calculate straight-line distance'),
            ),
            if (km != null)
              Text(
                '${km!.toStringAsFixed(1)} km in a straight line. Road distance and travel time may be much greater. This is not a catchment or CSSPS eligibility decision.',
              ),
            if (error != null) Text(error!),
          ],
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () => openLink(context, widget.school.mapUri),
            icon: const Icon(Icons.directions_outlined),
            label: const Text('Check road route & transport'),
          ),
        ],
      ),
    );
  }
}
