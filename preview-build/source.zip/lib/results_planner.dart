part of 'main.dart';

class ResultsPlannerPage extends StatefulWidget {
  final bool resumeSaved;
  const ResultsPlannerPage({super.key, this.resumeSaved = false});
  @override
  State<ResultsPlannerPage> createState() => _ResultsPlannerPageState();
}

class _ResultsPlannerPageState extends State<ResultsPlannerPage> {
  final grades = <String, int>{};
  final choices = <SchoolChoice>[];
  final town = TextEditingController(),
      jhsTown = TextEditingController(),
      search = TextEditingController();
  int step = 0, limit = 8;
  int? aggregate;
  String region = '',
      district = '',
      gender = 'Not entered',
      programme = 'General Science',
      scope = 'Region & boarding',
      track = 'General',
      draftStyle = 'Balanced categories',
      resultType = 'Actual results';
  String? error;
  void resetTravelChecks() {
    for (final choice in choices.where((c) => c.residence == 'Day')) {
      choice.commuteConfirmed = false;
      choice.catchmentConfirmed = false;
    }
  }

  void sourceChanged() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    publishedUpdates.addListener(sourceChanged);
    if (widget.resumeSaved) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) loadDraft();
      });
    }
  }

  @override
  void dispose() {
    publishedUpdates.removeListener(sourceChanged);
    town.dispose();
    jhsTown.dispose();
    search.dispose();
    super.dispose();
  }

  void loadDraft() {
    final data = planningStore.savedPlan;
    if (data == null) return;
    setState(() {
      grades
        ..clear()
        ..addAll(Map<String, int>.from(data['grades'] as Map? ?? {}));
      town.text = '${data['town'] ?? ''}';
      jhsTown.text = '${data['jhsTown'] ?? ''}';
      region = '${data['region'] ?? ''}';
      district = '${data['district'] ?? ''}';
      gender = '${data['gender'] ?? 'Not entered'}';
      programme = '${data['programme'] ?? 'General Science'}';
      track = '${data['track'] ?? 'General'}';
      draftStyle = '${data['draftStyle'] ?? 'Balanced categories'}';
      resultType = '${data['resultType'] ?? 'Actual results'}';
      choices
        ..clear()
        ..addAll(
          (data['choices'] as List? ?? []).map(
            (c) => SchoolChoice.fromJson(c as Map),
          ),
        );
      try {
        aggregate = resultsAggregate(grades);
      } on ArgumentError {
        aggregate = null;
      }
    });
  }

  Future<void> saveDraft() async {
    await planningStore.savePlan({
      'schema': 'choice-plan-v1',
      'grades': grades,
      'town': town.text.trim(),
      'jhsTown': jhsTown.text.trim(),
      'region': region,
      'district': district,
      'gender': gender,
      'programme': programme,
      'track': track,
      'draftStyle': draftStyle,
      'resultType': resultType,
      'choices': choices.map((c) => c.toJson()).toList(),
      'saved': DateTime.now().toIso8601String(),
    });
    if (mounted) {
      toast(
        context,
        planningStore.persistent
            ? 'Draft saved on this device, including the grades and town you entered.'
            : 'Device storage is unavailable. Download your school-choice pack instead.',
      );
    }
  }

  void calculate() {
    try {
      final value = resultsAggregate(grades);
      final paths = gradeStudyPaths(grades);
      setState(() {
        aggregate = value;
        error = null;
        if (paths.isNotEmpty &&
            !paths.any(
              (p) =>
                  p.programme == programme && p.average == paths.first.average,
            )) {
          programme = paths.first.programme;
        }
      });
    } on ArgumentError catch (e) {
      setState(() => error = '${e.message}');
    }
  }

  void suggestDraft(List<SchoolMatch> options) {
    setState(() {
      choices.addAll(
        buildSuggestedChoices(
          options: options.map((m) => m.school).toList(),
          programme: programme,
          region: region,
          town: town.text,
          gender: gender,
          district: district,
          style: draftStyle,
          scope: scope,
        ),
      );
    });
    toast(
      context,
      '${choices.length} of 8 draft choices found. ${choices.length < 8 ? 'Not enough suitable options. Check your town/district and ask your JHS about reachable Day schools. ' : ''}Review order and daily travel. These are options to discuss, not confirmed admission eligibility.',
    );
  }

  Future<void> addSchool(School school) async {
    if (school.programs.isEmpty || !school.selectable) {
      toast(
        context,
        'Current programmes or operation need confirmation before adding this school.',
      );
      return;
    }
    if (choices.length >= 8) {
      toast(
        context,
        'Your draft already has eight choices. Remove one to add another.',
      );
      return;
    }
    if (choices.any((c) => c.schoolId == school.id)) {
      toast(context, 'This school is already in your draft.');
      return;
    }
    String p = school.programs.contains(programme)
        ? programme
        : school.programs.first;
    final residences = ['Day', 'Boarding']
        .where(school.residency.contains)
        .where((r) => school.category != 'Pilot private' || r == 'Day')
        .toList();
    if (residences.isEmpty) {
      toast(context, 'Confirm this school residence before adding it.');
      return;
    }
    String residence = residences.contains('Day') && school.region == region
        ? 'Day'
        : residences.last;
    final choice = await showDialog<SchoolChoice>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: const Text('Add a school choice'),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SchoolName(
                    school: school,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<String>(
                    initialValue: p,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Programme for this choice',
                    ),
                    items: school.programs
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => update(() => p = v!),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    initialValue: residence,
                    decoration: const InputDecoration(
                      labelText: 'Residence for this choice',
                    ),
                    items: residences
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => update(() => residence = v!),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Add this to a draft for discussion. Review the exact subject combination and school code before official submission.',
                    style: TextStyle(color: context.atlas.muted, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(
                dialogContext,
                SchoolChoice(
                  schoolId: school.id,
                  programme: p,
                  residence: residence,
                  reviewedSignature: school.selectionSignature,
                ),
              ),
              child: const Text('Add to my eight choices'),
            ),
          ],
        ),
      ),
    );
    if (choice != null && mounted) setState(() => choices.add(choice));
  }

  @override
  Widget build(BuildContext context) {
    final paths = aggregate == null
        ? <({String programme, double average, List<String> subjects})>[]
        : gradeStudyPaths(grades);
    final programmes =
        schools
            .where((s) => s.data['registerYear'] == 2026)
            .expand((s) => s.programs)
            .toSet()
            .toList()
          ..sort();
    if (!programmes.contains(programme)) programmes.add(programme);
    final regions = schools.map((s) => s.region).toSet().toList()..sort();
    final districts =
        schools
            .where((s) => s.region == region)
            .map((s) => '${s.data['district'] ?? ''}')
            .where((d) => d.isNotEmpty)
            .toSet()
            .toList()
          ..sort();
    final options = region.isEmpty
        ? <SchoolMatch>[]
        : resultsSchoolOptions(
                programme: programme,
                region: region,
                district: district,
                town: town.text,
                gender: gender,
                scope: scope,
                query: search.text,
              )
              .where(
                (m) =>
                    track != 'TVET only' || m.school.kind == 'TVET / technical',
              )
              .where(
                (m) =>
                    track != 'Science / STEM' ||
                    ['General Science', 'STEM'].contains(programme),
              )
              .toList();
    final checks = validateSchoolChoices(
      choices,
      gender: gender,
      town: town.text,
      region: region,
      track: track,
    );
    return PageFrame(
      title: 'Plan with your results',
      subtitle:
          'Use your actual or expected grades, explore study paths and check eight choices with your family and JHS guidance teacher.',
      children: [
        const ResultsCheckerCard(compact: true),
        const SizedBox(height: 18),
        const OfficialSelectionSummary(compact: true),
        if (step == 2 || choices.isNotEmpty)
          DraftProgressPanel(choices: choices, checks: checks),
        const SizedBox(height: 18),
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  for (var i = 0; i < 3; i++)
                    ChoiceChip(
                      label: Text(
                        [
                          '1  My results',
                          '2  Where I live',
                          '3  Schools & eight choices',
                        ][i],
                      ),
                      selected: step == i,
                      onSelected: (_) => setState(() => step = i),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Text('Grades only. Never enter an index number or checker PIN.', style: TextStyle(color: context.atlas.muted, fontSize: 12)),
              const SizedBox(height: 4),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Privacy & saved drafts'),
                children: [
                  const Text(
                    'Your results stay with you',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Enter grades only - no index number, PIN, date of birth or student name. Grades and home location stay in this screen unless you choose Save draft on this device. Downloaded school packs exclude your grades and home address.',
                    style: TextStyle(color: context.atlas.muted, height: 1.6),
                  ),
                  const SizedBox(height: 16),
                  BalancedActions(
                    children: [
                      TextButton.icon(
                        onPressed: saveDraft,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('Save draft on this device'),
                      ),
                      TextButton(
                        onPressed: planningStore.savedPlan == null
                            ? null
                            : loadDraft,
                        child: const Text('Load saved draft'),
                      ),
                      TextButton(
                        onPressed: planningStore.savedPlan == null
                            ? null
                            : () async {
                                await planningStore.forgetPlan();
                                if (mounted && context.mounted) {
                                  setState(() {});
                                  toast(
                                    context,
                                    'Saved device draft deleted. Your current on-screen work is still open.',
                                  );
                                }
                              },
                        child: const Text('Delete saved device draft'),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (step == 0) ...[
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Enter your BECE grades',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final type in ['Actual results', 'Expected grades'])
                      ChoiceChip(
                        label: Text(type),
                        selected: resultType == type,
                        onSelected: (_) => setState(() => resultType = type),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Grade 1 is the strongest; grade 9 is the lowest. Enter all four core subjects and at least two other subjects. Leave subjects you did not take blank.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                const SizedBox(height: 18),
                LayoutBuilder(
                  builder: (context, constraints) => Wrap(
                    spacing: 12,
                    runSpacing: 20,
                    children: [
                      for (final subject in [...coreSubjects, ...otherSubjects])
                        SizedBox(
                          width: constraints.maxWidth >= 760
                              ? (constraints.maxWidth - 24) / 3
                              : constraints.maxWidth < 340 ||
                                    MediaQuery.textScalerOf(context).scale(14) >
                                        18
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 12) / 2,
                          child: DropdownButtonFormField<int>(
                            key: ValueKey('grade-$subject-${grades[subject]}'),
                            initialValue: grades[subject],
                            isExpanded: true,
                            decoration: InputDecoration(
                              labelText: subject,
                              labelStyle: const TextStyle(fontSize: 12),
                              helperText: coreSubjects.contains(subject)
                                  ? 'Core subject'
                                  : 'Other subject',
                            ),
                            items: [
                              const DropdownMenuItem<int>(
                                value: null,
                                child: Text('Not entered'),
                              ),
                              for (var g = 1; g <= 9; g++)
                                DropdownMenuItem(
                                  value: g,
                                  child: Text('Grade $g'),
                                ),
                            ],
                            onChanged: (g) => setState(() {
                              if (g == null) {
                                grades.remove(subject);
                              } else {
                                grades[subject] = g;
                              }
                              aggregate = null;
                            }),
                          ),
                        ),
                    ],
                  ),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(
                      error!,
                      style: const TextStyle(color: Colors.deepOrange),
                    ),
                  ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: calculate,
                  icon: const Icon(Icons.calculate_outlined),
                  label: const Text('Analyse my grades'),
                ),
              ],
            ),
          ),
          if (aggregate != null) ...[
            const SizedBox(height: 18),
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your six-subject aggregate: $aggregate',
                    style: TextStyle(
                      fontSize: 27,
                      fontWeight: FontWeight.w800,
                      color: context.atlas.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '$resultType: English + Mathematics + Science + Social Studies + your best two other subject grades.',
                    style: TextStyle(color: context.atlas.muted, height: 1.6),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Study paths to discuss',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'These suggestions compare your entered subject grades. They are not school admission cut-offs, career eligibility rules or guarantees. You can explore another programme based on your interests.',
                    style: TextStyle(color: context.atlas.muted, height: 1.6),
                  ),
                  for (final path in paths.where(
                    (p) =>
                        p.average <=
                        paths[paths.length < 3 ? paths.length - 1 : 2].average,
                  ))
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(path.programme),
                      subtitle: Text(
                        'Based on ${path.subjects.map((s) => '$s (${grades[s]})').join(', ')}',
                      ),
                      trailing: TextButton(
                        onPressed: () =>
                            setState(() => programme = path.programme),
                        child: Text(
                          programme == path.programme ? 'Selected' : 'Explore',
                        ),
                      ),
                    ),
                  if (grades['English Language'] == 9 ||
                      grades['Mathematics'] == 9)
                    Padding(
                      padding: EdgeInsets.only(top: 12),
                      child: Text(
                        'Grade 9 in English or Mathematics needs careful guidance. A September 2026 ministerial announcement reported self-placement opportunities for these candidates. Check your actual status on CSSPS; this planner does not disqualify you automatically.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          height: 1.6,
                        ),
                      ),
                    ),
                  const SizedBox(height: 14),
                  FilledButton(
                    onPressed: () => setState(() => step = 1),
                    child: const Text('Next: where I live'),
                  ),
                ],
              ),
            ),
          ],
        ],
        if (step == 1)
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Find options you can realistically attend',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: town,
                  decoration: const InputDecoration(
                    labelText: 'Your home town or community',
                    hintText: 'For example, Bawjiase',
                  ),
                  onChanged: (_) => setState(resetTravelChecks),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('home-region-$region'),
                  initialValue: region.isEmpty ? null : region,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Your home region',
                  ),
                  items: regions
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() {
                    region = r!;
                    district = '';
                    resetTravelChecks();
                  }),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('home-district-$region-$district'),
                  initialValue:
                      district.isEmpty || !districts.contains(district)
                      ? null
                      : district,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Your district (helps find nearby options)',
                  ),
                  items: districts
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() {
                    district = r!;
                    resetTravelChecks();
                  }),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: jhsTown,
                  onChanged: (_) => setState(resetTravelChecks),
                  decoration: const InputDecoration(
                    labelText: 'Your JHS town (optional)',
                    helperText:
                        'Discuss catchment eligibility with your JHS guidance teacher.',
                  ),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('candidate-gender-$gender'),
                  initialValue: gender,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText:
                        'Candidate gender (needed for a suggested draft)',
                  ),
                  items: ['Not entered', 'Male', 'Female']
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() => gender = r!),
                ),
                const SizedBox(height: 18),
                Text(
                  'Town and district matches are a starting point. We do not calculate travel distance from a town name or assume that the nearest listed school has a place. Use the map and ask your guardian about cost, safety, travel time and daily attendance.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () {
                    if (town.text.trim().isEmpty || region.isEmpty) {
                      toast(context, 'Enter your home town and region first.');
                      return;
                    }
                    setState(() => step = 2);
                  },
                  child: const Text('Next: explore suitable options'),
                ),
              ],
            ),
          ),
        if (step == 2) ...[
          if (aggregate == null)
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Surface(
                child: Text(
                  'You can explore programmes and choices now. Add grades in Step 1 to see your aggregate and subject-strength suggestions.',
                ),
              ),
            ),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  aggregate == null
                      ? 'Explore your programme options'
                      : 'Aggregate $aggregate | Explore your programme options',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Schools below match your selected programme, school gender and location/residence preferences. Grades help you discuss study paths; this catalogue has no verified school-by-programme grade cut-offs to decide admission.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('planner-programme-$programme'),
                  initialValue: programme,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Programme I want to explore',
                  ),
                  items: programmes
                      .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                      .toList(),
                  onChanged: (p) => setState(() {
                    programme = p!;
                    limit = 8;
                  }),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  initialValue: scope,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Where to look'),
                  items:
                      [
                            'Nearby day schools',
                            'Day schools in my region',
                            'Region & boarding',
                            'Boarding across Ghana',
                          ]
                          .map(
                            (p) => DropdownMenuItem(value: p, child: Text(p)),
                          )
                          .toList(),
                  onChanged: (p) => setState(() {
                    scope = p!;
                    limit = 8;
                  }),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  key: ValueKey('planner-track-$track'),
                  initialValue: track,
                  decoration: const InputDecoration(
                    labelText: 'Selection track',
                  ),
                  items: ['General', 'TVET only', 'Science / STEM']
                      .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                      .toList(),
                  onChanged: (p) => setState(() => track = p!),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: search,
                  decoration: const InputDecoration(
                    labelText: 'Search within these options',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (_) => setState(() => limit = 8),
                ),
                const SizedBox(height: 14),
                Text(
                  '${options.length} matching options | ${town.text.trim()}, $region${district.isEmpty ? '' : ' | $district'}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  initialValue: draftStyle,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'How to build my starting draft',
                  ),
                  items:
                      [
                            'Balanced categories',
                            'Category C focus',
                            'Day-only draft',
                          ]
                          .map(
                            (v) => DropdownMenuItem(value: v, child: Text(v)),
                          )
                          .toList(),
                  onChanged: (v) => setState(() => draftStyle = v!),
                ),
                const SizedBox(height: 8),
                Text(
                  'This is your preference, not a grade-based eligibility band. Automatic Day choices must match your listed town or selected district; a shared region alone is not enough. If there are too few local candidates, the draft stays incomplete. Town/district matches still need a real journey check and JHS catchment confirmation. The builder skips unresolved identities/codes and respects category and Boarding limits.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed:
                      options.isEmpty ||
                          choices.isNotEmpty ||
                          !['Male', 'Female'].contains(gender)
                      ? null
                      : () => suggestDraft(options),
                  icon: const Icon(Icons.playlist_add_check),
                  label: const Text('Suggest an eight-choice draft'),
                ),
                if (!['Male', 'Female'].contains(gender))
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      'Confirm the gender on your official candidate record in Step 2 before generating a draft. You can still browse school options.',
                      style: TextStyle(color: context.atlas.muted, height: 1.5),
                    ),
                  ),
                if (options.isEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'No options found. Try another programme, expand from nearby day schools to your region, or ask your JHS for a reachable school. The app cannot establish the closest school without verified coordinates.',
                      style: TextStyle(color: context.atlas.muted, height: 1.6),
                    ),
                  ),
              ],
            ),
          ),
          for (final match in options.take(limit))
            Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SchoolName(
                      school: match.school,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (final reason in match.reasons)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Text(
                          reason,
                          style: TextStyle(
                            color: context.atlas.muted,
                            height: 1.5,
                          ),
                        ),
                      ),
                    if (match.school.data['registerCodeConflict'] == true)
                      const Text(
                        'Printed school code needs confirmation before official selection.',
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 12,
                        ),
                      ),
                    BalancedActions(
                      children: [
                        FilledButton.tonal(
                          onPressed: () => addSchool(match.school),
                          child: const Text('Add to my choices'),
                        ),
                        TextButton(
                          onPressed: () => showSchool(context, match.school),
                          child: const Text('View profile'),
                        ),
                        TextButton(
                          onPressed: () =>
                              openLink(context, match.school.mapUri),
                          child: const Text('Check school map'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          if (options.length > limit)
            TextButton(
              onPressed: () => setState(() => limit += 8),
              child: const Text('Show more school options'),
            ),
          const SizedBox(height: 24),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'My eight choices (${choices.length}/8)',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Rank schools in your real order of preference. A school may appear once. Confirm daily travel for every Day option.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                TextButton.icon(
                  onPressed: choices.isEmpty
                      ? null
                      : () => setState(() {
                          final ordered = arrangeSchoolChoices(choices);
                          choices
                            ..clear()
                            ..addAll(ordered);
                        }),
                  icon: const Icon(Icons.sort),
                  label: const Text(
                    'Arrange A → B → C, Day last within each group',
                  ),
                ),
                Text(
                  'Suggested drafts start in this category order. Day choices remain within their categories, with a Category C Day choice last when available. You may move choices into your actual preference order before official submission.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
                if (choices.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 18),
                    child: Text(
                      'Add schools from the options above, or use the draft suggestion to start.',
                    ),
                  ),
                for (var i = 0; i < choices.length; i++)
                  choiceCard(choices[i], i),
                const SizedBox(height: 18),
                const Text(
                  'Rule checks',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                ),
                if (!checks.any((c) => c.error))
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'The coded choice checks pass. Your JHS / guardian must still verify catchment, current rules and availability before official submission.',
                      style: TextStyle(
                        color: context.atlas.primary,
                        fontWeight: FontWeight.w700,
                        height: 1.6,
                      ),
                    ),
                  ),
                for (final check in checks)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          check.error ? Icons.info_outline : Icons.history,
                          size: 19,
                          color: check.error
                              ? Colors.deepOrange
                              : context.atlas.muted,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            check.message,
                            style: const TextStyle(height: 1.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 18),
                ExportChoiceActions(
                  checks: checks,
                  selected: choices
                      .map((c) => c.school)
                      .whereType<School>()
                      .toList(),
                  choices: choices,
                ),
                const SizedBox(height: 16),
                BalancedActions(
                  children: [
                    FilledButton.icon(
                      onPressed: saveDraft,
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Save this draft on my device'),
                    ),
                    OutlinedButton(
                      onPressed: choices.isEmpty
                          ? null
                          : () => openPlanningTool(
                              context,
                              OfflineChoicesPage(
                                selected: choices
                                    .map((c) => c.school)
                                    .whereType<School>()
                                    .toList(),
                              ),
                              'Take my choices offline',
                            ),
                      child: const Text('Download / share chosen schools'),
                    ),
                    TextButton(
                      onPressed: choices.isEmpty
                          ? null
                          : () => setState(choices.clear),
                      child: const Text('Clear on-screen choices'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 24),
        const SelectionRulesPanel(),
      ],
    );
  }

  Widget choiceCard(SchoolChoice choice, int index) {
    final school = choice.school;
    if (school == null) {
      return ListTile(
        title: const Text('School needs remapping'),
        trailing: IconButton(
          tooltip: 'Remove choice',
          onPressed: () => setState(() => choices.removeAt(index)),
          icon: const Icon(Icons.close),
        ),
      );
    }
    return Container(
      margin: const EdgeInsets.only(top: 18),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.atlas.lightBg,
        border: Border.all(color: context.atlas.border),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Material(
        color: Colors.transparent,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: context.atlas.primarySoft,
                  child: Text(
                    '${index + 1}',
                    style: TextStyle(
                      color: context.atlas.primary,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SchoolName(
                    school: school,
                    badgeSize: 32,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              '${choice.selectionCategory} | ${choice.programme} | ${choice.residence}\nSchool code: ${school.data['code'] ?? 'Unconfirmed'}',
              style: TextStyle(color: context.atlas.muted, height: 1.6),
            ),
            if (choice.reviewedSignature.isNotEmpty &&
                choice.reviewedSignature != school.selectionSignature) ...[
              const SizedBox(height: 12),
              const Text(
                'School details changed. Check the programme, residence and code again. Remove and add this choice again if your programme is no longer offered.',
                style: TextStyle(color: Colors.deepOrange, height: 1.5),
              ),
              OutlinedButton.icon(
                onPressed:
                    school.programs.contains(choice.programme) &&
                        school.residency.contains(choice.residence) &&
                        school.selectable
                    ? () => setState(() {
                        choice.reviewedSignature = school.selectionSignature;
                        choice.codeConfirmed = false;
                        choice.commuteConfirmed = false;
                        choice.catchmentConfirmed = false;
                      })
                    : null,
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('I reviewed the updated details'),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                IconButton(
                  tooltip: 'Move choice up',
                  onPressed: index == 0
                      ? null
                      : () => setState(() {
                          final previous = choices.removeAt(index);
                          choices.insert(index - 1, previous);
                        }),
                  icon: const Icon(Icons.arrow_upward),
                ),
                IconButton(
                  tooltip: 'Move choice down',
                  onPressed: index == choices.length - 1
                      ? null
                      : () => setState(() {
                          final previous = choices.removeAt(index);
                          choices.insert(index + 1, previous);
                        }),
                  icon: const Icon(Icons.arrow_downward),
                ),
                TextButton(
                  onPressed: () => setState(() => choices.removeAt(index)),
                  child: const Text('Remove'),
                ),
                TextButton(
                  onPressed: () => showSchool(context, school),
                  child: const Text('View school'),
                ),
              ],
            ),
            if (school.category == 'Pilot private')
              DropdownButtonFormField<String>(
                isExpanded: true,
                initialValue: choice.pilotCategory,
                decoration: const InputDecoration(
                  labelText: 'Pilot private selection group',
                ),
                items: ['Category B', 'Category C']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (c) => setState(() => choice.pilotCategory = c!),
              ),
            if (choice.residence == 'Day') ...[
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.catchmentConfirmed,
                onChanged: (v) =>
                    setState(() => choice.catchmentConfirmed = v!),
                title: const Text(
                  'My JHS or the school office confirmed that I can select this Day option.',
                ),
                subtitle: const Text(
                  'Your confirmation only; Skool Atlas has not verified official catchment boundaries.',
                ),
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.commuteConfirmed,
                onChanged: (v) => setState(() => choice.commuteConfirmed = v!),
                title: const Text(
                  'My guardian and I checked that I can realistically attend this Day school daily.',
                ),
                subtitle: const Text(
                  'Confirm catchment with your JHS; the app has not measured travel distance.',
                ),
              ),
              TextButton.icon(
                onPressed: () => openLink(
                  context,
                  Uri.https('www.google.com', '/maps/dir/', {
                    'api': '1',
                    'origin': '${town.text}${district.isEmpty ? '' : ', $district'}, $region, Ghana',
                    'destination': '${school.name}, ${school.location}',
                  }),
                ),
                icon: const Icon(Icons.directions_outlined),
                label: const Text('Check the journey from my town'),
              ),
              const ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text('Check the practical daily journey'),
                children: [
                  Padding(
                    padding: EdgeInsets.only(bottom: 12),
                    child: Text(
                      'Check the exact campus and a normal school-morning route. Review journey time in both directions, changes of transport, return fares, arrival time, road safety and rainy-day alternatives with your guardian. A map estimate is not an official catchment decision. Do not share your exact home address in pilot feedback.',
                    ),
                  ),
                ],
              ),
            ],
            if (school.data['registerCodeConflict'] == true)
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.codeConfirmed,
                onChanged: (v) => setState(() => choice.codeConfirmed = v!),
                title: const Text(
                  'I confirmed the exact school code with my JHS / the school office.',
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class OfficialSelectionSummary extends StatelessWidget {
  final bool compact;
  const OfficialSelectionSummary({super.key, this.compact = false});
  @override
  Widget build(BuildContext context) => compact
      ? Surface(
          padding: const EdgeInsets.all(8),
          child: ExpansionTile(
            leading: Icon(
              Icons.fact_check_outlined,
              color: context.atlas.primary,
            ),
            title: const Text(
              'Before you build your eight choices',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: const Text(
              'Categories are selection groups. Suggestions cannot guarantee admission.',
            ),
            childrenPadding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            children: const [OfficialSelectionSummary()],
          ),
        )
      : Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'School categories are not your BECE grades',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: context.atlas.primaryDark,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'WAEC grades run from 1 (highest) to 9 (lowest). Category A, B and C are school-selection groups. The official manual does not give a compulsory category mix for a particular aggregate.',
                style: TextStyle(height: 1.6),
              ),
              const SizedBox(height: 12),
              const Text(
                '8 choices · maximum 2 Category A · maximum 3 Category B\nMaximum 5 Boarding · maximum 1 A Boarding · maximum 2 B Boarding',
                style: TextStyle(fontWeight: FontWeight.w700, height: 1.6),
              ),
              const SizedBox(height: 8),
              Text(
                'Day is a residence option within a category, not a separate eighth category. With eight choices and a maximum of five Boarding, at least three must be Day. All eight may be Category C or Day. You do not have to fill the A/B maximums.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
              const SizedBox(height: 8),
              Text(
                'Grades help suggest study paths. This app has no verified school/programme grade cut-off table and cannot decide that you qualify for admission. Official self-placement choices depend on current vacancies and your candidate record.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
              BalancedActions(
                children: [
                  TextButton.icon(
                    onPressed: () =>
                        openLink(context, Uri.parse(selectionManualUrl)),
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Official CSSPS selection rules'),
                  ),
                  TextButton(
                    onPressed: () => openLink(
                      context,
                      Uri.parse('https://waecgh.org/home/bece-school/'),
                    ),
                    child: const Text('WAEC grading explained'),
                  ),
                  TextButton(
                    onPressed: () => openLink(
                      context,
                      Uri.parse('https://www.cssps.gov.gh/vacancies'),
                    ),
                    child: const Text('Official vacancy directory'),
                  ),
                ],
              ),
              Text(
                'Sources checked 16 October 2026. Confirm the current instructions with your JHS before official submission.',
                style: TextStyle(fontSize: 12, color: context.atlas.muted),
              ),
            ],
          ),
        );
}

class SelectionRulesPanel extends StatelessWidget {
  const SelectionRulesPanel({super.key});
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'School-selection requirements',
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.w800,
            color: context.atlas.primaryDark,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Rule snapshot checked 16 October 2026. Follow the current CSSPS instructions and your JHS guidance teacher before final submission.',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        const SizedBox(height: 16),
        for (final line in [
          'Choose exactly eight different schools and rank them in order of preference. Select a programme and residence for each.',
          'Use at most five Boarding choices. The current CSSPS manual permits all eight choices to be Day.',
          'Category A: at most two schools, including at most one Boarding choice.',
          'Category B: at most three schools, including at most two Boarding choices. All eight schools may be Category C.',
          'These are maximums, not a grade-based quota. Day is a residence within Category A/B/C, not a separate school category. A strong or weaker aggregate does not create a different category rule in this manual.',
          'Day schools should be realistically reachable from your catchment area. Review daily travel with your guardian and confirm the catchment rule with your JHS.',
          'The sourced 2026 register lists pilot private schools as Category B/C Day options. Verify the actual school and programme on the official form.',
          'The register describes all-TVET choices for a purely TVET track, and Science/STEM programmes throughout a Science/STEM track. Confirm specialist subject combinations.',
          'Have a parent/guardian and your JHS check the final form. Keep a signed copy. Review every detail before confirming; confirmation can be final.',
        ])
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.check_circle_outline,
                  size: 19,
                  color: context.atlas.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(line, style: const TextStyle(height: 1.6)),
                ),
              ],
            ),
          ),
        Text(
          'Source difference: the printed 2026 register describes a five-Boarding/three-Day pattern, while the current CSSPS manual explicitly allows all-Day choices. The coded Boarding/category caps follow the current CSSPS manual. Confirm any later changes with CSSPS.',
          style: TextStyle(
            color: context.atlas.muted,
            fontSize: 12,
            height: 1.6,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Selection after results is reported in a September 2026 GES statement carried by GNA. GES/CSSPS administer school selection; WAEC provides examination results. On the 16 October check, CSSPS displayed choice confirmation as closed and self-placement as open. That is a dated observation, not a live service-status promise.',
          style: TextStyle(
            color: context.atlas.muted,
            fontSize: 12,
            height: 1.6,
          ),
        ),
        const SizedBox(height: 14),
        BalancedActions(
          children: [
            FilledButton(
              onPressed: () =>
                  openLink(context, Uri.parse('https://www.cssps.gov.gh/')),
              child: const Text('Open official CSSPS portal'),
            ),
            TextButton(
              onPressed: () => openLink(context, Uri.parse(selectionManualUrl)),
              child: const Text('Current CSSPS candidate manual'),
            ),
            TextButton(
              onPressed: () =>
                  openLink(context, Uri.parse(selectionRegisterUrl)),
              child: const Text('Sourced 2026 selection register'),
            ),
            TextButton(
              onPressed: () => openLink(
                context,
                Uri.parse(
                  'https://gna.org.gh/2026/09/ges-defends-post-bece-shs-selection-amid-placement-concerns/',
                ),
              ),
              child: const Text('GES post-results selection report'),
            ),
            TextButton(
              onPressed: () => openLink(
                context,
                Uri.parse(
                  'https://gna.org.gh/2026/09/bece-candidates-with-grade-nine-in-english-maths-eligible-for-self-placement/',
                ),
              ),
              child: const Text('2026 Grade 9 / self-placement report'),
            ),
          ],
        ),
      ],
    ),
  );
}
