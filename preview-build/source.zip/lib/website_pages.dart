part of 'main.dart';

class SchoolWebsiteSection extends StatefulWidget {
  final School school;
  const SchoolWebsiteSection({super.key, required this.school});
  @override
  State<SchoolWebsiteSection> createState() => _SchoolWebsiteSectionState();
}

class _SchoolWebsiteSectionState extends State<SchoolWebsiteSection> {
  String tab = 'Photos';
  int photoLimit = 6;
  int videoLimit = 6;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([websiteContent, publishedUpdates]),
    builder: (context, _) {
      final reviewedMedia = publishedUpdates.media[widget.school.id] ?? [];
      final row =
          websiteContent.school(widget.school.id) ??
          (reviewedMedia.isEmpty
              ? null
              : <String, dynamic>{
                  'website': reviewedMedia.first['source'],
                  'status': 'ok',
                  'lastSuccessAt': widget.school.data['lastReviewedUpdate'],
                  'sourceNotice':
                      'Administrator-reviewed media from the linked publisher. This does not establish a full school-website connection.',
                });
      if (row == null) {
        return Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'School website & media',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Text(
                websiteContent.approved.containsKey(widget.school.id)
                    ? 'This website is approved and waiting for its next source refresh. Available local photos and reviewed facts are shown on this profile.'
                    : 'A verified public website connection has not been added for this school yet. Its available local photos and reviewed information appear elsewhere on this profile.',
                style: TextStyle(color: context.atlas.muted, height: 1.6),
              ),
              TextButton.icon(
                onPressed: () => openPlanningTool(
                  context,
                  SchoolPortalPage(initialSchool: widget.school),
                  'School updates',
                ),
                icon: const Icon(Icons.add_link),
                label: const Text('Suggest a school website or media source'),
              ),
              OutlinedButton.icon(
                onPressed: () => openLink(
                  context,
                  Uri.https('www.youtube.com', '/results', {
                    'search_query':
                        '${widget.school.name} ${widget.school.region} Ghana',
                  }),
                ),
                icon: const Icon(Icons.video_library_outlined),
                label: const Text('Search school videos on YouTube'),
              ),
              Text(
                'External search results are not reviewed by Skool Atlas and may include unrelated schools.',
                style: TextStyle(
                  color: context.atlas.muted,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ],
          ),
        );
      }
      final photos = [
        ...websiteContent.items(widget.school.id, 'photos'),
        ...(publishedUpdates.media[widget.school.id] ?? []).where(
          (m) => m['kind'] == 'photo',
        ),
      ];
      final videos = [
        ...websiteContent.items(widget.school.id, 'videos'),
        ...(publishedUpdates.media[widget.school.id] ?? []).where(
          (m) => m['kind'] == 'video',
        ),
      ];
      final resources = websiteContent.items(widget.school.id, 'resources');
      final documents = resources
          .where((r) => r['kind'] == 'Prospectus & documents')
          .toList();
      final information = resources
          .where((r) => r['kind'] != 'Prospectus & documents')
          .toList();
      final lastSuccess = '${row['lastSuccessAt'] ?? ''}';
      return Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'School sources & media',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              linkHost('${row['website']}'),
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: context.atlas.primary,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              lastSuccess.isEmpty
                  ? 'No successful website scan yet.'
                  : 'Last successful scan: ${lastSuccess.split('T').first}. Website information may be older than this check.',
              style: TextStyle(
                fontSize: 12,
                color: context.atlas.muted,
                height: 1.5,
              ),
            ),
            if (row['sourceNotice'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  '${row['sourceNotice']}',
                  style: TextStyle(
                    color: context.atlas.muted,
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
              ),
            if (row['status'] != 'ok')
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  row['status'] == 'partial'
                      ? 'Some source pages could not be reached. Available resources are shown below.'
                      : 'This website could not be refreshed. Any earlier available content is retained.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
              ),
            if (websiteContent.error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  websiteContent.error!,
                  style: TextStyle(color: context.atlas.muted),
                ),
              ),
            const SizedBox(height: 12),
            BalancedActions(
              children: [
                OutlinedButton.icon(
                  onPressed: () =>
                      openLink(context, Uri.parse('${row['website']}')),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Open source website'),
                ),
                if (websiteContent.networkEnabled)
                  TextButton.icon(
                    onPressed: websiteContent.refreshing
                        ? null
                        : () async {
                            await Future.wait([
                              websiteContent.refresh(),
                              publishedUpdates.refresh(),
                            ]);
                          },
                    icon: const Icon(Icons.refresh),
                    label: Text(
                      websiteContent.refreshing
                          ? 'Checking…'
                          : 'Refresh available content',
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final item in [
                  ('Photos', photos.length),
                  ('Videos', videos.length),
                  ('Documents', documents.length),
                  ('School information', information.length),
                  ('News & updates', (row['changes'] as List? ?? []).length),
                ])
                  ChoiceChip(
                    label: Text('${item.$1} (${item.$2})'),
                    selected: tab == item.$1,
                    onSelected: (_) => setState(() {
                      tab = item.$1;
                      photoLimit = 6;
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            if (tab == 'Photos') ...[
              if (photos.isEmpty)
                const Text(
                  'No public gallery images were found in the connected pages yet.',
                ),
              if (photos.isNotEmpty)
                LayoutBuilder(
                  builder: (context, constraints) => GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: constraints.maxWidth >= 900
                          ? 3
                          : constraints.maxWidth >= 500
                          ? 2
                          : 1,
                      mainAxisExtent: 220,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                    ),
                    itemCount: math.min(photos.length, photoLimit),
                    itemBuilder: (context, i) => InkWell(
                      onTap: () =>
                          openWebsiteGallery(context, widget.school, photos, i),
                      borderRadius: BorderRadius.circular(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: WebsitePhoto(photo: photos[i], height: 180),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'School website photo ${i + 1}',
                            style: TextStyle(
                              fontSize: 12,
                              color: context.atlas.muted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              if (photos.length > photoLimit)
                TextButton.icon(
                  onPressed: () => setState(() => photoLimit += 12),
                  icon: const Icon(Icons.photo_library_outlined),
                  label: const Text('Show more photos'),
                ),
            ],
            if (tab == 'Videos') ...[
              OutlinedButton.icon(
                onPressed: () => openLink(
                  context,
                  Uri.https('www.youtube.com', '/results', {
                    'search_query':
                        '${widget.school.name} ${widget.school.region} Ghana',
                  }),
                ),
                icon: const Icon(Icons.search),
                label: const Text('Find more videos on YouTube'),
              ),
              Text(
                'Videos load only when opened and may use mobile data.',
                style: TextStyle(fontSize: 12, color: context.atlas.muted),
              ),
              const SizedBox(height: 10),
              if (videos.isEmpty)
                const Text(
                  'No video links were found in the connected public pages yet.',
                ),
              for (var i = 0; i < math.min(videos.length, videoLimit); i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: BorderSide(color: context.atlas.border),
                    ),
                    leading: Icon(
                      Icons.play_circle_fill,
                      size: 36,
                      color: context.atlas.primary,
                    ),
                    title: Text(
                      '${videos[i]['title']}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      'Video ${i + 1} · Published on the school website',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => openPlanningTool(
                      context,
                      SchoolVideoPage(video: videos[i]),
                      'School video',
                    ),
                  ),
                ),
            ],
            if (tab == 'Videos' && videos.length > videoLimit)
              TextButton.icon(
                onPressed: () => setState(() => videoLimit += 6),
                icon: const Icon(Icons.expand_more),
                label: const Text('Show more videos'),
              ),
            if (tab == 'News & updates') ...[
              Text(
                'Source-page changes and school-published news. A website edit is not an independently verified achievement or an admissions change.',
                style: TextStyle(color: context.atlas.muted, height: 1.5),
              ),
              for (final change in row['changes'] as List? ?? [])
                ListTile(
                  leading: const Icon(Icons.update),
                  title: Text('${change['kind']} updated'),
                  subtitle: Text('${change['detectedAt']} · Review required'),
                  onTap: () => openLink(context, Uri.parse('${change['url']}')),
                ),
              for (final resource in resources.where(
                (r) => r['kind'] == 'News & events',
              ))
                ListTile(
                  leading: const Icon(Icons.newspaper_outlined),
                  title: Text('${resource['title']}'),
                  subtitle: const Text(
                    'Read news and school activities at the source',
                  ),
                  onTap: () =>
                      openLink(context, Uri.parse('${resource['url']}')),
                ),
              if ((row['changes'] as List? ?? []).isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: Text(
                    'No new page changes detected in this scan. See the dated school news source for older activities.',
                  ),
                ),
              TextButton.icon(
                onPressed: () => openPlanningTool(
                  context,
                  SchoolPortalPage(initialSchool: widget.school),
                  'Review a school change',
                ),
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('Submit a sourced factual update'),
              ),
            ],
            if (tab == 'School information')
              for (final candidate in row['programmeCandidates'] as List? ?? [])
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Programmes mentioned on the website: ${(candidate['programmes'] as List).join(', ')}',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        'Automated extraction; not a confirmed complete programme list. Changes need review before affecting recommendations.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          fontSize: 12,
                        ),
                      ),
                      TextButton(
                        onPressed: () => openPlanningTool(
                          context,
                          SchoolPortalPage(
                            initialSchool: widget.school,
                            initialField: 'programs',
                            initialValue: (candidate['programmes'] as List)
                                .join(', '),
                            initialSource: '${candidate['source']}',
                          ),
                          'Review programmes',
                        ),
                        child: const Text(
                          'Check source & submit programme correction',
                        ),
                      ),
                    ],
                  ),
                ),
            if (tab == 'Documents' || tab == 'School information') ...[
              if (tab == 'Documents')
                Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text(
                    'Check the academic year and confirm requirements with the school before buying items or submitting documents.',
                    style: TextStyle(
                      fontSize: 12,
                      color: context.atlas.muted,
                      height: 1.5,
                    ),
                  ),
                ),
              if ((tab == 'Documents' ? documents : information).isEmpty)
                Text(
                  tab == 'Documents'
                      ? 'No prospectus or public document link was found yet.'
                      : 'No additional information links were found yet.',
                ),
              for (final item in tab == 'Documents' ? documents : information)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    tab == 'Documents'
                        ? Icons.picture_as_pdf_outlined
                        : Icons.article_outlined,
                    color: context.atlas.primary,
                  ),
                  title: Text(
                    '${item['title']}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    '${item['kind']} · ${linkHost('${item['url']}')}',
                  ),
                  trailing: const Icon(Icons.open_in_new, size: 18),
                  onTap: () => openLink(context, Uri.parse('${item['url']}')),
                ),
            ],
            const SizedBox(height: 16),
            Text(
              'Linked content belongs to its publisher and needs internet. It may include historical or promotional material. It does not override reviewed school facts or current CSSPS instructions.',
              style: TextStyle(
                fontSize: 12,
                color: context.atlas.muted,
                height: 1.6,
              ),
            ),
          ],
        ),
      );
    },
  );
}

class WebsitePhoto extends StatefulWidget {
  final Map<String, dynamic> photo;
  final double height;
  final BoxFit fit;
  const WebsitePhoto({
    super.key,
    required this.photo,
    this.height = 180,
    this.fit = BoxFit.cover,
  });
  @override
  State<WebsitePhoto> createState() => _WebsitePhotoState();
}

class _WebsitePhotoState extends State<WebsitePhoto> {
  int revision = 0;
  @override
  Widget build(BuildContext context) => Image.network(
    '${widget.photo['url']}',
    key: ValueKey('${widget.photo['url']}-$revision'),
    height: widget.height,
    width: double.infinity,
    fit: widget.fit,
    cacheWidth: widget.height > 250
        ? 1400
        : widget.height < 110
        ? 280
        : 640,
    filterQuality: FilterQuality.low,
    webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
    semanticLabel: '${widget.photo['title']}',
    loadingBuilder: (_, child, progress) => progress == null
        ? child
        : SizedBox(
            height: widget.height,
            child: Center(
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  value: progress.expectedTotalBytes == null
                      ? null
                      : progress.cumulativeBytesLoaded /
                            progress.expectedTotalBytes!,
                ),
              ),
            ),
          ),
    errorBuilder: (_, _, _) => Container(
      height: widget.height,
      color: context.atlas.primarySoft,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(12),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.broken_image_outlined),
            const SizedBox(height: 6),
            Text(
              widget.height < 110
                  ? 'Photo unavailable'
                  : 'Photo unavailable. Retry or open its source page.',
              textAlign: TextAlign.center,
            ),
            if (widget.height >= 110)
              TextButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('Retry photo'),
                onPressed: () async {
                  await NetworkImage('${widget.photo['url']}').evict();
                  if (mounted) setState(() => revision++);
                },
              ),
          ],
        ),
      ),
    ),
  );
}

void openWebsiteGallery(
  BuildContext context,
  School school,
  List<Map<String, dynamic>> photos,
  int initial,
) => Navigator.of(context).push(
  MaterialPageRoute<void>(
    builder: (_) =>
        WebsiteGalleryPage(school: school, photos: photos, initial: initial),
  ),
);

class WebsiteGalleryPage extends StatefulWidget {
  final School school;
  final List<Map<String, dynamic>> photos;
  final int initial;
  const WebsiteGalleryPage({
    super.key,
    required this.school,
    required this.photos,
    required this.initial,
  });
  @override
  State<WebsiteGalleryPage> createState() => _WebsiteGalleryPageState();
}

class _WebsiteGalleryPageState extends State<WebsiteGalleryPage> {
  late final controller = PageController(initialPage: widget.initial);
  late int index = widget.initial;
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: atlasPageBar(
      context,
      '${widget.school.name} · ${index + 1}/${widget.photos.length}',
    ),
    body: SafeArea(
      child: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: controller,
              itemCount: widget.photos.length,
              onPageChanged: (i) => setState(() => index = i),
              itemBuilder: (_, i) => InteractiveViewer(
                child: Center(
                  child: WebsitePhoto(
                    photo: widget.photos[i],
                    height: MediaQuery.sizeOf(context).height * .65,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 12,
              runSpacing: 8,
              children: [
                IconButton(
                  tooltip: 'Previous photo',
                  onPressed: index == 0
                      ? null
                      : () => controller.previousPage(
                          duration: const Duration(milliseconds: 200),
                          curve: Curves.easeOut,
                        ),
                  icon: const Icon(Icons.chevron_left),
                ),
                TextButton.icon(
                  onPressed: () => openLink(
                    context,
                    Uri.parse('${widget.photos[index]['source']}'),
                  ),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Photo source'),
                ),
                IconButton(
                  tooltip: 'Next photo',
                  onPressed: index == widget.photos.length - 1
                      ? null
                      : () => controller.nextPage(
                          duration: const Duration(milliseconds: 200),
                          curve: Curves.easeOut,
                        ),
                  icon: const Icon(Icons.chevron_right),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class SchoolVideoPage extends StatefulWidget {
  final Map<String, dynamic> video;
  const SchoolVideoPage({super.key, required this.video});
  @override
  State<SchoolVideoPage> createState() => _SchoolVideoPageState();
}

class _SchoolVideoPageState extends State<SchoolVideoPage> {
  VideoPlayerController? controller;
  String? error;
  String? get youtubeId {
    final uri = Uri.parse('${widget.video['url']}');
    return uri.host == 'www.youtube.com' ? uri.queryParameters['v'] : null;
  }

  @override
  void initState() {
    super.initState();
    if (youtubeId == null) {
      controller = VideoPlayerController.networkUrl(
        Uri.parse('${widget.video['url']}'),
      );
      unawaited(initialize());
    }
  }

  Future<void> initialize() async {
    try {
      await controller!.initialize().timeout(const Duration(seconds: 20));
    } catch (_) {
      if (mounted) {
        error =
            'This video could not load. You can open it on its source website.';
      }
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    unawaited(controller?.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PageFrame(
    title: '${widget.video['title']}',
    subtitle: 'Video linked from the school website. Playback needs internet.',
    children: [
      if (youtubeId != null)
        SchoolYouTube(videoId: youtubeId!)
      else if (error != null)
        Surface(child: Text(error!))
      else if (controller?.value.isInitialized != true)
        const SizedBox(
          height: 220,
          child: Center(child: CircularProgressIndicator()),
        )
      else ...[
        ClipRRect(
          borderRadius: AtlasStyle.cardRadius,
          child: AspectRatio(
            aspectRatio: controller!.value.aspectRatio,
            child: VideoPlayer(controller!),
          ),
        ),
        const SizedBox(height: 12),
        VideoProgressIndicator(controller!, allowScrubbing: true),
        const SizedBox(height: 12),
        ValueListenableBuilder(
          valueListenable: controller!,
          builder: (_, value, _) => FilledButton.icon(
            onPressed: () =>
                value.isPlaying ? controller!.pause() : controller!.play(),
            icon: Icon(value.isPlaying ? Icons.pause : Icons.play_arrow),
            label: Text(value.isPlaying ? 'Pause video' : 'Play video'),
          ),
        ),
      ],
      const SizedBox(height: 20),
      BalancedActions(
        children: [
          OutlinedButton.icon(
            onPressed: () =>
                openLink(context, Uri.parse('${widget.video['url']}')),
            icon: const Icon(Icons.open_in_new),
            label: const Text('Watch on source'),
          ),
          TextButton(
            onPressed: () =>
                openLink(context, Uri.parse('${widget.video['source']}')),
            child: const Text('View publishing page'),
          ),
        ],
      ),
    ],
  );
}
