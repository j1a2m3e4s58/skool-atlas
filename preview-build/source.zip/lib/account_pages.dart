part of 'main.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  final email = TextEditingController(),
      password = TextEditingController(),
      name = TextEditingController(),
      code = TextEditingController();
  String mode = 'Sign in';
  bool busy = false, consent = false, showPassword = false;
  String? error, message, developmentCode;
  Map<String, dynamic>? cloud;
  @override
  void dispose() {
    for (final c in [email, password, name, code]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> perform(Future<void> Function() action) async {
    setState(() {
      busy = true;
      error = null;
      message = null;
    });
    try {
      await action();
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> submit() => perform(() async {
    if (mode == 'Sign in') {
      await accounts.signIn(email.text.trim(), password.text);
      cloud = await accounts.cloudChoices();
    } else if (mode == 'Create account') {
      final result = await accounts.request(
        '/auth/register',
        method: 'POST',
        data: {
          'email': email.text.trim(),
          'password': password.text,
          'name': name.text.trim(),
          'guardianConsent': consent,
        },
      );
      developmentCode = result['developmentCode'] as String?;
      mode = 'Verify email';
      message = '${result['message']}';
    } else if (mode == 'Verify email') {
      final result = await accounts.request(
        '/auth/verify',
        method: 'POST',
        data: {'code': code.text.trim()},
      );
      developmentCode = null;
      message = '${result['message']}';
      mode = 'Sign in';
    } else if (mode == 'Reset password') {
      final result = await accounts.request(
        '/auth/request-reset',
        method: 'POST',
        data: {'email': email.text.trim()},
      );
      developmentCode = result['developmentCode'] as String?;
      message = '${result['message']}';
      mode = 'Enter reset code';
    } else {
      final result = await accounts.request(
        '/auth/reset',
        method: 'POST',
        data: {'code': code.text.trim(), 'password': password.text},
      );
      developmentCode = null;
      message = '${result['message']}';
      mode = 'Sign in';
    }
  });
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: accounts,
    builder: (context, _) => PageFrame(
      maxWidth: 900,
      title: accounts.signedIn
          ? 'Your account & family choices'
          : 'Keep your school journey together',
      subtitle:
          'Device-only browsing stays available. Accounts add optional cloud choices, source updates and review invitations.',
      children: [
        if (accounts.config['mode'] == 'local')
          const InfoPanel(
            title: 'Local account service',
            text:
                'This preview uses a real local database. Test email codes appear here instead of being sent. School access still requires an independent administrator review.',
          ),
        if (accounts.connectionError != null)
          InfoPanel(
            title: 'Account service unavailable',
            text: accounts.connectionError!,
          ),
        if (error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(error!, style: const TextStyle(color: Colors.red)),
          ),
        if (message != null) InfoPanel(title: 'Account update', text: message!),
        if (!accounts.signedIn)
          Surface(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      mode,
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (mode == 'Create account') ...[
                      TextField(
                        controller: name,
                        decoration: const InputDecoration(
                          labelText:
                              'Your display name (avoid a student’s full name)',
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if (![
                      'Verify email',
                      'Enter reset code',
                    ].contains(mode)) ...[
                      TextField(
                        controller: email,
                        keyboardType: TextInputType.emailAddress,
                        autofillHints: const [AutofillHints.email],
                        decoration: const InputDecoration(
                          labelText: 'Email address',
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if ([
                      'Sign in',
                      'Create account',
                      'Enter reset code',
                    ].contains(mode)) ...[
                      TextField(
                        controller: password,
                        obscureText: !showPassword,
                        autofillHints: mode == 'Sign in'
                            ? const [AutofillHints.password]
                            : const [AutofillHints.newPassword],
                        decoration: InputDecoration(
                          labelText: mode == 'Enter reset code'
                              ? 'New password'
                              : 'Password',
                          helperText: '12–128 characters',
                          suffixIcon: IconButton(
                            tooltip: showPassword
                                ? 'Hide password'
                                : 'Show password',
                            onPressed: () =>
                                setState(() => showPassword = !showPassword),
                            icon: Icon(
                              showPassword
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if ([
                      'Verify email',
                      'Enter reset code',
                    ].contains(mode)) ...[
                      TextField(
                        controller: code,
                        decoration: const InputDecoration(
                          labelText: 'Verification / reset code',
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if (developmentCode != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'LOCAL TEST CODE · not an email delivery',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                            SelectableText(
                              developmentCode!,
                              style: const TextStyle(fontSize: 12),
                            ),
                            TextButton(
                              onPressed: () =>
                                  setState(() => code.text = developmentCode!),
                              child: const Text('Use local test code'),
                            ),
                          ],
                        ),
                      ),
                    if (mode == 'Create account')
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: consent,
                        onChanged: (v) => setState(() => consent = v ?? false),
                        title: const Text(
                          'I am a guardian/teacher, or I have my guardian’s permission.',
                        ),
                        subtitle: const Text(
                          'Read the privacy notice and terms before creating an account.',
                        ),
                      ),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: busy ? null : submit,
                        icon: Icon(
                          busy ? Icons.hourglass_top : Icons.lock_outline,
                        ),
                        label: Text(busy ? 'Please wait…' : mode),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final m in [
                          'Sign in',
                          'Create account',
                          'Verify email',
                          'Reset password',
                        ])
                          if (m != mode)
                            TextButton(
                              onPressed: busy
                                  ? null
                                  : () => setState(() {
                                      mode = m;
                                      error = null;
                                      message = null;
                                      developmentCode = null;
                                    }),
                              child: Text(m),
                            ),
                        TextButton(
                          onPressed: () => openPlanningTool(
                            context,
                            const PrivacyHelpPage(),
                            'Privacy, terms & help',
                          ),
                          child: const Text('Privacy & terms'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        if (accounts.signedIn) ...[
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome, ${accounts.user!['name']}',
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Text('${accounts.user!['email']} · Email verified'),
                const SizedBox(height: 8),
                Text(
                  accounts.memberships.isEmpty
                      ? 'No school-management access has been approved for this account.'
                      : '${accounts.memberships.length} school access approval(s).',
                ),
                const SizedBox(height: 16),
                BalancedActions(
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => openPlanningTool(
                        context,
                        const SchoolPortalPage(),
                        'School updates & access',
                      ),
                      icon: const Icon(Icons.school_outlined),
                      label: const Text('School update portal'),
                    ),
                    if (accounts.isAdmin)
                      FilledButton.icon(
                        onPressed: () => openPlanningTool(
                          context,
                          const ModeratorPage(),
                          'Moderation desk',
                        ),
                        icon: const Icon(Icons.fact_check_outlined),
                        label: const Text('Moderation desk'),
                      ),
                    TextButton(
                      onPressed: busy
                          ? null
                          : () => perform(() async {
                              await accounts.signOut();
                              cloud = null;
                            }),
                      child: const Text('Sign out on all devices'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Choose what to sync',
                  style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                Text(
                  'Only your shortlist, comparison and checklist are synced. Your grades, home location and device-only draft are excluded.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                const SizedBox(height: 16),
                BalancedActions(
                  children: [
                    OutlinedButton.icon(
                      onPressed: busy
                          ? null
                          : () => perform(() async {
                              cloud = await accounts.cloudChoices();
                            }),
                      icon: const Icon(Icons.cloud_download_outlined),
                      label: const Text('Check cloud choices'),
                    ),
                    FilledButton.icon(
                      onPressed: busy || cloud == null
                          ? null
                          : () => perform(() async {
                              await accounts.uploadChoices();
                              cloud = await accounts.cloudChoices();
                              message =
                                  'Your device choices were saved to your account.';
                            }),
                      icon: const Icon(Icons.cloud_upload_outlined),
                      label: const Text('Save device choices to cloud'),
                    ),
                  ],
                ),
                if (cloud != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    cloud!['state'] == null
                        ? 'No cloud choices saved yet.'
                        : 'Cloud version ${cloud!['version']} · ${(cloud!['state']['saved'] as List? ?? []).length} saved schools',
                  ),
                  if (cloud!['state'] != null)
                    Wrap(
                      spacing: 10,
                      children: [
                        TextButton(
                          onPressed: busy
                              ? null
                              : () => perform(() async {
                                  await accounts.importCloudChoices(
                                    cloud!['state'] as Map,
                                  );
                                  message =
                                      'Cloud choices merged into this device.';
                                }),
                          child: const Text('Merge into this device'),
                        ),
                        TextButton(
                          onPressed: busy
                              ? null
                              : () => confirmReplaceCloud(context),
                          child: const Text('Replace device choices'),
                        ),
                      ],
                    ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 18),
          SharedPlansManager(onError: (e) => setState(() => error = e)),
          const SizedBox(height: 18),
          const AccountActivityPanel(),
          const SizedBox(height: 18),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your data & support',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                BalancedActions(
                  children: [
                    OutlinedButton(
                      onPressed: () => openPlanningTool(
                        context,
                        const PrivacyHelpPage(),
                        'Privacy, terms & help',
                      ),
                      child: const Text('Help & privacy'),
                    ),
                    TextButton(
                      onPressed: busy ? null : () => deleteAccount(context),
                      child: const Text('Delete my account'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ],
    ),
  );
  Future<void> confirmReplaceCloud(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Replace device choices?'),
        content: const Text(
          'This replaces the shortlist, comparison and checklist on this device with your cloud copy. Your grades and local draft are unaffected.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Keep device choices'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Replace'),
          ),
        ],
      ),
    );
    if (yes == true && mounted) {
      await perform(() async {
        await accounts.importCloudChoices(cloud!['state'] as Map, merge: false);
        message = 'Cloud choices restored on this device.';
      });
    }
  }

  Future<void> deleteAccount(BuildContext context) async {
    final pass = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete your account permanently?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Cloud choices, share links and school-access membership will be deleted. Device-only choices remain unless you clear them separately.',
            ),
            const SizedBox(height: 16),
            TextField(
              controller: pass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Current password'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete account'),
          ),
        ],
      ),
    );
    final value = pass.text;
    pass.dispose();
    if (confirmed == true && mounted) {
      await perform(() async {
        await accounts.request(
          '/me',
          method: 'DELETE',
          data: {'password': value},
        );
        accounts.token = null;
        accounts.user = null;
        accounts.memberships = [];
        cloud = null;
        message = 'Your account was deleted.';
      });
    }
  }
}

class InfoPanel extends StatelessWidget {
  final String title, text;
  const InfoPanel({super.key, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.zero,
    child: Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
          ),
          const SizedBox(height: 8),
          Text(text, style: TextStyle(color: context.atlas.muted, height: 1.6)),
        ],
      ),
    ),
  );
}

class SchoolPortalPage extends StatefulWidget {
  final School? initialSchool;
  final String? initialField, initialValue, initialSource;
  const SchoolPortalPage({
    super.key,
    this.initialSchool,
    this.initialField,
    this.initialValue,
    this.initialSource,
  });
  @override
  State<SchoolPortalPage> createState() => _SchoolPortalPageState();
}

class _SchoolPortalPageState extends State<SchoolPortalPage> {
  final search = TextEditingController(),
      value = TextEditingController(),
      source = TextEditingController(),
      note = TextEditingController(),
      position = TextEditingController();
  final recordTitle = TextEditingController(),
      detail = TextEditingController(),
      period = TextEditingController(),
      resourceUrl = TextEditingController(),
      year = TextEditingController(text: DateTime.now().year.toString()),
      latitude = TextEditingController(),
      longitude = TextEditingController();
  String mediaKind = 'photo';
  bool get structured => [
    'contact',
    'fees',
    'scholarship',
    'prospectus',
    'catchment',
    'media',
    'achievement',
  ].contains(field);
  static const fieldLabels = {
    'name': 'School name',
    'description': 'About the school',
    'programs': 'Programmes offered',
    'residency': 'Day / boarding',
    'website': 'School website',
    'location': 'Town and address',
    'contact': 'Office contact',
    'fees': 'Fees and costs',
    'scholarship': 'Scholarship / support',
    'prospectus': 'Prospectus / document',
    'coordinates': 'Campus map pin',
    'catchment': 'Day-school catchment',
    'media': 'Photo / video / crest',
    'achievement': 'Achievement',
    'code': 'Official school code',
    'category': 'Selection category',
    'ownership': 'Public / private',
    'gender': 'School gender',
    'region': 'Region',
    'status': 'Operation status',
  };
  School? selected;
  String field = 'description', mode = 'Suggest update';
  String? evidenceId;
  final observed = TextEditingController(text: dateLabel(DateTime.now()));
  @override
  void initState() {
    super.initState();
    selected = widget.initialSchool;
    field = widget.initialField ?? field;
    value.text = widget.initialValue ?? '';
    source.text = widget.initialSource ?? '';
  }

  Future<void> attach() async {
    try {
      final file = await openFile(
        acceptedTypeGroups: [
          const XTypeGroup(
            label: 'Evidence',
            extensions: ['pdf', 'png', 'jpg', 'jpeg'],
            mimeTypes: ['application/pdf', 'image/png', 'image/jpeg'],
            uniformTypeIdentifiers: [
              'com.adobe.pdf',
              'public.png',
              'public.jpeg',
            ],
          ),
        ],
      );
      if (file == null) return;
      if (await file.length() > 1000000) {
        throw Exception('Choose a file below 1 MB.');
      }
      final ext = file.name.split('.').last.toLowerCase();
      final type = ext == 'pdf'
          ? 'application/pdf'
          : ext == 'png'
          ? 'image/png'
          : 'image/jpeg';
      evidenceId = await accounts.uploadEvidence(
        await file.readAsBytes(),
        type,
      );
      if (mounted) {
        setState(
          () => result =
              'Private evidence attached. Only you and authorised reviewers can open it.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => result = '$e');
    }
  }

  bool busy = false;
  String? result;
  @override
  void dispose() {
    for (final c in [
      search,
      value,
      source,
      note,
      position,
      observed,
      recordTitle,
      detail,
      period,
      resourceUrl,
      year,
      latitude,
      longitude,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    if (selected == null) {
      setState(() => result = 'Choose a school first.');
      return;
    }
    setState(() => busy = true);
    try {
      if (mode == 'Request school access') {
        await accounts.request(
          '/claims',
          method: 'POST',
          data: {
            'schoolId': selected!.id,
            'position': position.text,
            'evidenceUrl': source.text,
            'note': note.text,
          },
        );
        result =
            'School access requested. An administrator must independently confirm your role.';
      } else {
        Object entry = value.text;
        if (field == 'programs') {
          entry = value.text
              .split(',')
              .map((v) => v.trim())
              .where((v) => v.isNotEmpty)
              .toList();
        } else if (field == 'coordinates') {
          final lat = double.tryParse(latitude.text),
              lon = double.tryParse(longitude.text);
          if (lat == null || lon == null) {
            throw Exception(
              'Enter the campus latitude and longitude from the cited map source.',
            );
          }
          entry = {'latitude': lat, 'longitude': lon};
        } else if (structured) {
          entry = {
            'title': recordTitle.text,
            'detail': detail.text,
            'period': period.text,
            if (resourceUrl.text.trim().isNotEmpty)
              'url': resourceUrl.text.trim(),
            if (field == 'media') 'kind': mediaKind,
            if (field == 'achievement') 'year': int.tryParse(year.text),
            if (field == 'achievement') 'result': detail.text,
          };
        }
        await accounts.request(
          '/proposals',
          method: 'POST',
          data: {
            'schoolId': selected!.id,
            'field': field,
            'value': entry,
            'sourceUrl': source.text,
            'observed': observed.text,
            if (evidenceId != null) 'evidenceId': evidenceId,
            'note': note.text,
          },
        );
        result =
            'Update submitted for evidence review. Nothing has been published yet.';
      }
    } catch (e) {
      result = '$e';
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!accounts.signedIn) return const AccountPage();
    return PageFrame(
      maxWidth: 900,
      title: 'School update portal',
      subtitle:
          'Submit a sourced correction or request access as a school representative. An email account alone does not verify school authority.',
      children: [
        if (result != null)
          InfoPanel(title: 'Submission status', text: result!),
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: [
                  for (final m in ['Suggest update', 'Request school access'])
                    ChoiceChip(
                      label: Text(m),
                      selected: mode == m,
                      onSelected: (_) => setState(() => mode = m),
                    ),
                ],
              ),
              const SizedBox(height: 18),
              TextField(
                controller: search,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Find your school',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              if (search.text.trim().length >= 2)
                for (final school in searchSchools(query: search.text).take(6))
                  ListTile(
                    title: SchoolName(school: school),
                    subtitle: Text(school.region),
                    trailing: Icon(
                      selected?.id == school.id
                          ? Icons.check_circle
                          : Icons.add_circle_outline,
                    ),
                    onTap: () => setState(() {
                      selected = school;
                      search.text = school.name;
                    }),
                  ),
              if (selected != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    'Selected: ${selected!.name}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              const SizedBox(height: 12),
              if (mode == 'Request school access') ...[
                TextField(
                  controller: position,
                  decoration: const InputDecoration(
                    labelText: 'Your position at the school',
                  ),
                ),
                const SizedBox(height: 14),
              ] else ...[
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  initialValue: field,
                  decoration: const InputDecoration(
                    labelText: 'Information to update',
                  ),
                  items: [
                    for (final f in [
                      'name',
                      'description',
                      'programs',
                      'residency',
                      'website',
                      'location',
                      'contact',
                      'fees',
                      'scholarship',
                      'prospectus',
                      'coordinates',
                      'catchment',
                      'media',
                      'achievement',
                      'code',
                      'category',
                      'ownership',
                      'gender',
                      'region',
                      'status',
                    ])
                      DropdownMenuItem(
                        value: f,
                        child: Text(fieldLabels[f] ?? f),
                      ),
                  ],
                  onChanged: (f) => setState(() {
                    field = f!;
                    value.clear();
                  }),
                ),
                const SizedBox(height: 14),
                if (!structured && field != 'coordinates')
                  TextField(
                    controller: value,
                    minLines: field == 'description' ? 3 : 1,
                    maxLines: field == 'description' ? 8 : 3,
                    decoration: InputDecoration(
                      labelText: fieldLabels[field] ?? 'Proposed information',
                      helperText: field == 'programs'
                          ? 'Programme names separated by commas'
                          : field == 'status'
                          ? 'Open, Closed, Renamed or Under review'
                          : field == 'category'
                          ? 'Category A, Category B, Category C or Pilot private'
                          : null,
                    ),
                  ),
                if (field == 'coordinates') ...[
                  const Text(
                    'Use a campus pin supported by the school’s published map. Do not enter a student’s home location.',
                  ),
                  TextField(
                    controller: latitude,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                      signed: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Campus latitude',
                    ),
                  ),
                  TextField(
                    controller: longitude,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                      signed: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Campus longitude',
                    ),
                  ),
                ],
                if (structured) ...[
                  TextField(
                    controller: recordTitle,
                    decoration: const InputDecoration(
                      labelText: 'Title / name of this information',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: detail,
                    minLines: 3,
                    maxLines: 8,
                    decoration: InputDecoration(
                      labelText: field == 'achievement'
                          ? 'Achievement and exact result'
                          : 'Details',
                      helperText: field == 'fees'
                          ? 'Include currency, what the amount covers and any conditions.'
                          : field == 'contact'
                          ? 'Use public school-office contacts, not private student or staff details.'
                          : null,
                    ),
                  ),
                  if ([
                    'fees',
                    'scholarship',
                    'prospectus',
                    'catchment',
                  ].contains(field)) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: period,
                      decoration: const InputDecoration(
                        labelText: 'Academic year / period',
                        hintText: '2026/2027',
                      ),
                    ),
                  ],
                  if (field == 'achievement') ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: year,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Year of achievement',
                      ),
                    ),
                  ],
                  if (field == 'media') ...[
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      isExpanded: true,
                      initialValue: mediaKind,
                      decoration: const InputDecoration(
                        labelText: 'Media type',
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'photo',
                          child: Text('School photograph'),
                        ),
                        DropdownMenuItem(
                          value: 'video',
                          child: Text('School video'),
                        ),
                        DropdownMenuItem(
                          value: 'crest',
                          child: Text('Authentic school crest'),
                        ),
                      ],
                      onChanged: (v) => setState(() => mediaKind = v!),
                    ),
                  ],
                  if (['media', 'prospectus'].contains(field)) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: resourceUrl,
                      keyboardType: TextInputType.url,
                      decoration: InputDecoration(
                        labelText: field == 'media'
                            ? 'Public photo / video / crest link'
                            : 'Public prospectus link',
                        helperText:
                            'Use the publisher’s HTTPS link. Check permission to display the resource.',
                      ),
                    ),
                  ],
                ],
                const SizedBox(height: 14),
              ],
              TextField(
                controller: source,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(
                  labelText: 'Public HTTPS evidence link',
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: note,
                minLines: 3,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Explain the evidence and what should change',
                ),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: observed,
                decoration: const InputDecoration(
                  labelText: 'Evidence observation date (YYYY-MM-DD)',
                ),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: busy ? null : attach,
                icon: const Icon(Icons.attach_file),
                label: Text(
                  evidenceId == null
                      ? 'Attach private evidence (PDF / image)'
                      : 'Replace private evidence',
                ),
              ),
              Text(
                'Do not upload student results, index numbers, identity documents or private student information.',
                style: TextStyle(color: context.atlas.muted, fontSize: 12),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: busy ? null : submit,
                icon: const Icon(Icons.send_outlined),
                label: Text(busy ? 'Submitting…' : 'Submit for review'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const AccountActivityPanel(),
        const SizedBox(height: 18),
        FutureBuilder(
          future: accounts.request('/proposals'),
          builder: (context, snapshot) => Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your update submissions',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
                if (snapshot.hasError) Text('${snapshot.error}'),
                if (snapshot.hasData)
                  for (final p in snapshot.data!['proposals'] as List)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('${p['field']} · ${p['state']}'),
                      subtitle: Text('${p['review_note'] ?? p['note']}'),
                    ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class ModeratorPage extends StatefulWidget {
  const ModeratorPage({super.key});
  @override
  State<ModeratorPage> createState() => _ModeratorPageState();
}

class _ModeratorPageState extends State<ModeratorPage> {
  late Future<Map<String, dynamic>> queue = accounts.request('/admin/queue');
  String tab = 'School access';
  String? error;
  void reload() => setState(() => queue = accounts.request('/admin/queue'));
  Future<void> review(Map row, bool claim) async {
    final note = TextEditingController();
    bool checked = false;
    final decision = await showDialog<String>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setDialog) => AlertDialog(
          title: Text(
            claim ? 'Review school authority' : 'Review school update',
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${row['school_name']}'),
                const SizedBox(height: 8),
                Text(
                  claim
                      ? '${row['name']} · ${row['email']}\n${row['position']}'
                      : '${row['field']}\n${row['value_json']}',
                ),
                const SizedBox(height: 10),
                Text('${row['note']}'),
                TextButton.icon(
                  onPressed: () => openLink(
                    context,
                    Uri.parse('${row[claim ? 'evidence_url' : 'source_url']}'),
                  ),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Open submitted evidence'),
                ),
                if (!claim && row['evidence_id'] != null)
                  TextButton.icon(
                    onPressed: () async {
                      try {
                        final file = await accounts.evidence(
                          '${row['evidence_id']}',
                        );
                        await saveBinaryFile(
                          'school-evidence',
                          file.bytes,
                          file.mime,
                        );
                      } catch (e) {
                        if (mounted) toast(context, '$e');
                      }
                    },
                    icon: const Icon(Icons.lock_outline),
                    label: const Text('Download private evidence'),
                  ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: checked,
                  onChanged: (v) => setDialog(() => checked = v ?? false),
                  title: Text(
                    claim
                        ? 'I independently confirmed this person’s school role.'
                        : 'I checked the source and accuracy of this change.',
                  ),
                ),
                TextField(
                  controller: note,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Review reason and verification steps',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancel'),
            ),
            OutlinedButton(
              onPressed: () => Navigator.pop(c, 'rejected'),
              child: const Text('Reject'),
            ),
            FilledButton(
              onPressed: checked ? () => Navigator.pop(c, 'approved') : null,
              child: Text(
                claim ? 'Approve school access' : 'Approve & publish',
              ),
            ),
          ],
        ),
      ),
    );
    final reason = note.text;
    note.dispose();
    if (decision == null) return;
    try {
      await accounts.request(
        '/admin/${claim ? 'claims' : 'proposals'}/${row['id']}',
        method: 'POST',
        data: {
          'decision': decision,
          'note': reason,
          'identityChecked': checked,
          'evidenceChecked': checked,
          'version': row['version'],
        },
      );
      reload();
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
    title: 'Moderation desk',
    subtitle:
        'Server-enforced permissions, independent source review and an audit trail. Unresolved register issues stay open until evidence is checked.',
    children: [
      if (error != null)
        InfoPanel(title: 'Review could not be saved', text: error!),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final t in [
            'School access',
            'School updates',
            'Register review',
            'Support',
            'Audit',
          ])
            ChoiceChip(
              label: Text(t),
              selected: tab == t,
              onSelected: (_) => setState(() => tab = t),
            ),
          TextButton.icon(
            onPressed: reload,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh'),
          ),
        ],
      ),
      const SizedBox(height: 18),
      FutureBuilder(
        future: queue,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return InfoPanel(
              title: 'Moderation access',
              text: '${snapshot.error}',
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final key = {
            'School access': 'claims',
            'School updates': 'proposals',
            'Register review': 'cases',
            'Support': 'tickets',
            'Audit': 'audit',
          }[tab]!;
          final items = snapshot.data![key] as List;
          return Column(
            children: [
              if (items.isEmpty)
                const InfoPanel(
                  title: 'Nothing waiting here',
                  text: 'There are no records in this queue.',
                ),
              for (final raw in items)
                Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Surface(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${raw['school_name'] ?? raw['topic'] ?? raw['kind'] ?? raw['event']}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 8),
                        if (key == 'cases')
                          SelectableText(
                            const JsonEncoder.withIndent(
                              '  ',
                            ).convert(jsonDecode('${raw['payload_json']}')),
                            style: const TextStyle(fontSize: 12),
                          ),
                        if (key == 'claims')
                          Text(
                            '${raw['name']} · ${raw['position']}\n${raw['note']}',
                          ),
                        if (key == 'proposals')
                          Text(
                            '${raw['field']} · ${raw['verified_school_staff'] == 1 ? 'Approved school representative' : 'Community correction'}\n${raw['note']}',
                          ),
                        if (key == 'tickets') ...[
                          Text('${raw['message']}'),
                          TextButton(
                            onPressed: () => respondToTicket('${raw['id']}'),
                            child: const Text('Respond & resolve'),
                          ),
                        ],
                        if (key == 'audit')
                          Text('${raw['note']}\n${raw['created_at']}'),
                        if (key == 'claims' || key == 'proposals')
                          Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: FilledButton(
                              onPressed: () =>
                                  review(Map.from(raw), key == 'claims'),
                              child: const Text('Review evidence'),
                            ),
                          ),
                        if (key == 'cases')
                          TextButton(
                            onPressed: () => resolveCase(Map.from(raw)),
                            child: const Text('Record a sourced resolution'),
                          ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    ],
  );
  Future<void> respondToTicket(String id) async {
    final reply = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Support response'),
        content: TextField(
          controller: reply,
          minLines: 3,
          maxLines: 6,
          maxLength: 3000,
          decoration: const InputDecoration(
            labelText: 'Response visible to this account',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Send in-app response'),
          ),
        ],
      ),
    );
    final response = reply.text;
    reply.dispose();
    if (confirmed != true) return;
    try {
      await accounts.request(
        '/admin/support/$id',
        method: 'POST',
        data: {'response': response},
      );
      reload();
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
  }

  Future<void> resolveCase(Map row) async {
    final source = TextEditingController(),
        resolution = TextEditingController();
    bool checked = false;
    final save = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setDialog) => AlertDialog(
          title: const Text('Resolve a register case'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Record what the authoritative source confirms. Any catalogue correction must still be submitted and approved through the update queue.',
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: source,
                  decoration: const InputDecoration(
                    labelText: 'HTTPS evidence source',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: resolution,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Resolution and source reasoning',
                  ),
                ),
                CheckboxListTile(
                  value: checked,
                  onChanged: (v) => setDialog(() => checked = v ?? false),
                  title: const Text('I checked the independent evidence.'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: checked ? () => Navigator.pop(c, true) : null,
              child: const Text('Save resolution'),
            ),
          ],
        ),
      ),
    );
    final src = source.text, note = resolution.text;
    source.dispose();
    resolution.dispose();
    if (save == true) {
      try {
        await accounts.request(
          '/admin/cases/${row['id']}',
          method: 'POST',
          data: {
            'sourceUrl': src,
            'resolution': note,
            'evidenceChecked': checked,
          },
        );
        reload();
      } catch (e) {
        if (mounted) setState(() => error = '$e');
      }
    }
  }
}

class SharedPlansManager extends StatefulWidget {
  final ValueChanged<String> onError;
  const SharedPlansManager({super.key, required this.onError});
  @override
  State<SharedPlansManager> createState() => _SharedPlansManagerState();
}

class _SharedPlansManagerState extends State<SharedPlansManager> {
  late Future<Map<String, dynamic>> future = accounts.request('/shares');
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Family & teacher invitations',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 8),
        Text(
          'Create an invitation from your eight-choice planner. Revoke a link here whenever it is no longer needed.',
          style: TextStyle(color: context.atlas.muted, height: 1.6),
        ),
        FutureBuilder(
          future: future,
          builder: (context, snapshot) => Column(
            children: [
              if (snapshot.hasError) Text('${snapshot.error}'),
              if (snapshot.hasData)
                for (final share in snapshot.data!['shares'] as List)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      '${jsonDecode('${share['payload_json']}')['title']}',
                    ),
                    subtitle: Text(
                      'Expires ${DateTime.fromMillisecondsSinceEpoch((share['expires_at'] as num).toInt() * 1000).toLocal().toString().split(' ').first}',
                    ),
                    trailing: TextButton(
                      onPressed: () async {
                        try {
                          await accounts.request(
                            '/shares/${share['id']}',
                            method: 'DELETE',
                          );
                          setState(() => future = accounts.request('/shares'));
                        } catch (e) {
                          widget.onError('$e');
                        }
                      },
                      child: const Text('Revoke'),
                    ),
                  ),
            ],
          ),
        ),
      ],
    ),
  );
}

class PrivacyHelpPage extends StatefulWidget {
  const PrivacyHelpPage({super.key});
  @override
  State<PrivacyHelpPage> createState() => _PrivacyHelpPageState();
}

class _PrivacyHelpPageState extends State<PrivacyHelpPage> {
  final topic = TextEditingController(), message = TextEditingController();
  String? status;
  bool busy = false;
  @override
  void dispose() {
    topic.dispose();
    message.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
    title: 'Privacy, terms & help',
    subtitle:
        'Understand your choices and how this independent school-discovery service handles information.',
    children: [
      InfoPanel(
        title: 'Who runs this service',
        text: accounts.config['publisher'] == null
            ? 'Publisher and public support contact are not configured yet. This local preview is not a public launch.'
            : '${accounts.config['publisher']} · ${accounts.config['supportEmail'] ?? 'Support contact pending'}',
      ),
      const InfoPanel(
        title: 'Your information',
        text:
            'Browsing does not need an account. Shortlists and result drafts are stored on your device. Grades and home location are excluded from account sync and shared school drafts. Optional accounts store your display name, email, password hash, account activity and chosen school lists. Sessions are protected by server-side expiry; web sessions use HttpOnly cookies. Native sessions currently last only while the app remains open.',
      ),
      const InfoPanel(
        title: 'Sharing and school updates',
        text:
            'Only share a family/teacher invitation with people you trust. Anyone with its access link can read the selected schools; a separate review invitation permits comments. Invitations expire and can be revoked. Source-update proposals and school-access evidence are reviewed by administrators. Do not submit student records, exam PINs or other people’s private information.',
      ),
      const InfoPanel(
        title: 'School facts, media and external services',
        text:
            'Skool Atlas is independent of GES, WAEC and CSSPS. School facts may be incomplete or dated. Confirm admissions, fees, residence and catchment with the school and official services. Images and videos belong to their publishers. External school sites, maps, YouTube and the checker shop receive requests under their own privacy terms. Payments and examination results are not processed in Skool Atlas.',
      ),
      const InfoPanel(
        title: 'Account choices and retention',
        text:
            'You can sign out, export your choices, revoke share links and delete your account. Account deletion removes cloud choices, school membership and owned share links. Reviewed public school facts may remain with their source; audit records retain the decision without your account identity. Device-only choices can be cleared separately through browser/app storage. Server sessions and expired shares are periodically removed. No advertising analytics is enabled in this local release.',
      ),
      const InfoPanel(
        title: 'Terms of use',
        text:
            'Use this service for informed discussion with your family and guidance teacher. It does not guarantee placement, scholarships, fees or availability. Submit accurate source-backed updates, respect media ownership and do not impersonate a school. School-management access requires independent verification. Abuse may lead to access removal. The publisher must review these notices and provide its final support/legal details before public launch.',
      ),
      if (accounts.config['supportEmail'] != null)
        OutlinedButton.icon(
          onPressed: () => launchUrl(
            Uri(scheme: 'mailto', path: '${accounts.config['supportEmail']}'),
          ),
          icon: const Icon(Icons.email_outlined),
          label: const Text('Email support'),
        ),
      const SizedBox(height: 18),
      if (accounts.signedIn)
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Send a support or correction request',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: topic,
                decoration: const InputDecoration(labelText: 'Topic'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: message,
                minLines: 3,
                maxLines: 7,
                decoration: const InputDecoration(
                  labelText:
                      'Describe the issue — do not include PINs or student records',
                ),
              ),
              const SizedBox(height: 14),
              if (status != null) Text(status!),
              FilledButton(
                onPressed: busy
                    ? null
                    : () async {
                        setState(() => busy = true);
                        try {
                          final response = await accounts.request(
                            '/support',
                            method: 'POST',
                            data: {
                              'topic': topic.text,
                              'message': message.text,
                            },
                          );
                          status = 'Request saved: ${response['id']}';
                        } catch (e) {
                          status = '$e';
                        } finally {
                          if (mounted) setState(() => busy = false);
                        }
                      },
                child: Text(busy ? 'Sending…' : 'Save support request'),
              ),
            ],
          ),
        ),
    ],
  );
}
