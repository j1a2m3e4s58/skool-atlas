import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

final websiteContent = WebsiteContentStore();

bool publicHttpsLink(String value) {
  final uri = Uri.tryParse(value);
  if (uri == null ||
      uri.scheme != 'https' ||
      uri.userInfo.isNotEmpty ||
      !uri.host.contains('.') ||
      uri.host.endsWith('.local') ||
      uri.host.endsWith('.localhost') ||
      uri.port != 443) {
    return false;
  }
  final parts = uri.host.split('.').map(int.tryParse).toList();
  if (parts.length == 4 && parts.every((p) => p != null)) {
    if (parts.any((p) => p! < 0 || p > 255)) return false;
    final a = parts[0]!, b = parts[1]!;
    if (a == 0 ||
        a == 10 ||
        a == 127 ||
        a >= 224 ||
        (a == 169 && b == 254) ||
        (a == 172 && b >= 16 && b <= 31) ||
        (a == 192 && b == 168) ||
        (a == 100 && b >= 64 && b <= 127)) {
      return false;
    }
  }
  return true;
}

String linkHost(String value) =>
    (Uri.tryParse(value)?.host ?? '').replaceFirst(RegExp(r'^www\.'), '');

class WebsiteContentStore extends ChangeNotifier {
  Map<String, dynamic> data = {};
  Map<String, String> approved = {};
  void useApprovedDomains(Map<String, String> domains) {
    approved = Map<String, String>.from(domains);
    final rows = Map<String, dynamic>.from(data['schools'] as Map? ?? {});
    rows.removeWhere(
      (id, row) =>
          !approved.containsKey(id) ||
          row is! Map ||
          linkHost('${row['website']}') != approved[id],
    );
    data = {...data, 'schools': rows};
    notifyListeners();
  }

  SharedPreferences? preferences;
  Timer? timer;
  bool refreshing = false;
  String? error;
  static const configuredFeed = String.fromEnvironment('SCHOOL_CONTENT_FEED');
  bool get networkEnabled => kIsWeb || configuredFeed.isNotEmpty;
  Map<String, dynamic>? school(String id) =>
      (data['schools'] as Map?)?[id] as Map<String, dynamic>?;
  List<Map<String, dynamic>> items(String id, String kind) =>
      ((school(id)?[kind] as List?) ?? []).cast<Map<String, dynamic>>();

  Map<String, dynamic> validate(String text) {
    if (text.length > 6000000) throw const FormatException('Feed too large');
    final raw = jsonDecode(text) as Map<String, dynamic>;
    if (raw['schema'] != 1 ||
        raw['schools'] is! Map ||
        DateTime.tryParse('${raw['generatedAt']}') == null) {
      throw const FormatException('Unsupported school content feed');
    }
    final result = <String, dynamic>{};
    for (final entry in (raw['schools'] as Map).entries) {
      final id = '${entry.key}', row = entry.value;
      if (!approved.containsKey(id) ||
          row is! Map ||
          !publicHttpsLink('${row['website']}') ||
          linkHost('${row['website']}') != approved[id]) {
        continue;
      }
      final record = Map<String, dynamic>.from(row);
      for (final kind in ['photos', 'videos', 'resources']) {
        record[kind] = ((row[kind] as List?) ?? [])
            .whereType<Map>()
            .where(
              (m) =>
                  publicHttpsLink('${m['url']}') &&
                  publicHttpsLink('${m['source']}') &&
                  linkHost('${m['source']}') == approved[id],
            )
            .take(
              kind == 'photos'
                  ? 80
                  : kind == 'videos'
                  ? 24
                  : 100,
            )
            .map((m) => Map<String, dynamic>.from(m))
            .toList();
      }
      result[id] = record;
    }
    return {...raw, 'schools': result};
  }

  Future<void> load() async {
    final registry =
        jsonDecode(
              await rootBundle.loadString(
                'assets/schools/website_sources.json',
              ),
            )
            as List;
    approved = {
      for (final row in registry)
        '${row['schoolId']}': linkHost('${row['url']}'),
    };
    data = validate(
      await rootBundle.loadString('assets/schools/website_content.json'),
    );
    try {
      preferences = await SharedPreferences.getInstance();
      final cached = preferences!.getString('atlas.website-content.v1');
      if (cached != null) {
        final candidate = validate(cached);
        if (!DateTime.parse(
          '${candidate['generatedAt']}',
        ).isBefore(DateTime.parse('${data['generatedAt']}'))) {
          data = candidate;
        }
      }
    } catch (_) {
      /* The bundled snapshot remains available. */
    }
    timer?.cancel();
    if (networkEnabled) {
      timer = Timer.periodic(
        const Duration(hours: 1),
        (_) => unawaited(refresh()),
      );
    }
    notifyListeners();
  }

  Future<void> refresh() async {
    if (refreshing || !networkEnabled) return;
    final uri = configuredFeed.isNotEmpty
        ? Uri.tryParse(configuredFeed)
        : Uri.base.resolve('school-content.json');
    if (uri == null ||
        (!publicHttpsLink(uri.toString()) &&
            !(kDebugMode &&
                ['localhost', '127.0.0.1', '10.0.2.2'].contains(uri.host)) &&
            !(kIsWeb &&
                uri.origin == Uri.base.origin &&
                ['localhost', '127.0.0.1'].contains(uri.host)))) {
      error = 'The content feed needs a public HTTPS address.';
      notifyListeners();
      return;
    }
    refreshing = true;
    error = null;
    notifyListeners();
    final client = http.Client();
    try {
      final response = await client
          .get(uri, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) {
        throw const FormatException('Feed unavailable');
      }
      final next = validate(utf8.decode(response.bodyBytes));
      if (DateTime.parse(
        '${next['generatedAt']}',
      ).isBefore(DateTime.parse('${data['generatedAt']}'))) {
        throw const FormatException('Older feed ignored');
      }
      // A failed source refresh retains its last useful content.
      final merged = Map<String, dynamic>.from(data['schools'] as Map? ?? {});
      for (final entry in (next['schools'] as Map).entries) {
        final record = Map<String, dynamic>.from(entry.value as Map);
        final previous = merged[entry.key] as Map?;
        if (record['status'] == 'unavailable' && previous != null) {
          for (final kind in ['photos', 'videos', 'resources']) {
            if ((record[kind] as List).isEmpty) {
              record[kind] = previous[kind] ?? [];
            }
          }
          record['lastSuccessAt'] = previous['lastSuccessAt'];
        }
        merged[entry.key] = record;
      }
      data = {...next, 'schools': merged};
      await preferences?.setString(
        'atlas.website-content.v1',
        jsonEncode(data),
      );
    } catch (_) {
      error =
          'Could not refresh online. Showing the last available website snapshot.';
    } finally {
      client.close();
      refreshing = false;
      notifyListeners();
    }
  }
}
