import 'dart:ui_web' as ui_web;
import 'package:flutter/material.dart';
import 'package:web/web.dart' as web;

class SchoolMap extends StatefulWidget {
  final String query;
  const SchoolMap({super.key, required this.query});
  @override
  State<SchoolMap> createState() => _SchoolMapState();
}

class _SchoolMapState extends State<SchoolMap> {
  static int nextId = 0;
  late final String viewType;
  @override
  void initState() {
    super.initState();
    viewType = 'school-map-${nextId++}';
    final url = Uri.https('maps.google.com', '/maps', {
      'q': widget.query,
      'output': 'embed',
    }).toString();
    ui_web.platformViewRegistry.registerViewFactory(
      viewType,
      (int id) => web.HTMLIFrameElement()
        ..src = url
        ..title = 'School map search: ${widget.query}'
        ..loading = 'lazy'
        ..referrerPolicy = 'no-referrer-when-downgrade'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%',
    );
  }

  @override
  Widget build(BuildContext context) =>
      SizedBox(height: 310, child: HtmlElementView(viewType: viewType));
}
