part of 'main.dart';

final atlasAppearance = AtlasAppearance();

class AtlasStyle {
  static const panelRadius = BorderRadius.only(
    topLeft: Radius.circular(6),
    topRight: Radius.circular(16),
    bottomLeft: Radius.circular(6),
    bottomRight: Radius.circular(6),
  );
  static const cardRadius = BorderRadius.all(Radius.circular(10));
  static const controlRadius = BorderRadius.all(Radius.circular(7));
  static const controlHeight = 52.0;
}

BoxDecoration atlasPanelDecoration(BuildContext context) => BoxDecoration(
  gradient: LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      context.atlas.surface,
      Color.lerp(context.atlas.surface, context.atlas.primarySoft, .10)!,
    ],
  ),
  borderRadius: AtlasStyle.panelRadius,
  border: Border.all(color: context.atlas.border, width: 1.1),
  boxShadow: [
    BoxShadow(
      color: Colors.black.withValues(alpha: context.atlas.isDark ? .10 : .025),
      blurRadius: 12,
      offset: const Offset(0, 3),
    ),
  ],
);

class AtlasAppearance extends ChangeNotifier {
  ThemeMode mode = ThemeMode.system;
  Future<void> load() async {
    try {
      final value = (await SharedPreferences.getInstance()).getString(
        'atlas.theme',
      );
      mode = ThemeMode.values.firstWhere(
        (m) => m.name == value,
        orElse: () => ThemeMode.system,
      );
    } catch (_) {
      mode = ThemeMode.system;
    }
    notifyListeners();
  }

  Future<void> setMode(ThemeMode value) async {
    mode = value;
    notifyListeners();
    try {
      await (await SharedPreferences.getInstance()).setString(
        'atlas.theme',
        value.name,
      );
    } catch (_) {
      // The preference still applies for this session if storage is unavailable.
    }
  }
}

extension AtlasContext on BuildContext {
  AtlasPalette get atlas => AtlasPalette(Theme.of(this));
}

class AtlasPalette {
  final ThemeData theme;
  AtlasPalette(this.theme);
  bool get isDark => theme.brightness == Brightness.dark;
  Color get surface => theme.colorScheme.surface;
  Color get canvas => theme.scaffoldBackgroundColor;
  Color get dark => theme.colorScheme.onSurface;
  Color get muted => theme.colorScheme.onSurfaceVariant;
  Color get border => theme.colorScheme.outlineVariant;
  Color get primary => isDark ? const Color(0xFFADC8FF) : AppColors.primary;
  Color get primaryDark =>
      isDark ? const Color(0xFFD5E3FF) : AppColors.primaryDark;
  Color get primarySoft =>
      isDark ? const Color(0xFF203350) : const Color(0xFFEDF3FF);
  Color get chipBg => primarySoft;
  Color get cardBg => surface;
  Color get lightBg =>
      isDark ? const Color(0xFF1B283D) : const Color(0xFFF3F6FC);
  Color get danger => theme.colorScheme.error;
}

ThemeData atlasTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final scheme =
      ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: brightness,
      ).copyWith(
        surface: dark ? const Color(0xFF142035) : Colors.white,
        onSurface: dark ? const Color(0xFFE8EEF8) : const Color(0xFF14223B),
        onSurfaceVariant: dark
            ? const Color(0xFFAFBED3)
            : const Color(0xFF52627B),
        outlineVariant: dark
            ? const Color(0xFF30425C)
            : const Color(0xFFD3DCE9),
        primary: dark ? const Color(0xFFADC8FF) : AppColors.primary,
      );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: 'SkoolSans',
  );
  const shape = RoundedRectangleBorder(borderRadius: AtlasStyle.controlRadius);
  final button = ButtonStyle(
    minimumSize: const WidgetStatePropertyAll(Size(48, AtlasStyle.controlHeight)),
    padding: const WidgetStatePropertyAll(
      EdgeInsets.symmetric(horizontal: 18, vertical: 14),
    ),
    shape: WidgetStatePropertyAll(shape),
    textStyle: const WidgetStatePropertyAll(
      TextStyle(
        fontFamily: 'SkoolSans',
        fontSize: 14,
        fontWeight: FontWeight.w700,
        height: 1.3,
      ),
    ),
    alignment: Alignment.center,
  );
  return base.copyWith(
    scaffoldBackgroundColor: dark
        ? const Color(0xFF0B1323)
        : const Color(0xFFF5F7FB),
    textTheme: base.textTheme
        .apply(bodyColor: scheme.onSurface, displayColor: scheme.onSurface)
        .copyWith(
          bodyMedium: TextStyle(
            fontSize: 14,
            height: 1.55,
            color: scheme.onSurface,
          ),
          bodyLarge: TextStyle(
            fontSize: 16,
            height: 1.55,
            color: scheme.onSurface,
          ),
          titleMedium: TextStyle(
            fontSize: 17,
            height: 1.35,
            fontWeight: FontWeight.w700,
            color: scheme.onSurface,
          ),
        )
        .apply(fontFamily: 'SkoolSans'),
    appBarTheme: AppBarTheme(
      backgroundColor: scheme.surface,
      foregroundColor: scheme.onSurface,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 72,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: button.copyWith(
        backgroundColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.disabled)
                ? scheme.onSurface.withValues(alpha: .10)
                : AppColors.primary),
        foregroundColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.disabled)
                ? scheme.onSurface.withValues(alpha: .38)
                : Colors.white),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: button.copyWith(
        elevation: const WidgetStatePropertyAll(0),
        backgroundColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.disabled)
                ? scheme.onSurface.withValues(alpha: .10)
                : AppColors.primary),
        foregroundColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.disabled)
                ? scheme.onSurface.withValues(alpha: .38)
                : Colors.white),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: button.copyWith(
        side: WidgetStatePropertyAll(BorderSide(color: scheme.outlineVariant)),
        foregroundColor: WidgetStatePropertyAll(scheme.primary),
      ),
    ),
    textButtonTheme: TextButtonThemeData(style: button),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: dark ? const Color(0xFF263D61) : const Color(0xFFE6EDFF),
      iconTheme: WidgetStateProperty.resolveWith(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? scheme.primary
              : scheme.onSurfaceVariant,
          size: 24,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith(
        (states) => TextStyle(
          fontFamily: 'SkoolSans',
          fontSize: 12,
          height: 1.25,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w500,
          color: states.contains(WidgetState.selected)
              ? scheme.onSurface
              : scheme.onSurfaceVariant,
        ),
      ),
    ),
    iconButtonTheme: const IconButtonThemeData(
      style: ButtonStyle(minimumSize: WidgetStatePropertyAll(Size(48, 48))),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0xFF1B283D) : const Color(0xFFF8FAFD),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
      border: OutlineInputBorder(borderRadius: AtlasStyle.controlRadius),
      enabledBorder: OutlineInputBorder(
        borderRadius: AtlasStyle.controlRadius,
        borderSide: BorderSide(color: scheme.outlineVariant),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: AtlasStyle.controlRadius,
        borderSide: BorderSide(color: scheme.primary, width: 2),
      ),
      helperMaxLines: 4,
      errorMaxLines: 4,
    ),
    chipTheme: base.chipTheme.copyWith(
      side: BorderSide(color: scheme.outlineVariant),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: AtlasStyle.controlRadius),
    ),
    dividerTheme: DividerThemeData(color: scheme.outlineVariant, space: 28),
    listTileTheme: const ListTileThemeData(
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      minVerticalPadding: 12,
    ),
    expansionTileTheme: ExpansionTileThemeData(
      backgroundColor: scheme.surface,
      collapsedBackgroundColor: scheme.surface,
      shape: const Border(),
      collapsedShape: const Border(),
      tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: AtlasStyle.panelRadius),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: scheme.surface,
      surfaceTintColor: Colors.transparent,
      shape: shape,
    ),
  );
}

class AppearanceButton extends StatelessWidget {
  const AppearanceButton({super.key});
  @override
  Widget build(BuildContext context) => IconButton(
    tooltip: 'Appearance',
    icon: Icon(
      context.atlas.isDark
          ? Icons.dark_mode_outlined
          : Icons.light_mode_outlined,
    ),
    onPressed: () => showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      showDragHandle: false,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => const AtlasAppearanceSheet(),
    ),
  );
}

class AtlasAppearanceSheet extends StatelessWidget {
  const AtlasAppearanceSheet({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: atlasAppearance,
    builder: (context, _) => Theme(
      data: atlasTheme(switch (atlasAppearance.mode) {
        ThemeMode.dark => Brightness.dark,
        ThemeMode.light => Brightness.light,
        ThemeMode.system => MediaQuery.platformBrightnessOf(context),
      }),
      child: Builder(
        builder: (context) => SafeArea(
          top: false,
          minimum: EdgeInsets.fromLTRB(
            16,
            0,
            16,
            20 + MediaQuery.viewPaddingOf(context).bottom,
          ),
          child: Material(
            key: const ValueKey('appearance-floating-panel'),
            color: context.atlas.surface,
            borderRadius: AtlasStyle.panelRadius,
            clipBehavior: Clip.antiAlias,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.sizeOf(context).height * .8,
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Appearance',
                            style: Theme.of(context).textTheme.headlineSmall
                                ?.copyWith(fontWeight: FontWeight.w800),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Close appearance',
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close_rounded),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Choose your look. Saved on this device.',
                      style: TextStyle(color: context.atlas.muted),
                    ),
                    const SizedBox(height: 20),
                    for (final entry in [
                      (
                        ThemeMode.system,
                        'Use device setting',
                        Icons.brightness_auto_outlined,
                      ),
                      (ThemeMode.light, 'Light', Icons.light_mode_outlined),
                      (ThemeMode.dark, 'Dark', Icons.dark_mode_outlined),
                    ]) ...[
                      Material(
                        color: atlasAppearance.mode == entry.$1
                            ? context.atlas.primarySoft
                            : context.atlas.lightBg,
                        borderRadius: AtlasStyle.controlRadius,
                        child: ListTile(
                          leading: Icon(entry.$3),
                          title: Text(
                            entry.$2,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          selected: atlasAppearance.mode == entry.$1,
                          trailing: atlasAppearance.mode == entry.$1
                              ? const Icon(Icons.check_circle_outline)
                              : null,
                          shape: RoundedRectangleBorder(
                            borderRadius: AtlasStyle.controlRadius,
                          ),
                          onTap: () => atlasAppearance.setMode(entry.$1),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
}
