/* Generated with the web build. Never cache account APIs or external media. */
const VERSION = '__ATLAS_VERSION__';
const CACHE = `skool-atlas-${VERSION}`;
const CORE = __ATLAS_CORE__;
let publicFetchCount=0;
self.addEventListener('message',event=>{
  if(event.data?.type!=='ATLAS_OFFLINE_STATUS'||!event.ports?.[0])return;
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    const ready=(await Promise.all(CORE.map(path=>cache.match(path)))).every(Boolean);
    event.ports[0].postMessage({version:VERSION,ready,files:CORE.length,publicFetchCount});
  })());
});
self.addEventListener('install', event => event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  await cache.addAll(CORE);
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async()=>{
  for(const key of await caches.keys()) {
    if((key.startsWith('skool-atlas-')||key.startsWith('flutter-'))&&key!==CACHE)await caches.delete(key);
  }
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/cdn-cgi/'))return;
  publicFetchCount++;
  // Only the build's public shell is a fallback, never an arbitrary server page.
  const isShell=url.pathname==='/'||url.pathname==='/index.html'||/^\/offline-status(?:\.html)?\/?$/.test(url.pathname);
  if(request.mode==='navigate'||isShell) {
    event.respondWith(fetch(request).catch(async()=>{
      const cache=await caches.open(CACHE);
      const saved=await cache.match(/^\/offline-status(?:\.html)?\/?$/.test(url.pathname)?'/offline-status.html':'/index.html');
      // Cloudflare redirects /index.html to /. A cached redirected response
      // cannot satisfy a browser navigation with redirect mode "manual".
      return saved?new Response(saved.body,{status:saved.status,statusText:saved.statusText,headers:saved.headers}):Response.error();
    }));
    return;
  }
  const isAsset=(CORE.includes(url.pathname)||/^\/(?:assets|icons|canvaskit)\//.test(url.pathname))&&/\.(?:js|wasm|json|png|jpe?g|webp|svg|ttf|otf|woff2?|bin)$/.test(url.pathname);
  if(!isAsset)return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    // Versioned runtime/data stay together and do not wait on a dead network.
    if(CORE.includes(url.pathname)) {
      const saved=await cache.match(url.pathname);
      if(saved)return saved;
    }
    try {
      const response=await fetch(request);
      if(response.ok&&response.type!=='opaque')await cache.put(request,response.clone());
      return response;
    } catch {return await cache.match(request)||Response.error();}
  })());
});
