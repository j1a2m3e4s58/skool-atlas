/* Generated with the web build. Never cache account APIs or external media. */
const VERSION = '__ATLAS_VERSION__';
const CACHE = `skool-atlas-${VERSION}`;
const CORE = __ATLAS_CORE__;
self.addEventListener('install', event => event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  await cache.addAll(CORE);
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async()=>{
  for(const key of await caches.keys()) {
    if((key.startsWith('skool-atlas-')||key.startsWith('flutter-'))&&key!==CACHE)await caches.delete(key);
  }
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/cdn-cgi/'))return;
  // Private invitation fragments are never sent to the server or cached.
  if(request.mode==='navigate') {
    event.respondWith(fetch(request).then(async response=>{
      if(response.ok){const cache=await caches.open(CACHE);await cache.put('/index.html',response.clone());}return response;
    }).catch(async()=>await caches.match('/index.html')||Response.error()));
    return;
  }
  const isAsset=/\.(?:js|wasm|json|png|jpe?g|webp|svg|ttf|otf|woff2?|bin)$/.test(url.pathname);
  if(!isAsset)return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    try {
      const response=await fetch(request);
      if(response.ok&&response.type!=='opaque')await cache.put(request,response.clone());
      return response;
    } catch {return await cache.match(request)||Response.error();}
  })());
});
