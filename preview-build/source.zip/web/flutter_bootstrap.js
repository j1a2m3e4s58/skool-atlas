{{flutter_js}}
{{flutter_build_config}}

// sw.js owns the root scope. Do not register Flutter's deprecated worker too.
_flutter.loader.load();
