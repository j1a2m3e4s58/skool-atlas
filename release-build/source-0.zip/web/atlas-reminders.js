/* Opt-in Web Push. No grades, notes, names or budgets leave this device. */
(() => {
  const key='tertiary.push.v1';
  const read=()=>{try{return JSON.parse(localStorage.getItem(key)||'null');}catch{return null;}};
  const write=v=>localStorage.setItem(key,JSON.stringify(v));
  const encode=bytes=>btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
  const decode=value=>Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')+'='.repeat((4-value.length%4)%4)),c=>c.charCodeAt(0));
  async function registration(){return Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('The offline app pack is still preparing. Try again shortly.')),8000))]);}
  function supported(){return window.isSecureContext&&'Notification' in window&&'serviceWorker' in navigator&&'PushManager' in window;}
  async function send(state,subscription){
    const response=await fetch('/api/reminders/'+state.id,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+state.token},
      body:JSON.stringify({subscription:subscription.toJSON(),reminders:state.reminders})});
    if(!response.ok){const data=await response.json().catch(()=>({}));throw new Error(data.error||'The reminder service could not be reached.');}
    state.pending=false;write(state);return 'Automatic reminders enabled for '+state.reminders.length+' target(s). The server stores only dates and this device subscription.';
  }
  const safe=fn=>async(...args)=>{try{return await fn(...args);}catch(error){return 'Reminder setup: '+error.message;}};
  window.atlasReminders={
    status:safe(async()=>{
      if(!supported())return 'Automatic device reminders are not supported here. You can use a calendar file instead. On iPhone/iPad, open the installed Home Screen app.';
      const state=read();return state?.enabled?(state.pending?'A reminder update is waiting for internet. Open this app online to retry.':'Automatic device reminders are enabled. Notifications also depend on browser and operating-system permissions.'):'Automatic reminders are off. Enable them here after choosing personal target dates.';
    }),
    enable:safe(async(raw)=>{
      if(!supported())throw new Error('This browser does not support automatic reminders. Use the calendar option.');
      const reminders=JSON.parse(raw);if(!reminders.length)throw new Error('Save a future target date and turn on its reminder first.');
      // Request permission only from the explicit user action, before awaiting I/O.
      const permission=await Notification.requestPermission();if(permission!=='granted')throw new Error('Notification permission was not granted. Calendar reminders remain available.');
      const response=await fetch('/api/health');if(!response.ok)throw new Error('Automatic reminders need the hosted app.');
      const health=await response.json();if(!health.pushConfigured||!health.publicKey)throw new Error('The server has not enabled push delivery yet.');
      const reg=await registration();
      let subscription=await reg.pushManager.getSubscription();
      if(!subscription)subscription=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:decode(health.publicKey)});
      const previous=read();const state={id:previous?.id||crypto.randomUUID(),token:previous?.token||encode(crypto.getRandomValues(new Uint8Array(32))),enabled:true,pending:true,reminders};
      write(state);return send(state,subscription);
    }),
    sync:safe(async(raw)=>{
      const state=read();if(!state?.enabled)return 'Automatic reminders are off.';
      state.reminders=JSON.parse(raw);state.pending=true;write(state);
      if(!navigator.onLine)return 'Reminder dates will sync when you open the app online.';
      const reg=await registration(),subscription=await reg.pushManager.getSubscription();
      if(!subscription)throw new Error('Enable this device again to restore its subscription.');
      return send(state,subscription);
    }),
    disable:safe(async()=>{
      const state=read();if(!state)return 'Automatic reminders are off.';
      const response=await fetch('/api/reminders/'+state.id,{method:'DELETE',headers:{Authorization:'Bearer '+state.token}});
      if(!response.ok)throw new Error('Connect to the internet to turn off server reminders. You can also revoke notifications in your browser settings.');
      const reg=await registration(),subscription=await reg.pushManager.getSubscription();if(subscription)await subscription.unsubscribe();
      localStorage.removeItem(key);return 'Automatic reminders are off and the server subscription was removed.';
    })
  };
  const retry=()=>{const s=read();if(s?.enabled&&s.pending)window.atlasReminders.sync(JSON.stringify(s.reminders));};
  window.addEventListener('online',retry);window.addEventListener('focus',retry);
})();
