import 'dart:js_interop';

@JS('atlasReminders.status')
external JSPromise<JSString> _status();
@JS('atlasReminders.enable')
external JSPromise<JSString> _enable(JSString dates);
@JS('atlasReminders.sync')
external JSPromise<JSString> _sync(JSString dates);
@JS('atlasReminders.disable')
external JSPromise<JSString> _disable();
Future<String> automaticReminderStatus() async =>
    (await _status().toDart).toDart;
Future<String> enableAutomaticReminders(String dates) async =>
    (await _enable(dates.toJS).toDart).toDart;
Future<String> syncAutomaticReminders(String dates) async =>
    (await _sync(dates.toJS).toDart).toDart;
Future<String> disableAutomaticReminders() async =>
    (await _disable().toDart).toDart;
