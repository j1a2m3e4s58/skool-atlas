part of 'main.dart';

class PilotFeedbackPage extends StatefulWidget {
  const PilotFeedbackPage({super.key});
  @override
  State<PilotFeedbackPage> createState() => _PilotFeedbackPageState();
}

class _PilotFeedbackPageState extends State<PilotFeedbackPage> {
  static const tasks = [
    'Find Bawjiase, Obrachire, Kwanyako and Methodist Saltpond. Check each school name and code against your official form.',
    'Open the programme-source check. Explain the difference between a vacancy snapshot and the full programme register.',
    'Use six Grade 2 results (four core subjects, Computing and French). Check that the aggregate is 12.',
    'Use sample Cape Coast / Central details. Generate a draft and read all category, residence and missing-confirmation warnings.',
    'Review a Day choice: distinguish checking the daily journey from asking the JHS/school office about catchment eligibility.',
    'Reorder and save a sample draft. Reopen it and check the choices are retained. Delete the sample draft afterwards.',
    'Test Home, Back, larger text, and the Light/Dark picker. Check the picker stays above phone navigation.',
    'Try a saved shortlist offline. Record which saved content remains available and which online actions clearly need a connection.',
  ];
  final outcomes = List.filled(tasks.length, 'Not tried');
  final feedback = TextEditingController();
  String role = 'Student with guardian';
  @override
  void dispose() {
    feedback.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PageFrame(
    maxWidth: 900,
    title: 'Student & parent pilot',
    subtitle:
        'Try the tasks together with sample information. Participation is optional; stop whenever you wish.',
    children: [
      const InfoPanel(
        title: 'Keep the test private',
        text:
            'Students should test with a guardian or teacher. Use sample grades and town details. Do not enter real index numbers, checker PINs, names, phone numbers or exact home addresses. Feedback stays on this screen until you choose Copy; it is not sent automatically.',
      ),
      Surface(
        child: DropdownButtonFormField<String>(
          initialValue: role,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Test perspective'),
          items: [
            'Student with guardian',
            'Parent / guardian',
            'Teacher',
          ].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) => setState(() => role = v!),
        ),
      ),
      for (var i = 0; i < tasks.length; i++)
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Task ${i + 1}',
                style: TextStyle(
                  color: context.atlas.primary,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(tasks[i]),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                key: ValueKey('pilot-task-$i'),
                initialValue: outcomes[i],
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Your outcome'),
                items:
                    [
                          'Not tried',
                          'Completed easily',
                          'Completed with help',
                          'Blocked',
                        ]
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                onChanged: (v) => setState(() => outcomes[i] = v!),
              ),
            ],
          ),
        ),
      Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: feedback,
              minLines: 4,
              maxLines: 8,
              maxLength: 2000,
              decoration: const InputDecoration(
                labelText: 'What was confusing or broken?',
                helperText:
                    'Include the task number, device/browser and what you expected. Leave out personal information.',
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              icon: const Icon(Icons.copy_outlined),
              label: const Text('Copy pilot feedback'),
              onPressed: () async {
                final report =
                    'Skool Atlas pilot feedback\nPerspective: $role\n${List.generate(tasks.length, (i) => 'Task ${i + 1}: ${outcomes[i]}').join('\n')}\nNotes: ${feedback.text.trim()}';
                await Clipboard.setData(ClipboardData(text: report));
                if (context.mounted) {
                  toast(
                    context,
                    'Copied. Review it before choosing who to share it with.',
                  );
                }
              },
            ),
          ],
        ),
      ),
    ],
  );
}
