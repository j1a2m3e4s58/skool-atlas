part of 'main.dart';

class ResultsPlannerPage extends StatefulWidget {
  final bool resumeSaved;
  const ResultsPlannerPage({super.key, this.resumeSaved = false});
  @override
  State<ResultsPlannerPage> createState() => _ResultsPlannerPageState();
}

class _ResultsPlannerPageState extends State<ResultsPlannerPage> with WidgetsBindingObserver {
  final grades = <String, int>{};
  final choices = <SchoolChoice>[];
  final town = TextEditingController(),
      jhsTown = TextEditingController(),
      search = TextEditingController();
  int step = 0, limit = 8;
  int? aggregate;
  bool vacanciesOnly = true;
  Timer? vacancyTimer, recoveryTimer;
  bool restoringProgress = false, recoveryCleared = false;
  String? lastSuggestedInputSignature;
  String region = '',
      district = '',
      gender = 'Not entered',
      programme = 'General Science',
      scope = 'Region & boarding',
      track = 'General',
      draftStyle = 'Balanced categories',
      resultType = 'Actual results';
  String? error;
  void resetTravelChecks() {
    for (final choice in choices.where((c) => c.residence == 'Day')) {
      choice.commuteConfirmed = false;
      choice.catchmentConfirmed = false;
    }
  }

  void sourceChanged() {
    if (mounted) setState(() {});
  }

  static const plannerSteps = [
    'Your grades',
    'Your location',
    'Find schools',
    'Review choices',
  ];
  static const plannerStepTabs = [
    '1  My results',
    '2  Where I live',
    '3  Find schools',
    '4  Review choices',
  ];

  String get _recommendationInputSignature => jsonEncode({
    'grades': Map.fromEntries(grades.entries.toList()..sort((a, b) => a.key.compareTo(b.key))),
    'aggregate': aggregate,
    'town': town.text.trim(),
    'jhsTown': jhsTown.text.trim(),
    'region': region,
    'district': district,
    'gender': gender,
    'programme': programme,
    'track': track,
    'scope': scope,
    'draftStyle': draftStyle,
    'search': search.text.trim(),
    'resultType': resultType,
    'vacanciesOnly': vacanciesOnly,
    'vacanciesCheckedAt': officialVacancies.fetchedAt?.toUtc().toIso8601String(),
  });

  bool get _suggestionsNeedRefresh => lastSuggestedInputSignature != null &&
      lastSuggestedInputSignature != _recommendationInputSignature;

  Widget plannerProgress(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: context.atlas.primarySoft,
              child: Text(
                '${step + 1}',
                style: TextStyle(
                  color: context.atlas.primary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Step ${step + 1} of ${plannerSteps.length}',
                    style: TextStyle(
                      color: context.atlas.muted,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    plannerSteps[step],
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: (step + 1) / plannerSteps.length,
            minHeight: 7,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var i = 0; i < plannerSteps.length; i++)
              ChoiceChip(
                label: Text(plannerStepTabs[i]),
                selected: step == i,
                onSelected: (_) => setState(() => step = i),
              ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'You can go back and change anything before you finish.',
          style: TextStyle(color: context.atlas.muted, height: 1.45),
        ),
      ],
    ),
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    publishedUpdates.addListener(sourceChanged);
    officialVacancies.addListener(sourceChanged);
    unawaited(officialVacancies.refresh());
    vacancyTimer = Timer.periodic(const Duration(minutes: 5), (_) => officialVacancies.refresh());
    final recovery = planningStore.inProgressPlan;
    if (!widget.resumeSaved && recovery != null) _restoreProgress(recovery);
    if (widget.resumeSaved) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) loadDraft();
      });
    }
  }

  @override
  void setState(VoidCallback fn) {
    super.setState(fn);
    recoveryCleared = false;
    if (!restoringProgress) _scheduleRecoverySave();
  }

  Map<String, dynamic> _plannerSnapshot() => {
    'schema': 'choice-recovery-v1',
    'grades': Map<String, int>.from(grades),
    'town': town.text,
    'jhsTown': jhsTown.text,
    'region': region,
    'district': district,
    'gender': gender,
    'programme': programme,
    'track': track,
    'scope': scope,
    'draftStyle': draftStyle,
    'resultType': resultType,
    'search': search.text,
    'step': step,
    'limit': limit,
    'aggregate': aggregate,
    'vacanciesOnly': vacanciesOnly,
    'lastSuggestedInputSignature': lastSuggestedInputSignature,
    'choices': choices.map((choice) => choice.toJson()).toList(),
    'updated': DateTime.now().toIso8601String(),
  };

  void _scheduleRecoverySave() {
    recoveryTimer?.cancel();
    recoveryTimer = Timer(const Duration(milliseconds: 350), _saveRecoveryNow);
  }

  void _saveRecoveryNow() {
    recoveryTimer?.cancel();
    recoveryTimer = null;
    if (!recoveryCleared) unawaited(planningStore.saveInProgressPlan(_plannerSnapshot()));
  }

  void _restoreProgress(Map<String, dynamic> data) {
    restoringProgress = true;
    try {
      grades..clear()..addAll(Map<String, int>.from(data['grades'] as Map? ?? {}));
      town.text = '${data['town'] ?? ''}';
      jhsTown.text = '${data['jhsTown'] ?? ''}';
      search.text = '${data['search'] ?? ''}';
      region = '${data['region'] ?? ''}';
      district = '${data['district'] ?? ''}';
      gender = '${data['gender'] ?? 'Not entered'}';
      programme = '${data['programme'] ?? 'General Science'}';
      track = '${data['track'] ?? 'General'}';
      scope = '${data['scope'] ?? 'Region & boarding'}';
      draftStyle = '${data['draftStyle'] ?? 'Balanced categories'}';
      resultType = '${data['resultType'] ?? 'Actual results'}';
      step = (data['step'] as num?)?.toInt().clamp(0, 3).toInt() ?? 0;
      limit = (data['limit'] as num?)?.toInt().clamp(8, 200).toInt() ?? 8;
      aggregate = (data['aggregate'] as num?)?.toInt();
      vacanciesOnly = data['vacanciesOnly'] as bool? ?? true;
      lastSuggestedInputSignature = data['lastSuggestedInputSignature'] as String?;
      choices..clear()..addAll((data['choices'] as List? ?? []).map((choice) => SchoolChoice.fromJson(choice as Map)));
      if (choices.isNotEmpty && lastSuggestedInputSignature == null) {
        lastSuggestedInputSignature = _recommendationInputSignature;
      }
    } catch (_) {
      grades.clear();
      choices.clear();
      town.clear();
      jhsTown.clear();
      search.clear();
      region = '';
      district = '';
      gender = 'Not entered';
      step = 0;
      aggregate = null;
      lastSuggestedInputSignature = null;
      unawaited(planningStore.clearInProgressPlan());
    } finally {
      restoringProgress = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden || state == AppLifecycleState.detached) {
      _saveRecoveryNow();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveRecoveryNow();
    publishedUpdates.removeListener(sourceChanged);
    officialVacancies.removeListener(sourceChanged);
    vacancyTimer?.cancel();
    town.dispose();
    jhsTown.dispose();
    search.dispose();
    super.dispose();
  }

  void loadDraft() {
    final data = planningStore.savedPlan;
    if (data == null) return;
    setState(() {
      grades
        ..clear()
        ..addAll(Map<String, int>.from(data['grades'] as Map? ?? {}));
      town.text = '${data['town'] ?? ''}';
      jhsTown.text = '${data['jhsTown'] ?? ''}';
      region = '${data['region'] ?? ''}';
      district = '${data['district'] ?? ''}';
      gender = '${data['gender'] ?? 'Not entered'}';
      programme = '${data['programme'] ?? 'General Science'}';
      track = '${data['track'] ?? 'General'}';
      draftStyle = '${data['draftStyle'] ?? 'Balanced categories'}';
      resultType = '${data['resultType'] ?? 'Actual results'}';
      scope = '${data['scope'] ?? 'Region & boarding'}';
      search.text = '${data['search'] ?? ''}';
      vacanciesOnly = data['vacanciesOnly'] as bool? ?? true;
      lastSuggestedInputSignature = data['lastSuggestedInputSignature'] as String?;
      limit = (data['limit'] as num?)?.toInt().clamp(8, 200).toInt() ?? 8;
      choices
        ..clear()
        ..addAll(
          (data['choices'] as List? ?? []).map(
            (c) => SchoolChoice.fromJson(c as Map),
          ),
        );
      try {
        aggregate = resultsAggregate(grades);
      } on ArgumentError {
        aggregate = null;
      }
      step = (data['step'] as num?)?.toInt().clamp(0, 3).toInt() ?? (choices.isNotEmpty
          ? 3
          : town.text.trim().isNotEmpty && region.isNotEmpty
          ? 2
          : 0);
      aggregate = (data['aggregate'] as num?)?.toInt() ?? aggregate;
      if (choices.isNotEmpty && lastSuggestedInputSignature == null) {
        lastSuggestedInputSignature = _recommendationInputSignature;
      }
    });
  }

  Future<void> saveDraft() async {
    final data = _plannerSnapshot()
      ..['schema'] = 'choice-plan-v1'
      ..['saved'] = DateTime.now().toIso8601String();
    await planningStore.savePlan(data);
    await planningStore.saveInProgressPlan(_plannerSnapshot());
    if (mounted) {
      toast(
        context,
        planningStore.persistent
            ? 'Draft saved on this device, including the grades and town you entered.'
            : 'Device storage is unavailable. Download your school-choice pack instead.',
      );
    }
  }

  void calculate() {
    try {
      final value = resultsAggregate(grades);
      final paths = gradeStudyPaths(grades);
      setState(() {
        aggregate = value;
        error = null;
        if (paths.isNotEmpty &&
            !paths.any(
              (p) =>
                  p.programme == programme && p.average == paths.first.average,
            )) {
          programme = paths.first.programme;
        }
      });
    } on ArgumentError catch (e) {
      setState(() => error = '${e.message}');
    }
  }

  Future<void> suggestDraft(List<SchoolMatch> options) async {
    if (choices.isNotEmpty) {
      final replace = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Update your school suggestions?'),
          content: const Text(
            'This replaces the choices on screen with suggestions for your updated grades or preferences. Your saved device draft stays unchanged.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Keep my choices'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Update suggestions'),
            ),
          ],
        ),
      );
      if (replace != true || !mounted) return;
    }
    setState(() {
      step = 3;
      choices.clear();
      choices.addAll(
        buildSuggestedChoices(
          options: options.map((m) => m.school).toList(),
          programme: programme,
          region: region,
          town: town.text,
          gender: gender,
          district: district,
          style: draftStyle,
          scope: scope,
          residenceAllowed: vacanciesOnly ? (school, residence) => officialVacancies.available(
            school.id, programme, residence, gender) : null,
        ),
      );
      lastSuggestedInputSignature = _recommendationInputSignature;
    });
    toast(
      context,
      '${choices.length} of 8 suggestions ready. Check the order and daily travel with your guardian and JHS. These are not confirmed admission eligibility.',
    );
  }

  Future<void> addSchool(School school) async {
    if (school.programs.isEmpty || !school.selectable) {
      toast(
        context,
        'Current programmes or operation need confirmation before adding this school.',
      );
      return;
    }
    if (choices.length >= 8) {
      toast(
        context,
        'Your draft already has eight choices. Remove one to add another.',
      );
      return;
    }
    if (choices.any((c) => c.schoolId == school.id)) {
      toast(context, 'This school is already in your draft.');
      return;
    }
    String p = school.programs.contains(programme)
        ? programme
        : school.programs.first;
    final residences = ['Day', 'Boarding']
        .where(school.residency.contains)
        .where((r) => !vacanciesOnly || officialVacancies.available(school.id, p, r, gender))
        .where((r) => school.category != 'Pilot private' || r == 'Day')
        .toList();
    if (residences.isEmpty) {
      toast(context, 'Confirm this school residence before adding it.');
      return;
    }
    String residence = residences.contains('Day') && school.region == region
        ? 'Day'
        : residences.last;
    final choice = await showDialog<SchoolChoice>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: const Text('Add a school choice'),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SchoolName(
                    school: school,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<String>(
                    initialValue: p,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Programme for this choice',
                    ),
                    items: school.programs
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => update(() => p = v!),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    initialValue: residence,
                    decoration: const InputDecoration(
                      labelText: 'Residence for this choice',
                    ),
                    items: residences
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => update(() => residence = v!),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Add this to a draft for discussion. Review the exact subject combination and school code before official submission.',
                    style: TextStyle(color: context.atlas.muted, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(
                dialogContext,
                SchoolChoice(
                  schoolId: school.id,
                  programme: p,
                  residence: residence,
                  reviewedSignature: school.selectionSignature,
                ),
              ),
              child: const Text('Add to my eight choices'),
            ),
          ],
        ),
      ),
    );
    if (choice != null && mounted) setState(() => choices.add(choice));
  }

  @override
  Widget build(BuildContext context) {
    final paths = aggregate == null
        ? <({String programme, double average, List<String> subjects})>[]
        : gradeStudyPaths(grades);
    final programmes =
        schools
            .where((s) => s.data['registerYear'] == 2026)
            .expand((s) => s.programs)
            .toSet()
            .toList()
          ..sort();
    if (!programmes.contains(programme)) programmes.add(programme);
    final regions = schools.map((s) => s.region).toSet().toList()..sort();
    final districts =
        schools
            .where((s) => s.region == region)
            .map((s) => '${s.data['district'] ?? ''}')
            .where((d) => d.isNotEmpty)
            .toSet()
            .toList()
          ..sort();
    final options = region.isEmpty
        ? <SchoolMatch>[]
        : resultsSchoolOptions(
                programme: programme,
                region: region,
                district: district,
                town: town.text,
                gender: gender,
                scope: scope,
                query: search.text,
                grades: aggregate == null ? const {} : grades,
              )
              .where(
                (m) =>
                    track != 'TVET only' || m.school.kind == 'TVET / technical',
              )
              .where((m) => !vacanciesOnly || ['Day', 'Boarding'].any((r) =>
                m.school.residency.contains(r) && officialVacancies.available(
                  m.school.id, programme, r, gender)))
              .where(
                (m) =>
                    track != 'Science / STEM' ||
                    ['General Science', 'STEM'].contains(programme),
              )
              .toList();
    final checks = validateSchoolChoices(
      choices,
      gender: gender,
      town: town.text,
      region: region,
      track: track,
    );
    for (final choice in choices) {
      if (!officialVacancies.available(choice.schoolId, choice.programme, choice.residence, gender)) {
        checks.add(ChoiceCheck('vacancy-confirmation',
          '${choice.school?.name ?? choice.schoolId}: current programme/residence vacancy not confirmed. Refresh and check your candidate options on official CSSPS.'));
      }
    }
    return PageFrame(
      title: 'Plan with your results',
      subtitle: 'Four quick steps to a school-choice draft. Progress saves on this device.',
      children: [
        plannerProgress(context),
        if (step == 0) ...[
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(8),
            child: ExpansionTile(
              leading: Icon(
                Icons.confirmation_number_outlined,
                color: context.atlas.primary,
              ),
              title: const Text('Need a results checker?'),
              subtitle: const Text('Buy one, then return here with your grades.'),
              children: [
                const Text('Keep your checker PIN private. Skool Atlas never asks you to enter it.'),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => openLink(
                    context,
                    Uri.parse(resultsCheckerShopUrl),
                  ),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Buy a results checker'),
                ),
              ],
            ),
          ),
        ],
        if (step == 2) ...[
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(8),
            child: CheckboxListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
              title: const Text('Use schools with published vacancies'),
              subtitle: Text(
                officialVacancies.fresh
                    ? 'These spaces can change. Confirm your choices on CSSPS.'
                    : 'No current vacancy list. Refresh or browse unconfirmed options.',
              ),
              value: vacanciesOnly,
              onChanged: (value) =>
                  setState(() => vacanciesOnly = value ?? true),
            ),
          ),
          const SizedBox(height: 10),
          Surface(
            padding: const EdgeInsets.all(8),
            child: ExpansionTile(
              leading: Icon(
                Icons.fact_check_outlined,
                color: context.atlas.primary,
              ),
              title: const Text('Vacancy source and last check'),
              subtitle: Text(
                officialVacancies.fetchedAt == null
                    ? 'No official snapshot loaded yet'
                    : 'Checked ${officialVacancies.fetchedAt!.toLocal().toString().substring(0, 16)} · ${officialVacancies.fresh ? 'recent snapshot' : 'needs a fresh check'}',
              ),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              children: [
                if (officialVacancies.error != null)
                  Text(officialVacancies.error!),
                const Text(
                  'Refreshed hourly from the CSSPS public directory. Programme and residence counts are listed separately. They do not reserve a place or confirm your candidate eligibility. Confirm the exact combination on CSSPS; counts can change before you submit.',
                  style: TextStyle(height: 1.5),
                ),
                BalancedActions(children: [
                  OutlinedButton.icon(
                    onPressed: officialVacancies.busy
                        ? null
                        : () => officialVacancies.refresh(),
                    icon: const Icon(Icons.refresh),
                    label: Text(officialVacancies.busy
                        ? 'Checking vacancies…'
                        : 'Refresh vacancies'),
                  ),
                  TextButton(
                    onPressed: () => openLink(
                      context,
                      Uri.parse('https://www.cssps.gov.gh/vacancies'),
                    ),
                    child: const Text('Open official vacancy list'),
                  ),
                ]),
              ],
            ),
          ),
        ],
        if (step == 3)
          DraftProgressPanel(choices: choices, checks: checks),
        const SizedBox(height: 18),
        Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Privacy & saved drafts'),
                subtitle: const Text(
                  'Recovery is automatic and stays on this device.',
                ),
                children: [
                  const Text(
                    'Your progress is saved on this device',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'To help you return after a call, app switch or restart, Skool Atlas automatically saves your planner progress, including grades and town, on this device. It is not synced to an account. Never enter your name, index number or checker PIN. You can clear the recovery copy below.',
                    style: TextStyle(color: context.atlas.muted, height: 1.6),
                  ),
                  const SizedBox(height: 16),
                  BalancedActions(
                    children: [
                      TextButton.icon(
                        onPressed: saveDraft,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('Save draft on this device'),
                      ),
                      TextButton(
                        onPressed: planningStore.savedPlan == null
                            ? null
                            : loadDraft,
                        child: const Text('Load saved draft'),
                      ),
                      TextButton(
                        onPressed: planningStore.savedPlan == null
                            ? null
                            : () async {
                                await planningStore.forgetPlan();
                                if (mounted && context.mounted) {
                                  setState(() {});
                                  toast(
                                    context,
                                    'Saved device draft deleted. Your current on-screen work is still open.',
                                  );
                                }
                              },
                        child: const Text('Delete saved device draft'),
                      ),
                      TextButton(
                        onPressed: planningStore.inProgressPlan == null
                            ? null
                            : () async {
                                await planningStore.clearInProgressPlan();
                                if (!context.mounted) return;
                                setState(() {});
                                recoveryTimer?.cancel();
                                recoveryCleared = true;
                                toast(context, 'Recovery copy cleared. This screen remains open until you leave it.');
                              },
                        child: const Text('Clear recovery copy'),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (step == 0) ...[
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Enter your BECE grades',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final type in ['Actual results', 'Expected grades'])
                      ChoiceChip(
                        label: Text(type),
                        selected: resultType == type,
                        onSelected: (_) => setState(() => resultType = type),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Enter your four core grades and at least two other grades. Grade 1 is strongest; 9 is lowest.',
                  style: TextStyle(color: context.atlas.muted, height: 1.45),
                ),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: const Text('How is my aggregate worked out?'),
                  children: const [
                    Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Text(
                        'English + Mathematics + Science + Social Studies + your best two other subject grades. Leave subjects you did not take blank.',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final scale = MediaQuery.textScalerOf(context).scale(16) / 16;
                    final columns = constraints.maxWidth >= 980 * scale
                        ? 3
                        : constraints.maxWidth >= 620 * scale
                        ? 2
                        : 1;
                    final gap = 14.0;
                    final fieldWidth = columns == 1
                        ? constraints.maxWidth
                        : (constraints.maxWidth - gap * (columns - 1)) / columns;
                    return Wrap(
                      spacing: gap,
                      runSpacing: 18,
                      children: [
                        for (final subject in [...coreSubjects, ...otherSubjects])
                          SizedBox(
                            width: fieldWidth,
                            child: DropdownButtonFormField<int>(
                              key: ValueKey('grade-$subject-${grades[subject]}'),
                              initialValue: grades[subject],
                              isExpanded: true,
                              dropdownColor: Theme.of(context).colorScheme.surface,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ).copyWith(color: context.atlas.dark),
                              selectedItemBuilder: (context) => [
                                Text(
                                  'Not entered',
                                  style: TextStyle(
                                    color: Theme.of(context).colorScheme.onSurface,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                for (var g = 1; g <= 9; g++)
                                  Text(
                                    'Grade $g',
                                    style: TextStyle(
                                      color: Theme.of(context).colorScheme.onSurface,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                              ],
                              decoration: InputDecoration(
                                labelText: subject,
                                labelStyle: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                                floatingLabelStyle: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 18,
                                ),
                              ),
                              items: [
                                DropdownMenuItem<int>(
                                  value: null,
                                  child: Text(
                                    'Not entered',
                                    style: TextStyle(color: context.atlas.dark),
                                  ),
                                ),
                                for (var g = 1; g <= 9; g++)
                                  DropdownMenuItem(
                                    value: g,
                                    child: Text(
                                      'Grade $g',
                                      style: TextStyle(color: context.atlas.dark),
                                    ),
                                  ),
                              ],
                              onChanged: (g) => setState(() {
                                if (g == null) {
                                  grades.remove(subject);
                                } else {
                                  grades[subject] = g;
                                }
                                aggregate = null;
                              }),
                            ),
                          ),
                      ],
                    );
                  },
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(
                      error!,
                      style: const TextStyle(color: Colors.deepOrange),
                    ),
                  ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: calculate,
                  icon: const Icon(Icons.calculate_outlined),
                  label: const Text('Analyse my grades'),
                ),
              ],
            ),
          ),
          if (aggregate != null) ...[
            const SizedBox(height: 18),
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your six-subject aggregate: $aggregate',
                    style: TextStyle(
                      fontSize: 27,
                      fontWeight: FontWeight.w800,
                      color: context.atlas.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '$resultType · English, Maths, Science, Social Studies + your best two other grades.',
                    style: TextStyle(color: context.atlas.muted, height: 1.45),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Study paths to discuss',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Study ideas from your grades—not admission guarantees. Choose a programme that also interests you.',
                    style: TextStyle(color: context.atlas.muted, height: 1.45),
                  ),
                  for (final path in paths.where(
                    (p) =>
                        p.average <=
                        paths[paths.length < 3 ? paths.length - 1 : 2].average,
                  ))
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(path.programme),
                      subtitle: Text(
                        'Based on ${path.subjects.map((s) => '$s (${grades[s]})').join(', ')}',
                      ),
                      trailing: TextButton(
                        onPressed: () =>
                            setState(() => programme = path.programme),
                        child: Text(
                          programme == path.programme ? 'Selected' : 'Explore',
                        ),
                      ),
                    ),
                  if (grades['English Language'] == 9 ||
                      grades['Mathematics'] == 9)
                    Padding(
                      padding: EdgeInsets.only(top: 12),
                      child: Text(
                        'Got Grade 9 in English or Maths? Check your options on CSSPS with your JHS. This app does not decide admission.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          height: 1.6,
                        ),
                      ),
                    ),
                  const SizedBox(height: 14),
                  FilledButton(
                    onPressed: () => setState(() => step = 1),
                    child: const Text('Next: where I live'),
                  ),
                ],
              ),
            ),
          ],
        ],
        if (step == 1)
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where do you live?',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                Text(
                  'Your town and region help us find nearby schools.',
                  style: TextStyle(color: context.atlas.muted),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: town,
                  decoration: const InputDecoration(
                    labelText: 'Your home town or community',
                    hintText: 'For example, Bawjiase',
                  ),
                  onChanged: (_) => setState(resetTravelChecks),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('home-region-$region'),
                  initialValue: region.isEmpty ? null : region,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Your home region',
                  ),
                  items: regions
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() {
                    region = r!;
                    district = '';
                    resetTravelChecks();
                  }),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('home-district-$region-$district'),
                  initialValue:
                      district.isEmpty || !districts.contains(district)
                      ? null
                      : district,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Your district (optional)',
                    helperText: 'Adding it can help find nearby day schools.',
                  ),
                  items: districts
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() {
                    district = r!;
                    resetTravelChecks();
                  }),
                ),
                const SizedBox(height: 8),
                ExpansionTile(
                  title: const Text('Add your JHS town (optional)'),
                  subtitle: const Text(
                    'Use this if your school is in a different town.',
                  ),
                  children: [
                    TextField(
                      controller: jhsTown,
                      onChanged: (_) => setState(resetTravelChecks),
                      decoration: const InputDecoration(
                        labelText: 'JHS town',
                        helperText:
                            'Ask your JHS guidance teacher to confirm catchment.',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('candidate-gender-$gender'),
                  initialValue: gender,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText:
                        'Gender on your candidate record',
                    helperText:
                        'Used to check published vacancy counts for the right group.',
                  ),
                  items: ['Not entered', 'Male', 'Female']
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  onChanged: (r) => setState(() => gender = r!),
                ),
                const SizedBox(height: 18),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: const Text('Choosing a Day school safely'),
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        'Ask your JHS to check catchment. With your guardian, check the daily route, fare and safe return time. Nearby suggestions do not confirm eligibility.',
                        style: TextStyle(color: context.atlas.muted, height: 1.45),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () {
                    if (town.text.trim().isEmpty || region.isEmpty) {
                      toast(context, 'Enter your home town and region first.');
                      return;
                    }
                    setState(() => step = 2);
                  },
                  child: const Text('Next: explore suitable options'),
                ),
              ],
            ),
          ),
        if (step == 2) ...[
          if (aggregate == null)
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Surface(
                child: Text(
                  'You can explore programmes and choices now. Add grades in Step 1 to see your aggregate and subject-strength suggestions.',
                ),
              ),
            ),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Choose a programme',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  aggregate == null
                      ? 'Choose what you want to study and how far you can travel.'
                      : 'Aggregate $aggregate · choose a programme and travel distance.',
                  style: TextStyle(color: context.atlas.muted, height: 1.45),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  key: ValueKey('planner-programme-$programme'),
                  initialValue: programme,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Which programme interests you?',
                  ),
                  items: programmes
                      .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                      .toList(),
                  onChanged: (p) => setState(() {
                    programme = p!;
                    limit = 8;
                  }),
                ),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  initialValue: scope,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'How far can you travel for school?',
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: 'Nearby day schools',
                      child: Text('Day schools near my town'),
                    ),
                    const DropdownMenuItem(
                      value: 'Day schools in my region',
                      child: Text('Day schools in my region'),
                    ),
                    const DropdownMenuItem(
                      value: 'Region & boarding',
                      child: Text('Schools in my region, Day or Boarding'),
                    ),
                    const DropdownMenuItem(
                      value: 'Boarding across Ghana',
                      child: Text('Boarding schools anywhere in Ghana'),
                    ),
                  ],
                  onChanged: (p) => setState(() {
                    scope = p!;
                    limit = 8;
                  }),
                ),
                Text(
                '${options.length} schools found near ${town.text.trim()}, $region${district.isEmpty ? '' : ' · $district'}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Surface(
                  padding: const EdgeInsets.all(8),
                  child: ExpansionTile(
                    leading: Icon(
                      Icons.tune_outlined,
                      color: context.atlas.primary,
                    ),
                    title: const Text('More filters (optional)'),
                    subtitle: const Text(
                      'Search by school name or narrow the study track.',
                    ),
                    children: [
                      DropdownButtonFormField<String>(
                        isExpanded: true,
                        key: ValueKey('planner-track-$track'),
                        initialValue: track,
                        decoration: const InputDecoration(
                          labelText: 'Study track',
                        ),
                        items: ['General', 'TVET only', 'Science / STEM']
                            .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                            .toList(),
                        onChanged: (p) => setState(() => track = p!),
                      ),
                      const SizedBox(height: 14),
                      TextField(
                        controller: search,
                        decoration: const InputDecoration(
                          labelText: 'School name (optional)',
                          prefixIcon: Icon(Icons.search),
                        ),
                        onChanged: (_) => setState(() => limit = 8),
                      ),
                      const SizedBox(height: 14),
                      DropdownButtonFormField<String>(
                        initialValue: draftStyle,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Draft preference',
                          helperText:
                              'This affects the mix of suggestions, not eligibility.',
                        ),
                        items: [
                          'Balanced categories',
                          'Category C focus',
                          'Day-only draft',
                        ].map((v) => DropdownMenuItem(value: v, child: Text(v)))
                         .toList(),
                        onChanged: (v) => setState(() => draftStyle = v!),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'A town or district match is only a starting point. Ask your guardian and JHS to confirm the Day school catchment and daily journey. The app does not measure travel distance or predict admission.',
                        style: TextStyle(color: context.atlas.muted, height: 1.5),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Schools with an unresolved identity or code are left out of automatic suggestions until checked. Grades do not set Category A, B or C eligibility.',
                        style: TextStyle(
                          color: context.atlas.muted,
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: options.isEmpty ||
                            aggregate == null ||
                            !['Male', 'Female'].contains(gender) ||
                            (choices.isNotEmpty && !_suggestionsNeedRefresh)
                        ? null
                        : () => unawaited(suggestDraft(options)),
                    icon: const Icon(Icons.playlist_add_check),
                    label: Text(
                      choices.isNotEmpty && _suggestionsNeedRefresh
                          ? 'Update my 8 suggestions'
                          : 'Suggest my 8 choices',
                    ),
                  ),
                ),
                if (choices.isNotEmpty && !_suggestionsNeedRefresh)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      lastSuggestedInputSignature == null
                          ? 'Remove your current choices before starting a suggested draft.'
                          : 'These suggestions are up to date. Change a preference to refresh them.',
                      style: TextStyle(color: context.atlas.muted, height: 1.4),
                    ),
                  ),
                if (aggregate == null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      'Add and analyse your grades first to get suggestions.',
                      style: TextStyle(color: context.atlas.muted, height: 1.5),
                    ),
                  ),
                if (!['Male', 'Female'].contains(gender))
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      'Choose the gender on your candidate record to get suggestions.',
                      style: TextStyle(color: context.atlas.muted, height: 1.5),
                    ),
                  ),
                if (options.isEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      vacanciesOnly
                          ? 'No matches yet. Try another programme or area, or include schools with unconfirmed vacancies.'
                          : 'No matches yet. Try another programme or search area.',
                      style: TextStyle(color: context.atlas.muted, height: 1.6),
                    ),
                  ),
              ],
            ),
          ),
          for (final match in options.take(limit))
            Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SchoolName(
                      school: match.school,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '${match.school.region} · ${match.school.categoryLabel} · $programme',
                      style: TextStyle(color: context.atlas.muted, height: 1.4),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Sources: ${match.school.plannerSourceLabel}',
                      style: TextStyle(
                        color: context.atlas.muted,
                        fontSize: 13,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 6),
                    ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      title: const Text('Why this school may fit'),
                      subtitle: Text(match.reasons.first),
                      children: [
                        for (final reason in match.reasons.skip(1))
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(reason, style: TextStyle(color: context.atlas.muted, height: 1.4)),
                            ),
                          ),
                        Text(
                          'Published programme spaces: ${officialVacancies.fresh ? officialVacancies.programmeCount(match.school.id, programme) : 'unconfirmed'}. Check the current selection form and requirements on CSSPS.',
                          style: TextStyle(color: context.atlas.muted, height: 1.4),
                        ),
                      ],
                    ),
                    if (match.school.data['registerCodeConflict'] == true)
                      const Text(
                        'Printed school code needs confirmation before official selection.',
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 12,
                        ),
                      ),
                    BalancedActions(
                      children: [
                        FilledButton.tonal(
                          onPressed: () => addSchool(match.school),
                          child: const Text('Add to my choices'),
                        ),
                        TextButton(
                          onPressed: () => showSchool(context, match.school),
                          child: const Text('View profile'),
                        ),
                        TextButton(
                          onPressed: () =>
                              openLink(context, match.school.mapUri),
                          child: const Text('Check school map'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          if (options.length > limit)
            TextButton(
              onPressed: () => setState(() => limit += 8),
              child: const Text('Show more school options'),
            ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => setState(() => step = 3),
            icon: const Icon(Icons.fact_check_outlined),
            label: Text('Review my choices (${choices.length}/8)'),
          ),
        ],
        if (step == 3) ...[
          const SizedBox(height: 24),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  aggregate == null
                      ? 'Your school-choice draft'
                      : 'Your results and school-choice draft',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  aggregate == null
                      ? 'No grades have been analysed. These are schools you added to discuss with your family and JHS teacher.'
                      : '$resultType · six-subject aggregate $aggregate · $programme · ${town.text.trim()}, $region${district.isEmpty ? '' : ' · $district'}',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'My eight choices (${choices.length}/8)',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w800,
                    color: context.atlas.primaryDark,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Rank schools in your real order of preference. A school may appear once. Confirm daily travel for every Day option.',
                  style: TextStyle(color: context.atlas.muted, height: 1.6),
                ),
                TextButton.icon(
                  onPressed: choices.isEmpty
                      ? null
                      : () => setState(() {
                          final ordered = arrangeSchoolChoices(choices);
                          choices
                            ..clear()
                            ..addAll(ordered);
                        }),
                  icon: const Icon(Icons.sort),
                  label: const Text(
                    'Arrange A → B → C, Day last within each group',
                  ),
                ),
                Text(
                  'Suggested drafts start in this category order. Day choices remain within their categories, with a Category C Day choice last when available. You may move choices into your actual preference order before official submission.',
                  style: TextStyle(color: context.atlas.muted, height: 1.5),
                ),
                if (choices.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 18),
                    child: Text(
                      'Add schools from the options above, or use the draft suggestion to start.',
                    ),
                  ),
                for (var i = 0; i < choices.length; i++)
                  choiceCard(choices[i], i),
                const SizedBox(height: 18),
                const Text(
                  'Rule checks',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                ),
                if (!checks.any((c) => c.error))
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'The coded choice checks pass. Your JHS / guardian must still verify catchment, current rules and availability before official submission.',
                      style: TextStyle(
                        color: context.atlas.primary,
                        fontWeight: FontWeight.w700,
                        height: 1.6,
                      ),
                    ),
                  ),
                for (final check in checks)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          check.error ? Icons.info_outline : Icons.history,
                          size: 19,
                          color: check.error
                              ? Colors.deepOrange
                              : context.atlas.muted,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            check.message,
                            style: const TextStyle(height: 1.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 18),
                ExportChoiceActions(
                  checks: checks,
                  selected: choices
                      .map((c) => c.school)
                      .whereType<School>()
                      .toList(),
                  choices: choices,
                ),
                const SizedBox(height: 16),
                BalancedActions(
                  children: [
                    FilledButton.icon(
                      onPressed: saveDraft,
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Save this draft on my device'),
                    ),
                    OutlinedButton(
                      onPressed: choices.isEmpty
                          ? null
                          : () => openPlanningTool(
                              context,
                              OfflineChoicesPage(
                                selected: choices
                                    .map((c) => c.school)
                                    .whereType<School>()
                                    .toList(),
                              ),
                              'Take my choices offline',
                            ),
                      child: const Text('Download / share chosen schools'),
                    ),
                    TextButton(
                      onPressed: choices.isEmpty
                          ? null
                          : () => setState(choices.clear),
                      child: const Text('Clear on-screen choices'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 24),
        if (step == 3) ...[
          const OfficialSelectionSummary(compact: true),
          const SizedBox(height: 12),
          Surface(
            padding: const EdgeInsets.all(8),
            child: ExpansionTile(
              leading: Icon(Icons.menu_book_outlined, color: context.atlas.primary),
              title: const Text('Read the full official selection rules'),
              children: const [SelectionRulesPanel()],
            ),
          ),
        ],
      ],
    );
  }

  Widget choiceCard(SchoolChoice choice, int index) {
    final school = choice.school;
    if (school == null) {
      return ListTile(
        title: const Text('School needs remapping'),
        trailing: IconButton(
          tooltip: 'Remove choice',
          onPressed: () => setState(() => choices.removeAt(index)),
          icon: const Icon(Icons.close),
        ),
      );
    }
    return Container(
      margin: const EdgeInsets.only(top: 18),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.atlas.lightBg,
        border: Border.all(color: context.atlas.border),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Material(
        color: Colors.transparent,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: context.atlas.primarySoft,
                  child: Text(
                    '${index + 1}',
                    style: TextStyle(
                      color: context.atlas.primary,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SchoolName(
                    school: school,
                    badgeSize: 32,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              '${choice.selectionCategory} | ${choice.programme} | ${choice.residence}\nSchool code: ${school.data['code'] ?? 'Unconfirmed'}',
              style: TextStyle(color: context.atlas.muted, height: 1.6),
            ),
            const SizedBox(height: 10),
            ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 14),
              childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              minTileHeight: 64,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: context.atlas.border),
              ),
              collapsedShape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: context.atlas.border),
              ),
              backgroundColor: context.atlas.surface,
              collapsedBackgroundColor: context.atlas.surface,
              title: const Text(
                'Why it fits · What to check',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              children: [
                Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(
                  officialVacancies.describe(choice.schoolId, choice.programme, choice.residence, gender),
                  style: const TextStyle(height: 1.5))),
                for (final reason in choiceFitReasons(choice,
                  grades: aggregate == null ? const {} : grades,
                  region: region, town: town.text, district: district))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(reason, style: const TextStyle(height: 1.5)),
                    ),
                  ),
              ],
            ),
            if (choice.reviewedSignature.isNotEmpty &&
                choice.reviewedSignature != school.selectionSignature) ...[
              const SizedBox(height: 12),
              const Text(
                'School details changed. Check the programme, residence and code again. Remove and add this choice again if your programme is no longer offered.',
                style: TextStyle(color: Colors.deepOrange, height: 1.5),
              ),
              OutlinedButton.icon(
                onPressed:
                    school.programs.contains(choice.programme) &&
                        school.residency.contains(choice.residence) &&
                        school.selectable
                    ? () => setState(() {
                        choice.reviewedSignature = school.selectionSignature;
                        choice.codeConfirmed = false;
                        choice.commuteConfirmed = false;
                        choice.catchmentConfirmed = false;
                      })
                    : null,
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('I reviewed the updated details'),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                IconButton(
                  tooltip: 'Move choice up',
                  onPressed: index == 0
                      ? null
                      : () => setState(() {
                          final previous = choices.removeAt(index);
                          choices.insert(index - 1, previous);
                        }),
                  icon: const Icon(Icons.arrow_upward),
                ),
                IconButton(
                  tooltip: 'Move choice down',
                  onPressed: index == choices.length - 1
                      ? null
                      : () => setState(() {
                          final previous = choices.removeAt(index);
                          choices.insert(index + 1, previous);
                        }),
                  icon: const Icon(Icons.arrow_downward),
                ),
                TextButton(
                  onPressed: () => setState(() => choices.removeAt(index)),
                  child: const Text('Remove'),
                ),
                TextButton(
                  onPressed: () => showSchool(context, school),
                  child: const Text('View school'),
                ),
              ],
            ),
            if (school.category == 'Pilot private')
              DropdownButtonFormField<String>(
                isExpanded: true,
                initialValue: choice.pilotCategory,
                decoration: const InputDecoration(
                  labelText: 'Pilot private selection group',
                ),
                items: ['Category B', 'Category C']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (c) => setState(() => choice.pilotCategory = c!),
              ),
            if (choice.residence == 'Day') ...[
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.catchmentConfirmed,
                onChanged: (v) =>
                    setState(() => choice.catchmentConfirmed = v!),
                title: const Text(
                  'My JHS or the school office confirmed that I can select this Day option.',
                ),
                subtitle: const Text(
                  'Your confirmation only; Skool Atlas has not verified official catchment boundaries.',
                ),
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.commuteConfirmed,
                onChanged: (v) => setState(() => choice.commuteConfirmed = v!),
                title: const Text(
                  'My guardian and I checked that I can realistically attend this Day school daily.',
                ),
                subtitle: const Text(
                  'Confirm catchment with your JHS; the app has not measured travel distance.',
                ),
              ),
              TextButton.icon(
                onPressed: () => openLink(
                  context,
                  Uri.https('www.google.com', '/maps/dir/', {
                    'api': '1',
                    'origin': '${town.text}${district.isEmpty ? '' : ', $district'}, $region, Ghana',
                    'destination': '${school.name}, ${school.location}',
                  }),
                ),
                icon: const Icon(Icons.directions_outlined),
                label: const Text('Check the journey from my town'),
              ),
              const ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text('Check the practical daily journey'),
                children: [
                  Padding(
                    padding: EdgeInsets.only(bottom: 12),
                    child: Text(
                      'Check the exact campus and a normal school-morning route. Review journey time in both directions, changes of transport, return fares, arrival time, road safety and rainy-day alternatives with your guardian. A map estimate is not an official catchment decision. Do not share your exact home address in pilot feedback.',
                    ),
                  ),
                ],
              ),
            ],
            if (school.data['registerCodeConflict'] == true)
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: choice.codeConfirmed,
                onChanged: (v) => setState(() => choice.codeConfirmed = v!),
                title: const Text(
                  'I confirmed the exact school code with my JHS / the school office.',
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class OfficialSelectionSummary extends StatelessWidget {
  final bool compact;
  const OfficialSelectionSummary({super.key, this.compact = false});
  @override
  Widget build(BuildContext context) => compact
      ? Surface(
          padding: const EdgeInsets.all(8),
          child: ExpansionTile(
            leading: Icon(
              Icons.fact_check_outlined,
              color: context.atlas.primary,
            ),
            title: const Text(
              'Before you build your eight choices',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: const Text(
                'Quick rules for your eight choices.',
            ),
            childrenPadding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            children: const [OfficialSelectionSummary()],
          ),
        )
      : Surface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Keep the rules simple',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: context.atlas.primaryDark,
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: const [
                  TagChip(label: '8 schools'),
                  TagChip(label: 'Max 2 in A'),
                  TagChip(label: 'Max 3 in B'),
                  TagChip(label: 'Max 5 Boarding'),
                  TagChip(label: 'All 8 may be Day'),
                  TagChip(label: 'All 8 may be C'),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Your grades do not set a category quota. Suggestions are not a promise of admission. Check the programme and vacancy on CSSPS with your JHS.',
                style: TextStyle(color: context.atlas.muted, height: 1.45),
              ),
              const SizedBox(height: 6),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Extra limits and source notes'),
                children: [
                  const Padding(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Text(
                      'Category A allows at most one Boarding choice; Category B allows at most two. Day is a residence option within A, B or C, not a separate category. Confirm current rules and exact eligibility before submitting.',
                    ),
                  ),
                  Text(
                    'The 2026 printed register and current CSSPS manual differ on the Day/Boarding mix. The planner follows the current manual and labels all vacancy guidance for confirmation.',
                    style: TextStyle(color: context.atlas.muted, height: 1.45),
                  ),
                ],
              ),
              BalancedActions(
                children: [
                  TextButton.icon(
                    onPressed: () =>
                        openLink(context, Uri.parse(selectionManualUrl)),
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Official CSSPS selection rules'),
                  ),
                  TextButton(
                    onPressed: () => openLink(
                      context,
                      Uri.parse('https://waecgh.org/home/bece-school/'),
                    ),
                    child: const Text('WAEC grading explained'),
                  ),
                  TextButton(
                    onPressed: () => openLink(
                      context,
                      Uri.parse('https://www.cssps.gov.gh/vacancies'),
                    ),
                    child: const Text('Official vacancy directory'),
                  ),
                ],
              ),
              Text(
                'CSSPS manual rechecked 21 October 2026. Confirm the current instructions with your JHS before official submission.',
                style: TextStyle(fontSize: 12, color: context.atlas.muted),
              ),
            ],
          ),
        );
}

class SelectionRulesPanel extends StatelessWidget {
  const SelectionRulesPanel({super.key});
  @override
  Widget build(BuildContext context) => Surface(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'School-selection requirements',
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.w800,
            color: context.atlas.primaryDark,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'CSSPS manual checked 21 October 2026. Confirm current rules with your JHS.',
          style: TextStyle(color: context.atlas.muted, height: 1.45),
        ),
        const SizedBox(height: 16),
        for (final item in [
          ('1', 'Choose 8 different schools', 'Rank them in your real preference order.'),
          ('2', 'Check category limits', 'Max 2 in A, max 3 in B. All 8 may be C.'),
          ('3', 'Check residence', 'Max 5 Boarding; max 1 A and 2 B Boarding. All 8 may be Day.'),
          ('4', 'Check nearby Day schools', 'Ask your JHS about catchment. Check safe daily travel with your guardian.'),
          ('5', 'Check each school', 'Confirm the school, code, programme and vacancy on CSSPS.'),
          ('6', 'Review before sending', 'Go through all 8 with your guardian and JHS teacher.'),
        ])
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundColor: context.atlas.primarySoft,
              child: Text(item.$1, style: TextStyle(color: context.atlas.primary, fontWeight: FontWeight.w800)),
            ),
            title: Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(item.$3),
          ),
        Text(
          'Your grades do not create a category quota. The app suggests options; CSSPS decides placement from current vacancies and your candidate record.',
          style: TextStyle(color: context.atlas.muted, height: 1.45),
        ),
        const ExpansionTile(
          tilePadding: EdgeInsets.zero,
          title: Text('More about tracks and source differences'),
          children: [
            Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text(
                'The printed 2026 register and current CSSPS manual differ on the Day/Boarding mix; the planner follows the current manual. The sourced register lists pilot private schools as Category B/C Day options. It describes all-TVET choices for a TVET-only track and Science/STEM programmes for a Science/STEM track. Confirm specialist combinations and the latest live instructions before submitting.',
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        BalancedActions(
          children: [
            FilledButton(
              onPressed: () =>
                  openLink(context, Uri.parse('https://www.cssps.gov.gh/')),
              child: const Text('Open official CSSPS portal'),
            ),
            TextButton(
              onPressed: () => openLink(context, Uri.parse(selectionManualUrl)),
              child: const Text('Current CSSPS candidate manual'),
            ),
            TextButton(
              onPressed: () =>
                  openLink(context, Uri.parse(selectionRegisterUrl)),
              child: const Text('Sourced 2026 selection register'),
            ),
            TextButton(
              onPressed: () => openLink(
                context,
                Uri.parse(
                  'https://gna.org.gh/2026/09/ges-defends-post-bece-shs-selection-amid-placement-concerns/',
                ),
              ),
              child: const Text('GES post-results selection report'),
            ),
            TextButton(
              onPressed: () => openLink(
                context,
                Uri.parse(
                  'https://gna.org.gh/2026/09/bece-candidates-with-grade-nine-in-english-maths-eligible-for-self-placement/',
                ),
              ),
              child: const Text('2026 Grade 9 / self-placement report'),
            ),
          ],
        ),
      ],
    ),
  );
}
