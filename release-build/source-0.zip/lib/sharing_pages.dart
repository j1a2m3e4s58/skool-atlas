part of 'main.dart';

class PublishDraftPage extends StatefulWidget {
  final List<SchoolChoice> choices;
  const PublishDraftPage({super.key, required this.choices});
  @override
  State<PublishDraftPage> createState() => _PublishDraftPageState();
}

class _PublishDraftPageState extends State<PublishDraftPage> {
  bool busy = false;
  String? error, viewLink, reviewLink;
  Future<void> publish() async {
    setState(() => busy = true);
    try {
      final result = await accounts.request(
        '/shares',
        method: 'POST',
        data: {
          'title': 'Our ordered school choices',
          'days': 30,
          'choices': widget.choices
              .map(
                (c) => {
                  'schoolId': c.schoolId,
                  'programme': c.programme,
                  'residence': c.residence,
                },
              )
              .toList(),
        },
      );
      final base = Uri.tryParse(
        '${accounts.config['publicAppUrl'] ?? accounts.baseUrl}',
      );
      if (base == null) throw Exception('App address is unavailable.');
      String link(bool review) => base
          .replace(
            path: '/',
            queryParameters: {'plan': '${result['id']}'},
            fragment: Uri(
              queryParameters: {
                'access': '${result['access']}',
                if (review) 'review': '${result['review']}',
              },
            ).query,
          )
          .toString();
      viewLink = link(false);
      reviewLink = link(true);
    } catch (e) {
      error = '$e';
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: accounts,
    builder: (context, _) => PageFrame(
      maxWidth: 900,
      title: 'Discuss your ordered choices',
      subtitle:
          'Share an expiring draft with your family or guidance teacher. Your grades, email and home location are excluded.',
      children: [
        const InfoPanel(
          title: 'Unverified planning draft',
          text:
              'An invitation shares your proposed order, not approved choices. Review school codes, current programmes, residence and all Day/catchment requirements with your JHS before official submission.',
        ),
        const InfoPanel(
          title: 'Private invitation links',
          text:
              'Anyone with a view link can read this draft. A review link also allows comments. Send links only to people you trust. Links expire after 30 days and can be revoked from Account & sync.',
        ),
        if (Uri.tryParse(accounts.baseUrl)?.host == '127.0.0.1' ||
            Uri.tryParse(accounts.baseUrl)?.host == 'localhost')
          const InfoPanel(
            title: 'Local preview',
            text:
                'These links work only on this computer until the app is hosted. For another device, use the offline file instead.',
          ),
        for (final entry in widget.choices.asMap().entries)
          ListTile(
            leading: CircleAvatar(child: Text('${entry.key + 1}')),
            title: Text(entry.value.school?.name ?? entry.value.schoolId),
            subtitle: Text(
              '${entry.value.programme} · ${entry.value.residence}',
            ),
          ),
        if (error != null) InfoPanel(title: 'Could not share', text: error!),
        if (!accounts.signedIn)
          FilledButton(
            onPressed: () => openPlanningTool(
              context,
              const AccountPage(),
              'Account & sync',
            ),
            child: const Text('Sign in to create an invitation'),
          ),
        if (accounts.signedIn && viewLink == null)
          FilledButton.icon(
            onPressed: busy ? null : publish,
            icon: const Icon(Icons.link),
            label: Text(busy ? 'Creating…' : 'Create 30-day invitation'),
          ),
        if (viewLink != null)
          Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Invitation created',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 21),
                ),
                const SizedBox(height: 12),
                for (final entry in {
                  'Copy view-only link': viewLink!,
                  'Copy family / teacher review link': reviewLink!,
                }.entries)
                  TextButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: entry.value));
                      if (context.mounted) toast(context, 'Invitation copied.');
                    },
                    icon: const Icon(Icons.copy),
                    label: Text(entry.key),
                  ),
                TextButton(
                  onPressed: () => openPlanningTool(
                    context,
                    SharedOnlinePlanPage(
                      id: Uri.parse(viewLink!).queryParameters['plan']!,
                      access: Uri.splitQueryString(
                        Uri.parse(viewLink!).fragment,
                      )['access']!,
                      review: Uri.splitQueryString(
                        Uri.parse(reviewLink!).fragment,
                      )['review'],
                    ),
                    'Shared school draft',
                  ),
                  child: const Text('Preview shared draft'),
                ),
              ],
            ),
          ),
      ],
    ),
  );
}

class SharedOnlinePlanPage extends StatefulWidget {
  final String id, access;
  final String? review;
  const SharedOnlinePlanPage({
    super.key,
    required this.id,
    required this.access,
    this.review,
  });
  @override
  State<SharedOnlinePlanPage> createState() => _SharedOnlinePlanPageState();
}

class _SharedOnlinePlanPageState extends State<SharedOnlinePlanPage> {
  final comment = TextEditingController();
  late Future<Map<String, dynamic>> data = load();
  String? error;
  bool busy = false;
  Map<String, String> get headers => {
    'X-Share-Token': widget.access,
    if (widget.review != null) 'X-Review-Token': widget.review!,
  };
  Future<Map<String, dynamic>> load() => accounts.request(
    '/shares/${Uri.encodeComponent(widget.id)}',
    extraHeaders: headers,
  );
  @override
  void dispose() {
    comment.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    setState(() => busy = true);
    try {
      await accounts.request(
        '/shares/${Uri.encodeComponent(widget.id)}/comments',
        method: 'POST',
        data: {'text': comment.text},
        extraHeaders: headers,
      );
      comment.clear();
      data = load();
      error = null;
    } catch (e) {
      error = '$e';
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
    future: data,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return PageFrame(
        maxWidth: 900,
          title: 'Shared draft unavailable',
          subtitle:
              'It may have expired, been revoked or the invitation key is missing.',
          children: [
            InfoPanel(title: 'Connection', text: '${snapshot.error}'),
            OutlinedButton(
              onPressed: () => setState(() => data = load()),
              child: const Text('Try again'),
            ),
          ],
        );
      }
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }
      final row = snapshot.data!, payload = row['payload'] as Map;
      final choices = (payload['choices'] as List)
          .map((c) => SchoolChoice.fromJson(c))
          .toList();
      return PageFrame(
        maxWidth: 900,
        title: '${payload['title']}',
        subtitle:
            'Ordered draft for discussion; not an official selection or a placement guarantee. Expires ${DateTime.fromMillisecondsSinceEpoch((row['expiresAt'] as num).toInt() * 1000).toLocal().toString().split(' ').first}.',
        children: [
          for (final entry in choices.asMap().entries)
            Surface(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(child: Text('${entry.key + 1}')),
                title: Text(entry.value.school?.name ?? entry.value.schoolId),
                subtitle: Text(
                  '${entry.value.programme} · ${entry.value.residence}',
                ),
                onTap: entry.value.school == null
                    ? null
                    : () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) =>
                              SchoolDetailsPage(school: entry.value.school!),
                        ),
                      ),
              ),
            ),
          ExportChoiceActions(
            selected: choices.map((c) => c.school).whereType<School>().toList(),
            choices: choices,
          ),
          const SizedBox(height: 20),
          const Text(
            'Family & teacher comments',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
          ),
          const Text(
            'Comments are advice from invited people; reviewer identity is not independently verified. Keep personal and student information out of comments.',
          ),
          for (final c in row['comments'] as List)
            ListTile(
              leading: const Icon(Icons.chat_bubble_outline),
              title: Text('${c['text']}'),
              subtitle: Text('${c['created_at']}'.split('T').first),
            ),
          if (error != null) Text(error!),
          if (widget.review != null) ...[
            TextField(
              controller: comment,
              minLines: 2,
              maxLines: 5,
              maxLength: 1000,
              decoration: const InputDecoration(
                labelText: 'Add a discussion comment',
              ),
            ),
            FilledButton(
              onPressed: busy ? null : submit,
              child: Text(busy ? 'Saving…' : 'Add comment'),
            ),
          ] else
            const Text(
              'This invitation is view-only. Ask the owner for a review link to comment.',
            ),
        ],
      );
    },
  );
}

class AccountActivityPanel extends StatefulWidget {
  const AccountActivityPanel({super.key});
  @override
  State<AccountActivityPanel> createState() => _AccountActivityPanelState();
}

class _AccountActivityPanelState extends State<AccountActivityPanel> {
  late Future<List<Map<String, dynamic>>> activity = load();
  Future<List<Map<String, dynamic>>> load() async => await Future.wait([
    accounts.request('/notifications'),
    accounts.request('/claims'),
    accounts.request('/support'),
  ]);
  @override
  Widget build(BuildContext context) =>
      FutureBuilder<List<Map<String, dynamic>>>(
        future: activity,
        builder: (context, s) {
          if (s.hasError) {
            return InfoPanel(title: 'Activity unavailable', text: '${s.error}');
          }
          if (!s.hasData) return const LinearProgressIndicator();
          return Surface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Updates & support',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Refresh activity',
                      onPressed: () => setState(() => activity = load()),
                      icon: const Icon(Icons.refresh),
                    ),
                  ],
                ),
                for (final n in s.data![0]['notifications'] as List)
                  ListTile(
                    title: Text('${n['title']}'),
                    subtitle: Text('${n['detail']}'),
                  ),
                for (final c in s.data![1]['claims'] as List)
                  ListTile(
                    title: Text('School access · ${c['state']}'),
                    subtitle: Text('${c['review_note'] ?? c['note']}'),
                  ),
                for (final t in s.data![2]['tickets'] as List)
                  ListTile(
                    title: Text('${t['topic']} · ${t['state']}'),
                    subtitle: Text('${t['response'] ?? 'Awaiting a response'}'),
                  ),
              ],
            ),
          );
        },
      );
}
