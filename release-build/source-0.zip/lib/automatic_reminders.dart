export 'automatic_reminders_stub.dart'
    if (dart.library.js_interop) 'automatic_reminders_web.dart';
