import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'tertiary_data.dart';

List<Map<String, dynamic>> galleryPhotos(TertiaryStore store, String id) {
  final m = store.media[id] as Map?;
  if (m == null) return [];
  final seen = <String>{};
  return [
    for (final p in [if (m['asset'] is String) m, ...?m['gallery'] as List?])
      if (p is Map &&
          p['asset'] is String &&
          seen.add('${p['sha256'] ?? p['asset']}'))
        Map<String, dynamic>.from(p),
  ];
}

class InstitutionGallery extends StatefulWidget {
  final TertiaryStore store;
  final TertiaryInstitution institution;
  const InstitutionGallery({
    super.key,
    required this.store,
    required this.institution,
  });
  @override
  State<InstitutionGallery> createState() => _InstitutionGalleryState();
}

class _InstitutionGalleryState extends State<InstitutionGallery> {
  int index = 0;
  final pages = PageController();
  @override
  void dispose() {
    pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final photos = galleryPhotos(widget.store, widget.institution.id);
    if (photos.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFFE7ECE6),
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Row(
          children: [
            Icon(Icons.photo_library_outlined),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Verified campus gallery not available yet. No substitute school photograph is used.',
              ),
            ),
          ],
        ),
      );
    }
    final photo = photos[index.clamp(0, photos.length - 1)];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 235,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: PageView.builder(
              controller: pages,
              itemCount: photos.length,
              onPageChanged: (v) => setState(() => index = v),
              itemBuilder: (context, n) => GestureDetector(
                onTap: () => fullscreen(photos, n),
                child: Image.asset(
                  photos[n]['asset'],
                  fit: BoxFit.contain,
                  semanticLabel:
                      '${widget.institution.name}: ${photos[n]['caption']}',
                  errorBuilder: (_, error, stack) => const Center(
                    child: Text('This offline photograph could not load.'),
                  ),
                ),
              ),
            ),
          ),
        ),
        Row(
          children: [
            IconButton(
              tooltip: 'Previous photograph',
              onPressed: index > 0
                  ? () => pages.previousPage(
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut,
                    )
                  : null,
              icon: const Icon(Icons.chevron_left),
            ),
            Expanded(
              child: Text(
                '${index + 1} / ${photos.length} · tap to zoom',
                textAlign: TextAlign.center,
              ),
            ),
            IconButton(
              tooltip: 'Next photograph',
              onPressed: index < photos.length - 1
                  ? () => pages.nextPage(
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut,
                    )
                  : null,
              icon: const Icon(Icons.chevron_right),
            ),
          ],
        ),
        if (photos.length > 1)
          SizedBox(
            height: 62,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: photos.length,
              separatorBuilder: (_, n) => const SizedBox(width: 8),
              itemBuilder: (ctx, n) => Semantics(
                button: true,
                selected: n == index,
                label: 'Show photograph ${n + 1}',
                child: InkWell(
                  onTap: () => pages.animateToPage(
                    n,
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOut,
                  ),
                  child: Container(
                    width: 82,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: n == index
                            ? const Color(0xFF173F3B)
                            : Colors.transparent,
                        width: 3,
                      ),
                    ),
                    child: Image.asset(photos[n]['asset'], fit: BoxFit.cover),
                  ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 12),
        Text(
          '${photo['caption'] ?? 'Institution photograph'}',
          style: const TextStyle(fontSize: 13, height: 1.6),
        ),
        if (photo['credit'] != null)
          Text(
            'Photo: ${photo['credit']} · ${photo['license'] ?? ''}',
            style: const TextStyle(fontSize: 12),
          ),
        Text(
          'Source checked ${photo['checkedAt'] ?? 'Not recorded'} · photograph date may differ',
          style: const TextStyle(fontSize: 11),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            if ('${photo['sourceUrl']}'.endsWith('.mp4'))
              TextButton.icon(
                onPressed: () => openSource(photo['sourceUrl']),
                icon: const Icon(Icons.play_circle_outline),
                label: const Text('Official campus film · online'),
              ),
            TextButton(
              onPressed: () =>
                  openSource('${photo['pageUrl'] ?? photo['sourceUrl']}'),
              child: const Text('Photo source'),
            ),
            if (photo['licenseUrl'] != null)
              TextButton(
                onPressed: () => openSource(photo['licenseUrl']),
                child: const Text('Licence'),
              ),
          ],
        ),
      ],
    );
  }

  Future<void> openSource(String url) async {
    final uri = Uri.tryParse(url);
    if (uri?.scheme == 'https') {
      final opened = await launchUrl(
        uri!,
        mode: LaunchMode.externalApplication,
      );
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Unable to open the source. Internet may be required.',
            ),
          ),
        );
      }
    }
  }

  void fullscreen(List<Map<String, dynamic>> photos, int initial) {
    final controller = PageController(initialPage: initial);
    showDialog<void>(
      context: context,
      useSafeArea: true,
      builder: (ctx) => Dialog.fullscreen(
        backgroundColor: const Color(0xFF102623),
        child: SafeArea(
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: 'Close gallery',
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                  Expanded(
                    child: Text(
                      widget.institution.name,
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Previous full-screen photograph',
                    onPressed: () => controller.previousPage(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeOut,
                    ),
                    icon: const Icon(Icons.chevron_left, color: Colors.white),
                  ),
                  IconButton(
                    tooltip: 'Next full-screen photograph',
                    onPressed: () => controller.nextPage(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeOut,
                    ),
                    icon: const Icon(Icons.chevron_right, color: Colors.white),
                  ),
                ],
              ),
              Expanded(
                child: PageView.builder(
                  controller: controller,
                  itemCount: photos.length,
                  itemBuilder: (ctx, n) => Column(
                    children: [
                      Expanded(
                        child: InteractiveViewer(
                          minScale: 1,
                          maxScale: 5,
                          child: Center(
                            child: Image.asset(
                              photos[n]['asset'],
                              fit: BoxFit.contain,
                              semanticLabel:
                                  '${widget.institution.name}: ${photos[n]['caption']}',
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          '${n + 1} / ${photos.length} · ${photos[n]['caption']}\nPinch or double-finger scroll to zoom',
                          style: const TextStyle(color: Colors.white),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ).whenComplete(controller.dispose);
  }
}
