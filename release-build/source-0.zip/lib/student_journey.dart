import 'dart:convert';
import 'dart:async';
import 'automatic_reminders.dart';
import 'package:shared_preferences/shared_preferences.dart';

const applicationStages = [
  'Researching',
  'Preparing',
  'Submitted',
  'Offer received',
  'Accepted',
  'Closed',
];
const applicationTasks = [
  'Check official programme requirements',
  'Prepare identity document',
  'Prepare examination results / transcript',
  'Check required supporting documents',
  'Confirm official payment instructions',
  'Submit through the official portal',
];
const budgetCategories = [
  'Tuition',
  'Accommodation',
  'Food & books',
  'Transport',
  'Application & other fees',
];

String programmeIdentity(String value) =>
    value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

class ApplicationPlan {
  final String id, institutionId, programme;
  String stage, note, period;
  String? targetDate;
  bool reminder;
  Set<String> completed;
  Map<String, double> budget;
  ApplicationPlan({
    required this.id,
    required this.institutionId,
    required this.programme,
    this.stage = 'Researching',
    this.note = '',
    this.period = 'One academic year',
    this.targetDate,
    this.reminder = false,
    Set<String>? completed,
    Map<String, double>? budget,
  }) : completed = completed ?? {},
       budget = budget ?? {};
  factory ApplicationPlan.fromJson(Map<String, dynamic> r) => ApplicationPlan(
    id: r['id'],
    institutionId: r['institutionId'],
    programme: r['programme'],
    stage: applicationStages.contains(r['stage']) ? r['stage'] : 'Researching',
    note: r['note'] ?? '',
    period: r['period'] ?? 'One academic year',
    targetDate: r['targetDate'],
    reminder: r['reminder'] == true,
    completed: Set<String>.from(r['completed'] ?? []),
    budget: {
      for (final e in (r['budget'] as Map? ?? {}).entries)
        e.key as String: (e.value as num).toDouble(),
    },
  );
  Map<String, dynamic> toJson() => {
    'id': id,
    'institutionId': institutionId,
    'programme': programme,
    'stage': stage,
    'note': note,
    'period': period,
    'targetDate': targetDate,
    'reminder': reminder,
    'completed': completed.toList(),
    'budget': budget,
  };
  double get subtotal => budget.values.fold(0, (a, b) => a + b);
  bool get budgetComplete => budgetCategories.every(budget.containsKey);
}

String canonicalJson(dynamic value) {
  if (value is Map) {
    final keys = value.keys.map((k) => k.toString()).toList()..sort();
    return '{${keys.map((k) => '${jsonEncode(k)}:${canonicalJson(value[k])}').join(',')}}';
  }
  if (value is List) return '[${value.map(canonicalJson).join(',')}]';
  return jsonEncode(value);
}

class StudentJourney {
  static const preferenceKey = 'tertiary.journey.v1';
  List<ApplicationPlan> applications = [];
  List<String> comparison = [];
  List<Map<String, dynamic>> updates = [];
  Map<String, dynamic> resources = {
    'fees': [],
    'deadlines': [],
    'scholarships': [],
  };
  Map<String, dynamic> baseline = {};
  bool followChanges = false;
  String? storageError;

  Future<void> load(Map<String, dynamic> bundled) async {
    validateResources(bundled);
    resources = bundled;
    final raw = (await SharedPreferences.getInstance()).getString(
      preferenceKey,
    );
    if (raw == null) return;
    try {
      final r = jsonDecode(raw) as Map;
      applications = [
        for (final a in r['applications'] ?? [])
          ApplicationPlan.fromJson(Map<String, dynamic>.from(a)),
      ];
      comparison = List<String>.from(r['comparison'] ?? []).take(4).toList();
      updates = [
        for (final u in r['updates'] ?? []) Map<String, dynamic>.from(u),
      ];
      baseline = Map<String, dynamic>.from(r['baseline'] ?? {});
      followChanges = r['followChanges'] == true;
    } catch (_) {
      // Preserve the unreadable value for recovery rather than overwriting it.
      storageError =
          'Your saved journey could not be read. Export device data before resetting browser storage.';
    }
  }

  static void validateResources(Map<String, dynamic> r) {
    if (r['schemaVersion'] != 1) {
      throw const FormatException('Unsupported student resources');
    }
    final ids = <String>{};
    for (final section in ['fees', 'deadlines', 'scholarships']) {
      if (r[section] is! List) {
        throw const FormatException('Missing resource section');
      }
      for (final row in r[section]) {
        if (row is! Map ||
            row['id'] is! String ||
            !ids.add(row['id']) ||
            row['institutionId'] is! String ||
            row['title'] is! String ||
            Uri.tryParse('${row['sourceUrl']}')?.scheme != 'https' ||
            DateTime.tryParse('${row['checkedAt']}') == null ||
            row['cycle'] is! String) {
          throw const FormatException('Invalid official resource');
        }
        if (row['date'] != null && DateTime.tryParse(row['date']) == null) {
          throw const FormatException('Invalid resource deadline');
        }
        if (row['availability'] != null && row['availability'] != 'closed') {
          throw const FormatException('Invalid explicit resource availability');
        }
        if (section == 'fees' &&
            (row['amount'] is! num ||
                row['amount'] < 0 ||
                !['GHS', 'USD'].contains(row['currency']) ||
                row['period'] is! String)) {
          throw const FormatException('Invalid fee');
        }
      }
    }
  }

  Future<void> persist() async {
    if (storageError != null) throw StateError(storageError!);
    final ok = await (await SharedPreferences.getInstance()).setString(
      preferenceKey,
      jsonEncode({
        'applications': applications.map((a) => a.toJson()).toList(),
        'comparison': comparison,
        'updates': updates,
        'baseline': baseline,
        'followChanges': followChanges,
      }),
    );
    if (!ok) {
      throw StateError('Device storage is full. Changes could not be saved.');
    }
    unawaited(
      syncAutomaticReminders(
        reminderPayload(),
      ).then<void>((_) {}, onError: (Object error, StackTrace stack) {}),
    );
  }

  String reminderPayload() {
    final today = DateTime.now().toUtc().toIso8601String().substring(0, 10);
    return jsonEncode([
      for (final a in applications)
        if (a.reminder &&
            a.targetDate != null &&
            a.targetDate!.compareTo(today) >= 0 &&
            DateTime.parse(
                  a.targetDate!,
                ).difference(DateTime.now().toUtc()).inDays <=
                370)
          {'id': a.id, 'date': a.targetDate},
    ]);
  }

  Future<ApplicationPlan> track(String institutionId, String programme) async {
    final existing = applications
        .where(
          (a) =>
              a.institutionId == institutionId &&
              programmeIdentity(a.programme) == programmeIdentity(programme),
        )
        .firstOrNull;
    if (existing != null) return existing;
    final a = ApplicationPlan(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      institutionId: institutionId,
      programme: programme,
    );
    applications.add(a);
    try {
      await persist();
    } catch (_) {
      applications.remove(a);
      rethrow;
    }
    return a;
  }

  Future<void> compare(String id) async {
    final before = [...comparison];
    if (comparison.contains(id)) {
      comparison.remove(id);
    } else {
      if (comparison.length == 4) {
        throw StateError('Compare up to four programmes. Remove one first.');
      }
      comparison.add(id);
    }
    try {
      await persist();
    } catch (_) {
      comparison = before;
      rethrow;
    }
  }

  /// Call only after a fully validated feed. Timestamp-only refreshes are quiet.
  Future<void> observe(
    Map<String, Map<String, dynamic>> snapshot,
    Set<String> followed, {
    DateTime? now,
  }) async {
    if (storageError != null) return;
    // Retain reproducible change evidence only for followed institutions. The
    // full national directory already lives in the independently cached feed.
    snapshot = {
      for (final entry in snapshot.entries)
        if (followed.contains(entry.value['institutionId']))
          entry.key: entry.value,
    };
    for (final e in snapshot.entries) {
      final old = baseline[e.key];
      final current = e.value;
      if (followChanges &&
          baseline.values.any(
            (row) =>
                row is Map && row['institutionId'] == current['institutionId'],
          ) &&
          old == null &&
          followed.contains(current['institutionId'])) {
        updates.insert(0, {
          'key': e.key,
          'institutionId': current['institutionId'],
          'title': current['title'],
          'sourceUrl': current['sourceUrl'],
          'observedAt': (now ?? DateTime.now()).toIso8601String(),
          'changes': [
            {'field': 'New published record', 'before': null, 'after': current},
          ],
          'read': false,
        });
      }
      if (followChanges &&
          followed.contains(current['institutionId']) &&
          old is Map) {
        final fields = {
          ...old.keys,
          ...current.keys,
        }.where((k) => !['institutionId', 'title', 'sourceUrl'].contains(k));
        final changes = [
          for (final field in fields)
            if (canonicalJson(old[field]) != canonicalJson(current[field]))
              {
                'field': '$field',
                'before': old[field],
                'after': current[field],
              },
        ];
        if (changes.isNotEmpty) {
          updates.insert(0, {
            'key': e.key,
            'institutionId': current['institutionId'],
            'title': current['title'],
            'sourceUrl': current['sourceUrl'],
            'observedAt': (now ?? DateTime.now()).toIso8601String(),
            'changes': changes,
            'read': false,
          });
        }
      }
    }
    if (followChanges) {
      for (final e in baseline.entries) {
        final old = e.value;
        if (!snapshot.containsKey(e.key) &&
            old is Map &&
            followed.contains(old['institutionId'])) {
          updates.insert(0, {
            'key': e.key,
            'institutionId': old['institutionId'],
            'title': old['title'],
            'sourceUrl': old['sourceUrl'],
            'observedAt': (now ?? DateTime.now()).toIso8601String(),
            'changes': [
              {
                'field': 'Record availability',
                'before': 'Previously published',
                'after':
                    'Not present in latest feed. Confirm directly; this is not a revocation decision.',
              },
            ],
            'read': false,
          });
        }
      }
    }
    baseline = snapshot;
    if (updates.length > 100) updates = updates.take(100).toList();
    await persist();
  }
}

String resourceDeadlineState(Map row, {DateTime? now}) =>
    row['availability'] == 'closed'
    ? 'Closed by official source'
    : deadlineState(row['date'] as String?, now: now);

bool resourceIsClosed(Map row, {DateTime? now}) =>
    row['availability'] == 'closed' ||
    deadlineState(row['date'] as String?, now: now) == 'Closed / date passed';

String deadlineState(String? date, {DateTime? now}) {
  if (date == null) return 'Date not confirmed';
  final d = DateTime.tryParse(date);
  if (d == null) return 'Date not confirmed';
  final clock = now ?? DateTime.now();
  final today = DateTime(clock.year, clock.month, clock.day);
  final day = DateTime(d.year, d.month, d.day);
  if (day.isBefore(today)) return 'Closed / date passed';
  if (day == today) return 'Due today';
  return '${day.difference(today).inDays} days remaining';
}

String calendarReminder(
  ApplicationPlan a,
  String institution, {
  DateTime? now,
}) {
  final date = DateTime.tryParse(a.targetDate ?? '');
  if (date == null || !a.reminder) {
    throw StateError(
      'Choose a target date and enable a calendar reminder first.',
    );
  }
  String escape(String s) => s
      .replaceAll('\\', '\\\\')
      .replaceAll('\n', r'\n')
      .replaceAll(';', r'\;')
      .replaceAll(',', r'\,')
      .replaceAll('\r', '');
  String day(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
  final utc = (now ?? DateTime.now()).toUtc();
  final stamp =
      '${day(utc)}T${utc.hour.toString().padLeft(2, '0')}${utc.minute.toString().padLeft(2, '0')}${utc.second.toString().padLeft(2, '0')}Z';
  final lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Tertiary Atlas//Application planner//EN',
    'BEGIN:VEVENT',
    'UID:${a.id}@tertiary-atlas.local',
    'DTSTAMP:$stamp',
    'DTSTART;VALUE=DATE:${day(date)}',
    'DTEND;VALUE=DATE:${day(date.add(const Duration(days: 1)))}',
    'SUMMARY:${escape('Application target: $institution')}',
    'DESCRIPTION:${escape('${a.programme}\nPersonal target date; verify the official deadline.\n${a.note}')}',
    'BEGIN:VALARM',
    'TRIGGER:-P1D',
    'ACTION:DISPLAY',
    'DESCRIPTION:Application target tomorrow',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  // RFC 5545 folds at 75 octets, preserving UTF-8 characters.
  final folded = <String>[];
  for (final line in lines) {
    var part = '';
    var bytes = 0;
    for (final rune in line.runes) {
      final char = String.fromCharCode(rune);
      final count = utf8.encode(char).length;
      if (bytes + count > 75) {
        folded.add(part);
        part = ' ';
        bytes = 1;
      }
      part += char;
      bytes += count;
    }
    folded.add(part);
  }
  return '${folded.join('\r\n')}\r\n';
}
