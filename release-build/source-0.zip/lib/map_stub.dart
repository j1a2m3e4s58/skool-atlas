import 'package:flutter/material.dart';

class SchoolMap extends StatelessWidget {
  final String query;
  const SchoolMap({super.key, required this.query});
  @override
  Widget build(BuildContext context) => const SizedBox(
    height: 120,
    child: Center(
      child: Text(
        'Use Open map & directions to view this school on your device.',
      ),
    ),
  );
}
