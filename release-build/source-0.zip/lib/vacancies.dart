import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'accounts.dart';

final officialVacancies = OfficialVacancies();

class OfficialVacancies extends ChangeNotifier {
  Future<Map<String, dynamic>> Function() fetchSnapshot =
      () => accounts.request('/catalogue/vacancies');
  Map<String, dynamic> data = {};
  String? error;
  bool busy = false;
  DateTime? get fetchedAt => DateTime.tryParse('${data['fetchedAt']}');
  bool freshAt(DateTime now) {
    final at = fetchedAt;
    if (at == null) return false;
    final age = now.toUtc().difference(at.toUtc());
    return age >= const Duration(minutes: -5) && age <= const Duration(hours: 2);
  }
  bool get fresh => freshAt(DateTime.now()) && error == null;
  Map? school(String id) => (data['schools'] as Map?)?[id] as Map?;
  int programmeCount(String id, String programme) {
    final rows = school(id)?['programmes'] as List? ?? [];
    return rows.where((p) => p['name'] == programme)
      .fold<int>(0, (sum, p) => sum + (p['vacancies'] as num).toInt());
  }
  int residenceCount(String id, String residence, String gender) {
    if (!['Male', 'Female'].contains(gender)) return 0;
    final rows = (school(id)?['residences'] as List? ?? [])
      .where((r) => r['name'] == residence).toList();
    final specific = rows.where((r) => r['gender'] == gender).toList();
    final eligible = specific.isNotEmpty ? specific : rows.where((r) =>
      r['gender'] == null || r['gender'] == 'Mixed');
    return eligible.fold<int>(0, (sum, r) => sum + (r['vacancies'] as num).toInt());
  }
  bool available(String id, String programme, String residence, String gender) =>
    fresh && programmeCount(id, programme) > 0 && residenceCount(id, residence, gender) > 0;
  String describe(String id, String programme, String residence, String gender) {
    if (!fresh) return 'Current vacancies are unconfirmed: refresh online and check CSSPS. Cached or old figures cannot establish availability.';
    if (school(id) == null) return 'No safely matched official vacancy record. Absence does not mean this school is closed.';
    return 'Official snapshot: ${programmeCount(id, programme)} $programme spaces; ${residenceCount(id, residence, gender)} $residence spaces for the selected gender. Checked ${fetchedAt!.toUtc().toIso8601String()}. Counts are separate, not a confirmed programme/residence combination or reserved place.';
  }
  Future<void> refresh() async {
    if (busy) return;
    busy = true;
    notifyListeners();
    try {
      if (data.isEmpty) {
        final cache = (await SharedPreferences.getInstance()).getString('atlas.vacancies.v1');
        if (cache != null) data = Map<String, dynamic>.from(jsonDecode(cache));
      }
      final result = await fetchSnapshot();
      if (result['source'] != 'https://www.cssps.gov.gh/vacancies' ||
          result['schools'] is! Map || DateTime.tryParse('${result['fetchedAt']}') == null) {
        throw const FormatException('Invalid vacancy snapshot');
      }
      data = result;
      error = null;
      await (await SharedPreferences.getInstance()).setString('atlas.vacancies.v1', jsonEncode(data));
    } catch (_) {
      error = 'Official vacancy refresh unavailable. Check CSSPS directly; saved counts are not current confirmation.';
    } finally {
      busy = false;
      notifyListeners();
    }
  }
}
