import 'package:flutter/material.dart';
import 'atlas_controls.dart';
import 'tertiary_data.dart';

class PreferenceControls extends StatefulWidget {
  final TertiaryStore store;
  final VoidCallback onChanged;
  const PreferenceControls({
    super.key,
    required this.store,
    required this.onChanged,
  });
  @override
  State<PreferenceControls> createState() => _PreferenceControlsState();
}

class _PreferenceControlsState extends State<PreferenceControls> {
  late final TextEditingController budget;
  String? budgetError;
  @override
  void initState() {
    super.initState();
    budget = TextEditingController(
      text: widget.store.preferences.annualTuitionGhs?.toStringAsFixed(0) ?? '',
    );
  }

  @override
  void dispose() {
    budget.dispose();
    super.dispose();
  }

  void update(PathwayPreferences next) {
    widget.store.preferences = next;
    widget.onChanged();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.store.preferences;
    return AtlasDisclosure(
      tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      title: const Text('Personalise your suggestions'),
      subtitle: const Text(
        'Interests, preferred regions, qualification, study mode and tuition budget',
      ),
      children: [
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Preferences help order suitable routes. They cannot override academic requirements or predict admission.',
          ),
        ),
        const SizedBox(height: 12),
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'What would you like to study?',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final interest in pathwayInterests.keys)
              FilterChip(
                label: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.sizeOf(context).width - 160,
                  ),
                  child: Text(interest),
                ),
                selected: p.interests.contains(interest),
                onSelected: (selected) {
                  final next = {...p.interests};
                  selected ? next.add(interest) : next.remove(interest);
                  update(p.copyWith(interests: next));
                },
              ),
          ],
        ),
        const SizedBox(height: 12),
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Preferred regions · optional',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final region in pathwayRegions)
              FilterChip(
                label: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.sizeOf(context).width - 160,
                  ),
                  child: Text(region),
                ),
                selected: p.regions.contains(region),
                onSelected: (selected) {
                  final next = {...p.regions};
                  selected ? next.add(region) : next.remove(region);
                  update(p.copyWith(regions: next));
                },
              ),
          ],
        ),
        const SizedBox(height: 16),
        AtlasDropdown<String>(
          key: ValueKey('level-${p.level}'),
          initialValue: p.level,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'Preferred qualification',
          ),
          items: [
            for (final v in ['Any', 'Degree', 'Diploma'])
              DropdownMenuItem(value: v, child: Text(v)),
          ],
          onChanged: (v) => update(p.copyWith(level: v)),
        ),
        const SizedBox(height: 12),
        AtlasDropdown<String>(
          key: ValueKey('mode-${p.mode}'),
          initialValue: p.mode,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Preferred study mode'),
          items: [
            for (final v in ['Any', 'Regular', 'Distance'])
              DropdownMenuItem(value: v, child: Text(v)),
          ],
          onChanged: (v) => update(p.copyWith(mode: v)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: budget,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Annual tuition limit (GHS) · optional',
            errorText: budgetError,
            helperText:
                'Unknown fees stay unknown. Application fees, other currencies and term fees are not compared as annual tuition.',
            helperMaxLines: 4,
          ),
          onChanged: (text) {
            final n = double.tryParse(text);
            if (text.trim().isNotEmpty && (n == null || !n.isFinite || n < 0)) {
              setState(() => budgetError = 'Enter a non-negative GHS amount.');
              return;
            }
            budgetError = null;
            update(
              p.copyWith(annualTuitionGhs: n, clearBudget: text.trim().isEmpty),
            );
          },
        ),
        const SizedBox(height: 12),
        const Text(
          'Preferences are used on this device. Saving them does not save your grades or send a student profile to the server.',
          style: TextStyle(fontSize: 12),
        ),
        if (widget.store.preferencesStorageError != null)
          Text(widget.store.preferencesStorageError!),
        Wrap(
          spacing: 12,
          children: [
            TextButton.icon(
              onPressed: budgetError != null
                  ? null
                  : () async {
                      try {
                        await widget.store.savePathwayPreferences();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Preferences saved on this device.',
                              ),
                            ),
                          );
                        }
                      } catch (_) {
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Preferences could not be saved. Existing device data has been preserved.',
                              ),
                            ),
                          );
                        }
                      }
                    },
              icon: const Icon(Icons.save_outlined),
              label: const Text('Save preferences on this device'),
            ),
            TextButton(
              onPressed: () {
                budget.clear();
                budgetError = null;
                update(const PathwayPreferences());
              },
              child: const Text('Reset choices'),
            ),
          ],
        ),
      ],
    );
  }
}

class SubjectPicker extends StatefulWidget {
  final List<String> subjects;
  const SubjectPicker({super.key, required this.subjects});
  @override
  State<SubjectPicker> createState() => _SubjectPickerState();
}

class _SubjectPickerState extends State<SubjectPicker> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final choices = widget.subjects
        .where((s) => subjectMatchesSearch(s, query))
        .toList();
    return Dialog(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 480,
          maxHeight: MediaQuery.sizeOf(context).height * .72,
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Choose an elective',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              TextField(
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'Search subject or WAEC name',
                ),
                onChanged: (v) => setState(() => query = v),
              ),
              const SizedBox(height: 8),
              Flexible(
                child: choices.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No matching subject. Try another spelling.',
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: choices.length,
                        itemBuilder: (context, index) => ListTile(
                          title: Text(subjectDisplayName(choices[index])),
                          onTap: () => Navigator.pop(context, choices[index]),
                        ),
                      ),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EvidenceReviewPanel extends StatelessWidget {
  final TertiaryStore store;
  final ValueChanged<String> openSource;
  const EvidenceReviewPanel({
    super.key,
    required this.store,
    required this.openSource,
  });
  @override
  Widget build(BuildContext context) {
    final queue = admissionReviewQueue(store);
    return AtlasDisclosure(
      tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      title: const Text('Admissions evidence under review'),
      leading: const Icon(Icons.verified_outlined),
      subtitle: Text('${queue.length} source groups need confirmation'),
      children: [
        const Text(
          'Changed, unavailable, old or ambiguous evidence stays paused. A new admission year is not guessed from today’s date. Reviewed requirements must be published before affected checks resume.',
        ),
        for (final item in queue)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              '${(item['titles'] as List).length} ${(item['kind'] == 'cutoff') ? 'cutoff entries' : 'academic/source checks'}',
            ),
            subtitle: Text(
              '${item['reason']}\n${(item['titles'] as List).take(3).join('; ')}${(item['titles'] as List).length > 3 ? ' …' : ''}',
            ),
            trailing: const Icon(Icons.open_in_new, size: 18),
            onTap: () => openSource(item['sourceUrl'] as String),
          ),
        if (queue.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'No held evidence is reported in this snapshot. Each rule still has its own source date and admission-cycle limits.',
            ),
          ),
      ],
    );
  }
}
