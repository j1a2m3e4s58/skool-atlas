part of 'main.dart';

class OfficialProgrammeReview extends StatelessWidget {
  final School school;
  const OfficialProgrammeReview({super.key, required this.school});
  @override
  Widget build(BuildContext context) {
    final review = school.data['publicProgrammeReview'] as Map?;
    final tvet = school.data['officialTvetReview'] as Map?;
    if (tvet != null) {
      final courses = (tvet['programs'] as List? ?? [])
          .map((p) => '${p['name']} (${p['code']})')
          .join(', ');
      return Surface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Official TVET directory check',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: context.atlas.primaryDark,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Checked ${tvet['observed']} · institution code ${tvet['code']}',
            ),
            if (courses.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text('Listed courses: $courses.'),
            ],
            const SizedBox(height: 10),
            Text(
              'Public institution portal linked by Ghana TVET Service. Confirm current intake and subject combinations before submitting your choices.',
              style: TextStyle(color: context.atlas.muted),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () =>
                  openLink(context, Uri.parse('https://gtvets.info/')),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Open official institution portal'),
            ),
          ],
        ),
      );
    }
    if (review == null) return const SizedBox.shrink();
    final listed = (review['listedProgrammes'] as List).join(', ');
    final additional = (review['catalogueOnly'] as List).join(', ');
    return Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Official programme-source check',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: context.atlas.primaryDark,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'CSSPS public vacancy directory · checked ${review['observed']}',
            style: TextStyle(color: context.atlas.muted),
          ),
          const SizedBox(height: 10),
          Text('Programmes shown in that snapshot: $listed.'),
          if (additional.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              'Also listed in our selection-register data, but not in that vacancy snapshot: $additional. Confirm the current offering with the school; absence from a vacancy list does not mean a programme has stopped.',
            ),
          ],
          const SizedBox(height: 10),
          Text(
            'The source does not publish selection codes. The displayed code still needs confirmation on your current official form. Vacancy information can change and is not an admission offer.',
            style: TextStyle(color: context.atlas.muted),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () =>
                openLink(context, Uri.parse('${review['source']}')),
            icon: const Icon(Icons.open_in_new),
            label: const Text('Check current official listings'),
          ),
        ],
      ),
    );
  }
}

class SchoolInformationStatus extends StatelessWidget {
  final School school;
  const SchoolInformationStatus({super.key, required this.school});
  @override
  Widget build(BuildContext context) {
    final records =
        ((supportData['schools'] as Map?)?[school.id] as List? ?? [])
            .whereType<Map>();
    final linkedPhotos = websiteContent.items(school.id, 'photos');
    final approvedPhotos = (publishedUpdates.media[school.id] ?? []).where(
      (m) => m['kind'] == 'photo',
    );
    final items = <({String title, String detail, bool pending})>[
      (
        title: 'School identity',
        detail: school.identityNeedsReview
            ? 'Needs review: a similar listing exists. Confirm the exact campus.'
            : school.data['legacyIds'] != null
            ? 'Duplicate name reconciled; previous saved links are preserved.'
            : 'Directory identity; confirm the campus before official selection.',
        pending: school.identityNeedsReview,
      ),
      (
        title: 'School code',
        detail: school.data['registerCodeConflict'] == true
            ? 'Needs confirmation: ${school.data['code'] ?? 'Not listed'} conflicts with another register entry.'
            : school.data['code'] == null
            ? 'Not yet verified'
            : '${school.data['code']} · sourced listing, not an admission guarantee.',
        pending:
            school.data['code'] == null ||
            school.data['registerCodeConflict'] == true,
      ),
      (
        title: 'Programmes',
        detail: school.programs.isEmpty
            ? 'Not yet verified'
            : school.data['officialTvetReview']?['programs'] != null
            ? 'Official TVET course directory checked ${school.data['officialTvetReview']['observed']}. Confirm current intake.'
            : school.data['programsObserved'] != null
            ? 'Administrator-reviewed source observed ${school.data['programsObserved']}. Confirm the current intake.'
            : school.data['registerYear'] != null
            ? 'Listed in the ${school.data['registerYear']} register, page ${school.data['registerPage']}. Confirm current subject combinations.'
            : 'Archive listing; current programmes are not yet verified.',
        pending:
            school.programs.isEmpty ||
            school.data['registerYear'] == null &&
                school.data['programsObserved'] == null,
      ),
      (
        title: 'Photos',
        detail: school.images.isNotEmpty
            ? '${school.images.length} local photos; check source dates below.'
            : linkedPhotos.isNotEmpty || approvedPhotos.isNotEmpty
            ? 'Linked school photos; internet required.'
            : 'Not yet verified',
        pending:
            school.images.isEmpty &&
            linkedPhotos.isEmpty &&
            approvedPhotos.isEmpty,
      ),
      (
        title: 'Crest',
        detail: school.hasCrest
            ? '${school.data['crestNote'] ?? 'Crest available; see school sources.'}'
            : 'Not yet verified · initials are a placeholder',
        pending: !school.hasCrest,
      ),
      for (final kind in ['Contact', 'Fees', 'Scholarship', 'Prospectus'])
        (
          title: kind == 'Contact' ? 'Office contact' : kind,
          detail: records.any((r) => r['kind'] == kind)
              ? 'Dated source available below; check its year and applicability.'
              : 'Not yet verified',
          pending: !records.any((r) => r['kind'] == kind),
        ),
      (
        title: 'Achievements',
        detail: school.achievements.isEmpty
            ? 'Not yet verified'
            : '${school.achievements.length} dated records; this is not a complete awards history.',
        pending: school.achievements.isEmpty,
      ),
    ];
    return Surface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Information you can check',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: context.atlas.primaryDark,
            ),
          ),
          const SizedBox(height: 8),
          if (school.data['profileReviewed'] != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                'Profile sources reviewed ${school.data['profileReviewed']}. Individual details may still need school confirmation.',
                style: TextStyle(
                  color: context.atlas.muted,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
            ),
          Text(
            'A missing record does not mean the school has no achievements, scholarships or facilities. Source dates matter.',
            style: TextStyle(color: context.atlas.muted, height: 1.5),
          ),
          const SizedBox(height: 12),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('View source and missing details'),
            subtitle: Text(
              '${items.where((item) => item.pending).length} areas need confirmation',
            ),
            children: [
              for (final item in items)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        item.pending
                            ? Icons.help_outline
                            : Icons.article_outlined,
                        size: 20,
                        color: item.pending
                            ? Colors.deepOrange
                            : AppColors.primary,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              item.detail,
                              style: TextStyle(
                                color: context.atlas.muted,
                                height: 1.45,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          TextButton.icon(
            onPressed: () => openPlanningTool(
              context,
              SchoolPortalPage(initialSchool: school),
              'Suggest a sourced update',
            ),
            icon: const Icon(Icons.edit_note),
            label: const Text('Help improve this profile'),
          ),
        ],
      ),
    );
  }
}
