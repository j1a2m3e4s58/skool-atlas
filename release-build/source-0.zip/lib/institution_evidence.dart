import 'package:flutter/material.dart';
import 'tertiary_data.dart';

/// Readable provenance shared by every institution, including long records.
class InstitutionEvidence extends StatelessWidget {
  final TertiaryInstitution institution;
  final Map<dynamic, dynamic> media;
  final void Function(String) onOpen;
  const InstitutionEvidence({
    super.key,
    required this.institution,
    required this.media,
    required this.onOpen,
  });
  static const ink = Color(0xFF173F3B);
  static const muted = Color(0xFF60736A);

  Widget section(String text) => Padding(
    padding: const EdgeInsets.only(top: 22, bottom: 10),
    child: Text(
      text,
      style: const TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
    ),
  );
  Widget fact(IconData icon, String label, String value) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(icon, size: 20, color: muted),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, color: muted)),
            const SizedBox(height: 5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                height: 1.5,
                color: ink,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    ],
  );
  Widget source(String title, String subtitle, String url) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: OutlinedButton(
      style: OutlinedButton.styleFrom(
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.all(14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: const BorderSide(color: Color(0xFFD6DED6)),
      ),
      onPressed: () => onOpen(url),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: muted,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(Icons.open_in_new, size: 17),
          ),
        ],
      ),
    ),
  );
  @override
  Widget build(BuildContext context) {
    final i = institution;
    final logo = media['logo'] as Map?;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .74),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD6DED6)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Row(
            children: [
              Icon(Icons.fact_check_outlined, color: ink, size: 22),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Source & approval',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                    color: ink,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          LayoutBuilder(
            builder: (context, box) {
              final width = box.maxWidth >= 580
                  ? (box.maxWidth - 24) / 2
                  : box.maxWidth;
              return Wrap(
                spacing: 24,
                runSpacing: 18,
                children: [
                  SizedBox(
                    width: width,
                    child: fact(
                      Icons.verified_outlined,
                      'Institution listing',
                      i.status,
                    ),
                  ),
                  SizedBox(
                    width: width,
                    child: fact(
                      Icons.event_outlined,
                      'Register last checked',
                      i.checkedAt,
                    ),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFEDF1EA),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline, size: 18, color: muted),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'A regulator listing does not confirm every programme or the current admissions intake. Listed programmes use a separate dated snapshot. Confirm the exact programme with the institution.',
                    style: TextStyle(fontSize: 13, height: 1.6, color: ink),
                  ),
                ),
              ],
            ),
          ),
          section('Regulator evidence'),
          if (i.recordIds.length > 1)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                '${i.recordIds.length} register records are combined in this profile. Each original record remains available below.',
                style: const TextStyle(fontSize: 13, height: 1.5, color: muted),
              ),
            ),
          for (final record in i.records)
            source(
              '${record['name']}',
              '${record['id'].toString().split(':').first.toUpperCase()} · record ${record['id'].toString().split(':').last}',
              record['source'] as String,
            ),
          if (i.records.isEmpty)
            source(
              'Official institution record',
              'Open the regulator register',
              i.source,
            ),
          if (logo != null || media['asset'] is String) ...[
            section('Media provenance'),
            if (logo?['pageUrl'] is String)
              source(
                'Institution logo',
                'View the official source',
                logo!['pageUrl'] as String,
              ),
            if (media['asset'] is String)
              source(
                'Profile photograph',
                '${media['caption'] ?? 'Institution photograph'}',
                (media['pageUrl'] ?? media['sourceUrl']) as String,
              ),
            if (media['credit'] is String)
              Text(
                'Photo: ${media['credit']} · ${media['license'] ?? ''}',
                style: const TextStyle(fontSize: 12, height: 1.5, color: muted),
              ),
            if (media['licenseUrl'] is String)
              source(
                'Photograph licence',
                'Read the attribution and licence terms',
                media['licenseUrl'] as String,
              ),
            const Text(
              'Individual gallery photographs include their own source and caption above.',
              style: TextStyle(fontSize: 12, height: 1.5, color: muted),
            ),
          ],
        ],
      ),
    );
  }
}
