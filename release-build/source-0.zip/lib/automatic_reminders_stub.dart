Future<String> automaticReminderStatus() async =>
    'Automatic device reminders are available in the hosted web app on supported browsers. This build can export calendar reminders.';
Future<String> enableAutomaticReminders(String dates) =>
    automaticReminderStatus();
Future<String> syncAutomaticReminders(String dates) async => '';
Future<String> disableAutomaticReminders() => automaticReminderStatus();
