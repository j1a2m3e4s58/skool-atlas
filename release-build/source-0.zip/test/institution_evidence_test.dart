import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/institution_evidence.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  const institution = TertiaryInstitution(
    id: 'gtec:123',
    name: 'Long institution name for layout verification',
    category: 'Universities & colleges',
    location: 'Accra',
    source: 'https://gtec.edu.gh/explore-institutions/',
    checkedAt: '2026-10-25',
    status:
        'Course approvals vary; check the official register for the exact programme',
    courses: [],
    listedActive: true,
    recordIds: ['gtec:123', 'nmc:123'],
    records: [
      {
        'id': 'gtec:123',
        'name':
            'A university with a long official institution name and multiple regional campuses',
        'source': 'https://gtec.edu.gh/explore-institutions/',
      },
      {
        'id': 'nmc:123',
        'name':
            'The same institution listed under its nursing and midwifery training name',
        'source': 'https://nmc.gov.gh/web/find-accredited-institutions',
      },
    ],
  );
  testWidgets(
    'Long source records wrap without overflow at phone, tablet and desktop widths',
    (tester) async {
      addTearDown(() => tester.view.resetPhysicalSize());
      addTearDown(() => tester.view.resetDevicePixelRatio());
      tester.view.devicePixelRatio = 1;
      for (final width in [320.0, 768.0, 1280.0]) {
        tester.view.physicalSize = Size(width, 900);
        await tester.pumpWidget(
          MaterialApp(
            home: MediaQuery(
              data: MediaQueryData(
                size: Size(width, 900),
                textScaler: TextScaler.linear(1.35),
              ),
              child: Scaffold(
                body: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: InstitutionEvidence(
                      institution: institution,
                      media: const {},
                      onOpen: (_) {},
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
        await tester.pump();
        expect(
          tester.takeException(),
          isNull,
          reason: 'Overflow at width $width',
        );
        expect(find.text('Source & approval'), findsOneWidget);
        expect(
          find.textContaining('A regulator listing does not confirm'),
          findsOneWidget,
        );
      }
    },
  );
  testWidgets('Evidence row opens its own regulator source', (tester) async {
    String? opened;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: InstitutionEvidence(
              institution: institution,
              media: const {},
              onOpen: (url) => opened = url,
            ),
          ),
        ),
      ),
    );
    final record = find.text(
      'A university with a long official institution name and multiple regional campuses',
    );
    await tester.ensureVisible(record);
    await tester.tap(record);
    expect(opened, 'https://gtec.edu.gh/explore-institutions/');
  });
}
