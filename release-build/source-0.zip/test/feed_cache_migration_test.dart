import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'a verified online refresh retires only obsolete feed caches and preserves student choices',
    () async {
      SharedPreferences.setMockInitialValues({
        'tertiary.feed.v8': 'old reproducible feed',
        'tertiary.feed.v9': 'previous large reproducible feed',
        'tertiary.saved.v1': ['gtec:875'],
        'tertiary.pathway.preferences.v1': 'retain student preferences',
        'tertiary.journey.applications.v1': 'retain applications',
      });
      final store = TertiaryStore()
        ..feedUrl = 'https://atlas.test/tertiary-feed.json';
      final body = File('web/tertiary-feed.json').readAsStringSync();
      await http.runWithClient(
        () => store.refresh(),
        () => MockClient(
          (_) async => http.Response(
            body,
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          ),
        ),
      );
      expect(store.rules.length, 600);
      expect(store.syncMessage, startsWith('Admissions feed updated'));
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.containsKey('tertiary.feed.v8'), isFalse);
      expect(prefs.containsKey('tertiary.feed.v9'), isFalse);
      expect(
        jsonDecode(prefs.getString('tertiary.feed.v10')!)['rules'],
        hasLength(600),
      );
      expect(prefs.getStringList('tertiary.saved.v1'), ['gtec:875']);
      expect(
        prefs.getString('tertiary.pathway.preferences.v1'),
        'retain student preferences',
      );
      expect(
        prefs.getString('tertiary.journey.applications.v1'),
        'retain applications',
      );
    },
  );
}
