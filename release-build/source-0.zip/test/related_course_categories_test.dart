import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  AdmissionRule rule(String id, String name) => AdmissionRule({
    'id': id,
    'programme': name,
    'institutionId': id,
    'scope': 'programme',
    'studyMode': 'Regular',
  });
  PathwayRecommendation candidate(AdmissionRule r, {bool passes = true}) =>
      PathwayRecommendation(r, MatchAssessment('Test assessment', [], 21,
          academicPass: passes), 0, [], []);

  test('BEd Dagbani alternatives require education relevance and passing grades', () {
    final target = rule('target', 'BEd Dagbani');
    final education = rule('education', 'Bachelor of Education');
    final nursing = rule('nursing', 'Certificate in Nurse Assistant Preventive');
    final failed = rule('failed', 'B.Ed French');
    expect(programmeInterests(target), contains('Education'));
    expect(alternativeProgrammes(target, [
      candidate(nursing), candidate(failed, passes: false), candidate(education),
    ]).map((r) => r.rule.id), ['education']);
  });

  test('Unclassified programmes do not treat every passing course as related', () {
    expect(alternativeProgrammes(rule('unknown', 'Unclassified route'), [
      candidate(rule('nursing', 'BSc Nursing')),
    ]), isEmpty);
  });

  test('Education abbreviation requires word boundaries', () {
    for (final name in ['BEd Dagbani', 'B.Ed. French', 'B.Ed Arabic']) {
      expect(programmeInterests(rule(name, name)), contains('Education'));
    }
    expect(programmeInterests(rule('other', 'Embedded Systems')),
        isNot(contains('Education')));
  });
}
