import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  final now = DateTime(2026, 10, 27, 12);
  final raw =
      jsonDecode(
            File('assets/tertiary/admissions.json').readAsStringSync(),
          )['rules']
          as List;
  AdmissionRule rule(String id) => AdmissionRule(
    Map<String, dynamic>.from(raw.singleWhere((r) => r['id'] == id)),
  );
  final grades = {
    'English Language': 2,
    'Core Mathematics': 2,
    'Integrated Science': 2,
    'Social Studies': 2,
    'Elective Mathematics': 4,
    'Physics': 2,
    'Chemistry': 2,
  };
  TertiaryStore store() {
    final s = TertiaryStore()
      ..rules = [
        rule('ug-wassce-23'),
        rule('ug-wassce-18'),
        rule('knust-civil'),
        rule('upsa-diploma-general'),
      ];
    s.institutions =
        (jsonDecode(
                  File('assets/tertiary/catalogue.json').readAsStringSync(),
                )['institutions']
                as List)
            .map(
              (r) => TertiaryInstitution.fromJson(Map<String, dynamic>.from(r)),
            )
            .toList();
    return s;
  }

  test(
    'preferences never promote a failed or general route above an academically matching programme',
    () {
      final ranked = rankPathways(
        store(),
        grades,
        const PathwayPreferences(
          interests: {'Computing & data'},
          regions: {'Greater Accra'},
          mode: 'Regular',
          level: 'Degree',
        ),
        now: now,
      );
      expect(ranked.first.rule.id, 'ug-wassce-18');
      expect(ranked.last.rule.data['scope'], 'institution_general');
      expect(ranked.first.fitReasons.join(' '), contains('Computing & data'));
      expect(
        ranked.first.fitReasons.join(' '),
        contains('Confirm this programme’s teaching campus'),
      );
      expect(
        ranked
            .singleWhere((r) => r.rule.id == 'ug-wassce-23')
            .assessment
            .academicPass,
        isFalse,
      );
    },
  );
  test(
    'preferred regions change order within the same academic tier and ordering is deterministic',
    () {
      final s = store();
      final a = rankPathways(
        s,
        grades,
        const PathwayPreferences(regions: {'Ashanti'}),
        now: now,
      );
      final b = rankPathways(
        s,
        grades,
        const PathwayPreferences(regions: {'Ashanti'}),
        now: now,
      );
      expect(a.first.rule.id, 'knust-civil');
      expect(a.map((r) => r.rule.id), b.map((r) => r.rule.id));
    },
  );
  test(
    'unknown annual tuition is not treated as free or as an affordability match',
    () {
      final a = rankPathways(
        store(),
        grades,
        const PathwayPreferences(annualTuitionGhs: 1000),
        now: now,
        targetCycle: '2026/2027',
      );
      expect(
        a.every(
          (r) => r.tradeoffs.any((t) => t.contains('budget fit is unknown')),
        ),
        isTrue,
      );
      expect(
        a.any((r) => r.fitReasons.any((t) => t.contains('within your GHS'))),
        isFalse,
      );
    },
  );
  test(
    'only verified annual GHS tuition for the selected cycle affects budget fit',
    () {
      final s = store();
      Map<String, dynamic> fee() => {
        'id': 'fictional-test-only',
        'institutionId': 'gtec:876',
        'costType': 'tuition',
        'currency': 'GHS',
        'period': 'Per academic year',
        'cycle': '2026/2027',
        'checkedAt': '2026-10-27',
        'amount': 500,
        'status': 'source_checked',
      };
      PathwayRecommendation ranked() => rankPathways(
        s,
        grades,
        const PathwayPreferences(annualTuitionGhs: 1000),
        now: now,
        targetCycle: '2026/2027',
      ).singleWhere((r) => r.rule.id == 'knust-civil');
      s.journey.resources['fees'] = [fee()];
      expect(ranked().fitReasons.join(' '), contains('within your GHS'));
      for (final patch in [
        {'currency': 'USD'},
        {'period': 'Per term'},
        {'cycle': '2025/2026'},
        {'status': 'needs_source_review'},
        {'costType': 'application'},
        {'checkedAt': '2025-01-01'},
      ]) {
        s.journey.resources['fees'] = [
          {...fee(), ...patch},
        ];
        expect(ranked().tradeoffs.join(' '), contains('budget fit is unknown'));
      }
    },
  );
  test(
    'related alternatives contain only verified matching programme routes, never general minima',
    () {
      final s = store();
      final alternatives = alternativeProgrammes(
        rule('ug-wassce-23'),
        rankPathways(s, grades, const PathwayPreferences(), now: now),
      );
      expect(alternatives.map((r) => r.rule.id), contains('ug-wassce-18'));
      expect(alternatives.every((r) => r.programmeMatch), isTrue);
      expect(
        alternatives.any((r) => r.rule.id == 'upsa-diploma-general'),
        isFalse,
      );
      s.rules = [
        AdmissionRule({
          ...rule('ug-wassce-18').data,
          'status': 'needs_source_review',
        }),
      ];
      expect(
        alternativeProgrammes(
          rule('ug-wassce-23'),
          rankPathways(s, grades, const PathwayPreferences(), now: now),
        ),
        isEmpty,
      );
    },
  );
  test(
    'simulation opens the B3 route without mutating original grades, rules or preferences',
    () {
      final s = store();
      final before = jsonEncode(grades);
      final ruleBefore = jsonEncode(s.rules.map((r) => r.data).toList());
      final result = simulateGrade(
        s,
        grades,
        const PathwayPreferences(),
        'Elective Mathematics',
        3,
        now: now,
      );
      expect(
        result.newlyMatched.map((r) => r.rule.id),
        contains('ug-wassce-23'),
      );
      expect(
        result.newlyMatched.map((r) => r.rule.id),
        isNot(contains('ug-wassce-18')),
      );
      expect(
        result.newlyMatched.every(
          (r) => r.assessment.status.startsWith('Provisional'),
        ),
        isTrue,
      );
      expect(jsonEncode(grades), before);
      expect(jsonEncode(s.rules.map((r) => r.data).toList()), ruleBefore);
      expect(
        () => simulateGrade(
          s,
          grades,
          const PathwayPreferences(),
          'Elective Mathematics',
          5,
          now: now,
        ),
        throwsFormatException,
      );
    },
  );
  test(
    'actionable next steps choose the smallest successful single-subject improvement',
    () {
      final steps = singleSubjectNextSteps(
        rule('ug-wassce-23'),
        grades,
        now: now,
      );
      expect(steps, contains((subject: 'Elective Mathematics', grade: 3)));
      expect(
        singleSubjectNextSteps(
          AdmissionRule({
            ...rule('ug-wassce-23').data,
            'status': 'needs_source_review',
          }),
          grades,
          now: now,
        ),
        isEmpty,
      );
    },
  );
  test(
    'predicted results are provisional and cannot establish a confirmed cutoff match',
    () {
      final result = assessPathway(
        rule('ug-wassce-18'),
        grades,
        now: now,
        resultBasis: 'Predicted results',
      );
      expect(result.status, 'Provisional academic minimum met');
      expect(result.cutoff.status, contains('no confirmed cutoff'));
      expect(
        assessPathway(
          rule('ug-wassce-18'),
          grades,
          now: now,
          resultBasis: 'Unknown',
        ).academicPass,
        isFalse,
      );
    },
  );
  test('awaiting a mandatory core never supplies an assumed credit', () {
    final missing = {...grades}..remove('English Language');
    expect(
      assessPathway(rule('ug-wassce-18'), missing, now: now).status,
      'More results needed',
    );
    expect(
      assessPathway(
        rule('ug-wassce-18'),
        missing,
        now: now,
        resultBasis: 'Predicted results',
      ).academicPass,
      isFalse,
    );
  });
  test('combined sittings require an explicit fresh source-backed policy', () {
    final original = rule('ug-wassce-18');
    expect(
      assessPathway(original, grades, now: now, sittings: 2).academicPass,
      isFalse,
    );
    final policy = {
      'maxSittings': 2,
      'status': 'source_checked',
      'checkedAt': '2026-10-27',
      'sourceUrl': 'https://example.edu.gh/fictional-test-only-sittings',
    };
    expect(
      assessPathway(
        AdmissionRule({...original.data, 'sittingPolicy': policy}),
        grades,
        now: now,
        sittings: 2,
      ).academicPass,
      isTrue,
    );
    for (final patch in [
      {'status': 'needs_source_review'},
      {'checkedAt': '2025-01-01'},
      {'checkedAt': '2027-01-01'},
      {'maxSittings': 1},
    ]) {
      expect(
        assessPathway(
          AdmissionRule({
            ...original.data,
            'sittingPolicy': {...policy, ...patch},
          }),
          grades,
          now: now,
          sittings: 2,
        ).academicPass,
        isFalse,
      );
    }
    expect(
      assessPathway(original, grades, now: now, sittings: 3).academicPass,
      isFalse,
    );
  });
  test(
    'new WAEC arts subjects work for unrestricted routes but do not replace mandatory sciences',
    () {
      final arts = {
        'English Language': 2,
        'Core Mathematics': 2,
        'Integrated Science': 2,
        'Social Studies': 2,
        'Picture Making': 2,
        'Sculpture': 2,
        'Ceramics': 2,
      };
      expect(
        assessRule(rule('ug-early-grade'), arts, now: now).academicPass,
        isTrue,
      );
      expect(
        assessRule(rule('knust-civil'), arts, now: now).academicPass,
        isFalse,
      );
      expect(
        subjectMatchesSearch('Accounting', 'Financial Accounting'),
        isTrue,
      );
      expect(
        subjectMatchesSearch('Agricultural Science', 'General Agriculture'),
        isTrue,
      );
      expect(electiveSubjects, contains('Woodwork'));
      expect(electiveSubjects, contains('Twi (Asante)'));
    },
  );
  test(
    'generic and named language entries cannot count the same subject twice',
    () {
      final duplicate = {...grades, 'Ghanaian Language': 1, 'Twi (Asante)': 1};
      expect(
        assessRule(rule('ug-early-grade'), duplicate, now: now).status,
        'Invalid results',
      );
    },
  );
  test(
    'preference persistence contains no grades and corrupt values are preserved',
    () async {
      SharedPreferences.setMockInitialValues({});
      final s = store()
        ..preferences = const PathwayPreferences(
          interests: {'Computing & data'},
          regions: {'Eastern'},
          annualTuitionGhs: 12000,
        );
      s.sessionGrades.addAll(grades);
      await s.savePathwayPreferences();
      final prefs = await SharedPreferences.getInstance();
      final text = prefs.getString('tertiary.preferences.v1')!;
      expect(text, isNot(contains('English Language')));
      final loaded = store();
      await loaded.loadPathwayPreferences();
      expect(loaded.preferences.regions, {'Eastern'});
      await prefs.setString(
        'tertiary.preferences.v1',
        'broken preference data',
      );
      final broken = store();
      await broken.loadPathwayPreferences();
      expect(broken.preferencesStorageError, isNotNull);
      await expectLater(broken.savePathwayPreferences(), throwsStateError);
      expect(
        prefs.getString('tertiary.preferences.v1'),
        'broken preference data',
      );
    },
  );
  test('preferences reject invalid interests, regions and budget values', () {
    final valid = const PathwayPreferences().toJson();
    for (final patch in [
      {
        'regions': ['Atlantis'],
      },
      {
        'interests': ['Made up'],
      },
      {'annualTuitionGhs': -1},
      {'annualTuitionGhs': double.infinity},
      {'mode': 'Unverified mode'},
    ]) {
      expect(
        () => PathwayPreferences.fromJson({...valid, ...patch}),
        throwsFormatException,
      );
    }
  });
  test(
    'plain-language explanations include alternative groups and grade floors',
    () {
      expect(
        describeRequirements(rule('ug-wassce-19')).join(' '),
        contains('Biology, Chemistry'),
      );
      expect(
        describeRequirements(rule('ug-wassce-23')).join(' '),
        contains('B3 or better'),
      );
      final s = store();
      s.rules.add(rule('ug-wassce-53'));
      expect(
        admissionReviewQueue(s).any((r) => r['kind'] == 'academic'),
        isTrue,
      );
      expect(admissionReviewQueue(s).any((r) => r['kind'] == 'cutoff'), isTrue);
    },
  );
}
