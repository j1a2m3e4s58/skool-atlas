import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  test('Ho and Akim Oda records never make an unverified admission decision', () {
    final feed = jsonDecode(File(Platform.environment['ATLAS_TEST_FEED'] ?? 'web/tertiary-feed.json').readAsStringSync())
        as Map<String, dynamic>;
    final store = TertiaryStore()..applyFeed(feed);
    final rules = store.rules.where(
      (r) => ['college-20261104-ho-nap', 'college-20261104-akim-oda-nap'].contains(r.id),
    );
    expect(rules.map((r) => r.data['campus']).toSet(), {'Ho', 'Akim Oda'});
    expect(rules, hasLength(2));
    for (final rule in rules) {
      validateAdmissionRule(rule);
      expect(rule.data['status'], 'needs_source_review');
      expect(rule.data['maxAggregate'], isNull);
      expect(rule.data['note'], contains('cannot determine academic eligibility'));
      for (final grade in [1, 2, 3, 4, 5, 6, 7, 8, 9]) {
        final assessment = assessPathway(rule, {
          for (final s in ['English Language', 'Core Mathematics', 'Integrated Science',
            'Biology', 'Chemistry', 'Physics']) s: grade,
        }, now: DateTime(2026, 11, 4));
        expect(assessment.academicPass, isFalse);
        expect(assessment.aggregate, isNull);
      }
      final sixE8 = {
        for (final s in ['English Language', 'Core Mathematics', 'Integrated Science',
          'Biology', 'Chemistry', 'Physics']) s: 8,
      };
      expect(sixE8.values.reduce((a,b)=>a+b), 48);
      for (final subject in sixE8.keys) {
        for (final input in [
          {...sixE8, subject:9},
          {...sixE8, subject:7},
          {...sixE8}..remove(subject),
        ]) {
          final result=assessPathway(rule,input,now:DateTime(2026,11,4));
          expect(result.academicPass,isFalse);
          expect(result.aggregate,isNull);
        }
      }
    }
  });
}
