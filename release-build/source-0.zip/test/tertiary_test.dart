import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  final data =
      jsonDecode(File('assets/tertiary/admissions.json').readAsStringSync())
          as Map;
  final rules = (data['rules'] as List)
      .map((r) => AdmissionRule(Map<String, dynamic>.from(r as Map)))
      .toList();
  final date = DateTime(2026, 10, 27, 12);
  final science = {
    'English Language': 2,
    'Core Mathematics': 2,
    'Integrated Science': 2,
    'Social Studies': 2,
    'Elective Mathematics': 2,
    'Physics': 2,
    'Chemistry': 2,
  };
  test('KNUST requires the exact science elective set', () {
    final rule = rules.firstWhere((r) => r.id == 'knust-civil');
    expect(assessRule(rule, science, now: date).aggregate, 12);
    expect(
      assessRule(rule, science, now: date).status,
      'Meets checked academic minimum',
    );
    final missing = {...science}..remove('Physics');
    missing['Government'] = 1;
    expect(assessRule(rule, missing, now: date).status, 'More results needed');
  });
  test(
    'UG checks all four core credits, counts social studies for non-science',
    () {
      final grades = {...science, 'Integrated Science': 7};
      final a = assessRule(rules.first, grades, now: date);
      expect(a.status, 'Requirements not met');
      expect(a.aggregate, 12);
      expect(a.reasons.join(' '), contains('Integrated Science'));
    },
  );
  test('Regular and distance thresholds remain different', () {
    final grades = {for (final s in science.keys) s: 5};
    expect(
      assessRule(rules[0], grades, now: date).status,
      'Requirements not met',
    );
    expect(
      assessRule(rules[1], grades, now: date).status,
      'Meets checked academic minimum',
    );
  });
  test('Absent, failing and stale grades cannot yield a positive match', () {
    expect(
      assessRule(rules.first, {}, now: date).status,
      'More results needed',
    );
    expect(
      assessRule(rules.firstWhere((r) => r.id == 'knust-civil'), {
        ...science,
        'Physics': 9,
      }, now: date).status,
      'Requirements not met',
    );
    expect(
      assessRule(rules.first, science, now: DateTime(2027, 6, 1)).status,
      'Needs source review',
    );
  });
  test('A better optional elective does not displace a mandatory subject', () {
    final result = assessRule(rules.firstWhere((r) => r.id == 'knust-civil'), {
      ...science,
      'Chemistry': 6,
      'Economics': 1,
    }, now: date);
    expect(result.aggregate, 16);
    expect(result.countedSubjects, contains('Chemistry'));
  });
  test('Invalid feed is rejected without replacing previous rules', () {
    final store = TertiaryStore()..rules = rules;
    final invalid = Map<String, dynamic>.from(data);
    invalid['schemaVersion'] = 2;
    invalid['rules'] = [
      {
        ...rules.first.data,
        'aggregateCores': ['English Language', 'Physics', 'Social Studies'],
      },
    ];
    expect(() => store.applyFeed(invalid), throwsFormatException);
    expect(store.rules.length, rules.length);
  });
}
