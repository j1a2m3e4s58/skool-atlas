import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  final feed = jsonDecode(File(Platform.environment['ATLAS_TEST_FEED'] ?? 'web/tertiary-feed.json').readAsStringSync()) as Map<String, dynamic>;
  final store = TertiaryStore()..applyFeed(feed);
  final rule = store.rules.singleWhere((r) => r.id == 'college-20261104-odumase-nap');
  final now = DateTime(2026, 11, 4);
  final grades = {'English Language':8, 'Core Mathematics':8, 'Integrated Science':8,
    'Biology':8, 'Chemistry':8, 'Physics':8};
  test('Odumase published WASSCE boundary: E8 aggregate 48 and 47 pass', () {
    validateAdmissionRule(rule);
    final result = assessPathway(rule, grades, now:now);
    expect(result.academicPass, isTrue);
    expect(result.aggregate, 48);
    expect(result.countedSubjects.length, 6);
    expect(result.cutoff.status, 'No verified programme cutoff');
    final below = assessPathway(rule, {...grades, 'Biology':7}, now:now);
    expect(below.academicPass, isTrue);
    expect(below.aggregate, 47);
  });
  test('F9 and missing subjects fail even when other grades lower the total', () {
    for(final subject in grades.keys) {
      expect(assessPathway(rule, {...grades, subject:9}, now:now).academicPass, isFalse, reason:subject);
      final lowTotal = grades.map((key,value)=>MapEntry(key,1))..[subject]=9;
      expect(assessPathway(rule, lowTotal, now:now).academicPass, isFalse, reason:subject);
      expect(assessPathway(rule, {...grades}..remove(subject), now:now).academicPass, isFalse, reason:subject);
    }
    expect(assessPathway(rule, {...grades, 'Integrated Science':9,'Social Studies':1}, now:now).academicPass,isFalse);
  });
  test('three best passing electives count; unused F9 does not disqualify', () {
    final result = assessPathway(rule, {...grades, 'Biology':9,'Economics':8}, now:now);
    expect(result.academicPass,isTrue);
    expect(result.aggregate,48);
    expect(result.countedSubjects.containsKey('Biology'),isFalse);
    expect(assessPathway(rule, {'English Language':8,'Core Mathematics':8,'Integrated Science':8,
      'Accounting':8,'Business Management':8,'Cost Accounting':8},now:now).academicPass,isTrue);
  });
  test('changed and stale evidence cannot recommend admission', () {
    expect(assessPathway(AdmissionRule({...rule.data,'status':'needs_source_review'}),grades,now:now).academicPass,isFalse);
    expect(assessPathway(rule,grades,now:DateTime(2027,6,1)).academicPass,isFalse);
  });
}
