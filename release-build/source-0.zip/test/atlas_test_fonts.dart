import 'package:flutter/services.dart';

Future<void> loadAtlasTestFonts() async {
  final loader = FontLoader('SkoolSans')
    ..addFont(rootBundle.load('assets/fonts/roboto-regular.ttf'))
    ..addFont(rootBundle.load('assets/fonts/roboto-bold.ttf'));
  await loader.load();
  await (FontLoader(
    'MaterialIcons',
  )..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'))).load();
}
