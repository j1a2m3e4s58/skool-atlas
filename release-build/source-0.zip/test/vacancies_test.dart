import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/vacancies.dart';
import 'package:skoolatlas/planning.dart';
import 'package:skoolatlas/school.dart';

void main() {
  test('zero spaces, wrong residence gender and stale snapshots cannot qualify', () {
    final store = OfficialVacancies();
    final now = DateTime.now().toUtc();
    store.data = {'fetchedAt': now.toIso8601String(), 'schools': {'s': {
      'programmes': [{'name': 'Business', 'vacancies': 3}, {'name': 'General Science', 'vacancies': 0}],
      'residences': [{'name': 'Day', 'gender': null, 'vacancies': 4},
        {'name': 'Boarding', 'gender': 'Male', 'vacancies': 0},
        {'name': 'Boarding', 'gender': 'Female', 'vacancies': 8}],
    }}};
    expect(store.available('s', 'Business', 'Day', 'Male'), isTrue);
    expect(store.available('s', 'Business', 'Boarding', 'Male'), isFalse);
    expect(store.available('s', 'Business', 'Boarding', 'Female'), isTrue);
    expect(store.available('s', 'General Science', 'Day', 'Male'), isFalse);
    expect(store.available('missing', 'Business', 'Day', 'Male'), isFalse);
    expect(store.available('s', 'Business', 'Day', 'Not entered'), isFalse);
    expect(store.describe('s', 'Business', 'Day', 'Male'), contains('Counts are separate'));
    expect(store.freshAt(now.add(const Duration(hours: 3))), isFalse);
    store.error = 'offline';
    expect(store.available('s', 'Business', 'Day', 'Male'), isFalse);
  });
  test('vacancy constraint cannot be bypassed by automatic Boarding fallback', () {
    final previous = schools;
    addTearDown(() => schools = previous);
    schools = [for (var i=0;i<10;i++) School({'id':'s$i','name':'School $i',
      'region':'Central','location':'Cape Coast','gender':'Mixed',
      'category':'Category C','residency':'Day/Boarding','registerYear':2026,
      'programs':['Business'],'images':<String>[],'sources':<Map<String,dynamic>>[]})];
    final draft = buildSuggestedChoices(options: schools, programme:'Business',
      region:'Central',town:'Cape Coast',gender:'Male',
      residenceAllowed:(s,r)=>r=='Day' && s.id=='s0');
    expect(draft.length,1);expect(draft.single.residence,'Day');
    expect(draft.single.schoolId,'s0');
  });
}
