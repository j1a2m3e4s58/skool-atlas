import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_app.dart';
import 'package:skoolatlas/tertiary_data.dart';

class ProfileTestStore extends TertiaryStore {
  @override
  Future<void> refresh() async {}
}

void main() {
  testWidgets(
    'Opening a complete institution panel lays out its programme rows and evidence',
    (tester) async {
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      tester.view.devicePixelRatio = 1;
      final rows =
          jsonDecode(
                File('assets/tertiary/catalogue.json').readAsStringSync(),
              )['institutions']
              as List;
      final ug = Map<String, dynamic>.from(
        rows.firstWhere((r) => r['id'] == 'gtec:881'),
      );
      ug['courses'] = [
        'BSc · Computer Science',
        'BSc · Administration (Procurement, Logistics and Transport Management)',
      ];
      for (final width in [390.0, 1280.0]) {
        tester.view.physicalSize = Size(width, 900);
        final store = ProfileTestStore()
          ..institutions = [TertiaryInstitution.fromJson(ug)];
        await tester.pumpWidget(TertiaryAtlasApp(store: store));
        await tester.pumpAndSettle();
        final hero = find.byTooltip('Explore University of Ghana');
        await tester.ensureVisible(hero);
        await tester.tap(hero);
        await tester.pumpAndSettle();
        expect(
          tester.takeException(),
          isNull,
          reason: 'Profile layout at $width',
        );
        expect(find.text('Source & approval'), findsOneWidget);
        expect(
          find.text(
            'BSc · Administration (Procurement, Logistics and Transport Management)',
          ),
          findsOneWidget,
        );
        final size = tester.getSize(find.text('BSc · Computer Science'));
      expect(size.height.isFinite, isTrue);
        expect(size.height, greaterThan(0));
        await tester.tap(find.byTooltip('Close institution'));
        await tester.pumpAndSettle();
        expect(find.text('Source & approval'), findsNothing);
        await tester.pumpWidget(const SizedBox.shrink());
      }
    },
  );
}
