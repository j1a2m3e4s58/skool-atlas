import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/atlas_controls.dart';

void main() {
  for (final width in [320.0, 390.0, 1280.0]) {
    testWidgets('shared controls wrap and retain selection at $width', (
      tester,
    ) async {
      tester.view.physicalSize = Size(width, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      String? changed;
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: TextScaler.linear(width == 320 ? 1.25 : 1),
              ),
              child: Scaffold(
                body: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        AtlasDropdown<String>(
                          initialValue: 'one',
                          decoration: const InputDecoration(
                            labelText: 'Institution',
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 'one',
                              child: Text('University of Ghana'),
                            ),
                            DropdownMenuItem(
                              value: 'two',
                              child: Text(
                                'Ghana Institute of Management and Public Administration',
                              ),
                            ),
                          ],
                          onChanged: (value) => changed = value,
                        ),
                        const SizedBox(height: 20),
                        const AtlasDisclosure(
                          title: Text('Personalise your suggestions'),
                          subtitle: Text(
                            'Interests, preferred regions, qualification, study mode and tuition budget',
                          ),
                          children: [
                            Text(
                              'Full preference controls remain available here.',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byType(DropdownButtonFormField<String>));
      await tester.pumpAndSettle();
      await tester.tap(
        find
            .text('Ghana Institute of Management and Public Administration')
            .last,
      );
      await tester.pumpAndSettle();
      expect(changed, 'two');
      await tester.tap(find.byType(DropdownButtonFormField<String>));
      await tester.pumpAndSettle();
      final inner = tester.widget<DropdownButtonFormField<String>>(
        find.byType(DropdownButtonFormField<String>),
      );
      expect(inner.initialValue, 'two');
      await tester.tap(find.text('University of Ghana').last);
      await tester.pumpAndSettle();
      await tester.tap(find.text('Personalise your suggestions'));
      await tester.pumpAndSettle();
      expect(
        find.text('Full preference controls remain available here.'),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    });
  }
  testWidgets('disabled fields and form validation retain their behaviour', (
    tester,
  ) async {
    final form = GlobalKey<FormState>();
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Form(
            key: form,
            child: Column(
              children: [
                AtlasDropdown<int>(
                  decoration: const InputDecoration(
                    labelText: 'Choose a grade',
                  ),
                  hint: const Text('Not entered'),
                  items: const [DropdownMenuItem(value: 1, child: Text('A1'))],
                  onChanged: (_) {},
                  validator: (value) =>
                      value == null ? 'Choose your grade' : null,
                ),
                const AtlasDropdown<String>(
                  decoration: InputDecoration(
                    labelText: 'No available choices',
                  ),
                  items: [],
                  onChanged: null,
                ),
              ],
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(form.currentState!.validate(), isFalse);
    await tester.pumpAndSettle();
    expect(find.text('Choose your grade'), findsOneWidget);
    expect(
      tester
          .widget<DropdownButtonFormField<String>>(
            find.byType(DropdownButtonFormField<String>),
          )
          .onChanged,
      isNull,
    );
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}
