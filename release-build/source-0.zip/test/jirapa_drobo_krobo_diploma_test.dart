import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';
void main(){
 final feed=jsonDecode(File(Platform.environment['ATLAS_TEST_FEED']??'web/tertiary-feed.json').readAsStringSync()) as Map<String,dynamic>;
 final store=TertiaryStore()..applyFeed(feed),now=DateTime(2026,11,4);
 final ids=['jirapa-midwifery-rm','jirapa-community-phn','drobo-rgn','drobo-rm','techiman-krobo-rgn','techiman-krobo-phn','techiman-krobo-rm'].map((s)=>'moh-20261104-$s');
 final rules=store.rules.where((r)=>ids.contains(r.id)).toList();
 final cores={'English Language':6,'Core Mathematics':6,'Integrated Science':6};
 final grades={...cores,'Biology':6,'Chemistry':6,'Physics':6};
 test('seven Ministry diploma checks accept C6 aggregate 36 for the named 2026 intake',(){
  expect(rules,hasLength(7));
  for(final r in rules){validateAdmissionRule(r);expect(r.data['maxAggregate'],36);expect(r.data['cycle'],'2026/2027');
   for(final g in [1,6]){final result=assessPathway(r,grades.map((k,v)=>MapEntry(k,g)),now:now);
    expect(result.aggregate,g*6);expect(result.countedSubjects,hasLength(6));expect(result.academicPass,isTrue);
    expect(result.status,'Meets checked academic minimum');
   }
  }
 });
 test('D7 E8 F9 and absent counted subjects do not meet national credits',(){
  for(final r in rules){for(final s in grades.keys){
   for(final g in [7,8,9]){final result=assessPathway(r,{...grades,s:g},now:now);expect(result.academicPass,isFalse);expect(result.status,'Requirements not met');}
   expect(assessPathway(r,{...grades}..remove(s),now:now).academicPass,isFalse);
  }
  }
  for(final r in rules){expect(assessPathway(r,{...grades,'Integrated Science':9,'Social Studies':1},now:now).status,'Requirements not met');}
 });
 test('published elective streams and spare failed electives meet the academic minimum',(){
  for(final r in rules){
   for(final electives in [
    {'Government':6,'History':6,'Economics':6},
    {'French':6,'ICT':6,'Geography':6},
    {'Dagaare':6,'Government':6,'History':6},
    {'Agricultural Science':6,'Biology':6,'ICT':6},
    {'Agricultural Science':6,'Chemistry':6,'Physics':6},
    {'Management in Living':6,'Food and Nutrition':6,'Economics':6},
    {'Biology':9,'Chemistry':6,'Physics':6,'Elective Mathematics':6},
   ]){final result=assessPathway(r,{...cores,...electives},now:now);expect(result.aggregate,36);expect(result.academicPass,isTrue);expect(result.status,'Meets checked academic minimum');}
   final unsupported=assessPathway(r,{...cores,'Accounting':1,'Cost Accounting':1,'Business Management':1},now:now);
   expect(unsupported.status,'More results needed');expect(unsupported.academicPass,isFalse);expect(unsupported.aggregate,isNull);
  }
 });
 test('changed and stale evidence cannot match; all unconfirmed NAP remain held',(){
  for(final r in rules){expect(assessPathway(AdmissionRule({...r.data,'status':'needs_source_review'}),grades,now:now).aggregate,isNull);expect(assessPathway(r,grades,now:DateTime(2027,6,1)).academicPass,isFalse);}
  final pending=store.rules.where((r)=>r.data['status']=='needs_source_review'&&r.programme.contains('Nurse Assistant Preventive'));
  expect(pending,isNotEmpty);for(final r in pending){expect(assessPathway(r,grades,now:now).academicPass,isFalse);}
 });
 test('alternatives cannot be counted as multiple slots; aggregate 37 and missing results fail',(){
  for(final r in rules){
   for(final electives in [
    {'French':1,'Arabic':1,'Government':1},
    {'Christian Religious Studies':1,'Islamic Religious Studies':1,'West Africa Traditional Religion':1},
    {'Dagaare':1,'Dagbani':1,'Government':1},
   ]){expect(assessPathway(r,{...cores,...electives},now:now).academicPass,isFalse);}
   final over=assessPathway(r,{...grades,'English Language':7},now:now);
   expect(over.aggregate,37);expect(over.academicPass,isFalse);
   expect(assessPathway(r,{'English Language':1,'Core Mathematics':1,'Integrated Science':1,'Biology':9,'Chemistry':1,'Physics':1},now:now).academicPass,isFalse);
  }
 });

}
