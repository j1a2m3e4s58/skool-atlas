import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';
void main(){test('Published Ministry diploma replaces the earlier unconfirmed route',(){
 final feed=jsonDecode(File(Platform.environment['ATLAS_TEST_FEED']??'web/tertiary-feed.json').readAsStringSync()) as Map<String,dynamic>;
 final store=TertiaryStore()..applyFeed(feed);final r=store.rules.singleWhere((r)=>r.id=='nmc-indexing-20261104-navrongo-rcn');validateAdmissionRule(r);
 expect(r.data['cycle'],'2026/2027');expect(r.data['maxAggregate'],36);
 final grades={for(final s in ['English Language','Core Mathematics','Integrated Science','Biology','Chemistry','Physics'])s:6};
 final a=assessPathway(r,grades,now:DateTime(2026,11,4));expect(a.academicPass,isTrue);expect(a.aggregate,36);expect(a.status,'Meets checked academic minimum');
 });}
