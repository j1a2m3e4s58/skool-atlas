import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skoolatlas/student_journey.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final resources = Map<String, dynamic>.from(
    jsonDecode(
      File('assets/tertiary/student_resources.json').readAsStringSync(),
    ),
  );
  final rules =
      (jsonDecode(
                File('assets/tertiary/admissions.json').readAsStringSync(),
              )['rules']
              as List)
          .map((r) => AdmissionRule(Map<String, dynamic>.from(r)))
          .toList();
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test(
    'change evidence stores followed institutions only and newly following a school is not a publication alert',
    () async {
      final journey = StudentJourney();
      await journey.load(resources);
      journey.followChanges = true;
      final records = {
        'one': <String, dynamic>{
          'institutionId': 'gtec:875',
          'title': 'One',
          'sourceUrl': 'https://gimpa.edu.gh/',
          'amount': 10,
        },
        'two': <String, dynamic>{
          'institutionId': 'gtec:876',
          'title': 'Two',
          'sourceUrl': 'https://knust.edu.gh/',
          'amount': 20,
        },
      };
      await journey.observe(records, {'gtec:875'});
      expect(journey.baseline.keys, ['one']);
      await journey.observe(records, {'gtec:875', 'gtec:876'});
      expect(journey.updates, isEmpty);
      await journey.observe(
        {
          'one': {...records['one']!, 'amount': 15},
          'two': records['two']!,
        },
        {'gtec:875', 'gtec:876'},
      );
      expect(journey.updates, hasLength(1));
      expect(journey.updates.single['changes'].single['before'], 10);
      await journey.observe(records, {});
      expect(journey.baseline, isEmpty);
    },
  );
  test(
    'Application progress and budgets survive reload without duplicate programmes',
    () async {
      final a = StudentJourney();
      await a.load(resources);
      final p = await a.track('gtec:875', 'Public administration');
      p.stage = 'Submitted';
      p.completed.add(applicationTasks.first);
      p.targetDate = '2026-12-15';
      p.reminder = true;
      p.budget['Tuition'] = 4500;
      p.note = 'Follow up';
      await a.persist();
      final same = await a.track('gtec:875', 'PUBLIC · ADMINISTRATION');
      expect(same.id, p.id);
      expect(a.applications, hasLength(1));
      final b = StudentJourney();
      await b.load(resources);
      expect(b.applications.single.stage, 'Submitted');
      expect(b.applications.single.completed, contains(applicationTasks.first));
      expect(b.applications.single.budgetComplete, false);
      expect(b.applications.single.subtotal, 4500);
      expect(b.applications.single.reminder, true);
    },
  );

  test(
    'Comparison is persistent and capped at four without silently replacing choices',
    () async {
      final a = StudentJourney();
      await a.load(resources);
      for (var n = 0; n < 4; n++) {
        await a.compare('$n');
      }
      await expectLater(a.compare('fifth'), throwsStateError);
      expect(a.comparison, ['0', '1', '2', '3']);
      await a.compare('1');
      await a.compare('fifth');
      final b = StudentJourney();
      await b.load(resources);
      expect(b.comparison, ['0', '2', '3', 'fifth']);
    },
  );

  test(
    'A baseline, unchanged feed and unrelated schools produce no update alerts',
    () async {
      final a = StudentJourney();
      await a.load(resources);
      a.followChanges = true;
      final snapshot = {
        'fee:one': <String, dynamic>{
          'institutionId': 'gtec:875',
          'title': 'Fee',
          'sourceUrl': 'https://gimpa.edu.gh/',
          'amount': 100,
        },
      };
      await a.observe(snapshot, {'gtec:875'});
      await a.observe(snapshot, {'gtec:875'});
      expect(a.updates, isEmpty);
      await a.observe(
        {
          'fee:one': {...snapshot['fee:one']!, 'amount': 200},
        },
        {'gtec:881'},
      );
      expect(a.updates, isEmpty);
    },
  );

  test(
    'A followed fee change records before/after once and persists read state',
    () async {
      final a = StudentJourney();
      await a.load(resources);
      a.followChanges = true;
      final snapshot = {
        'fee:one': <String, dynamic>{
          'institutionId': 'gtec:875',
          'title': 'Fee',
          'sourceUrl': 'https://gimpa.edu.gh/',
          'amount': 100,
        },
      };
      await a.observe(snapshot, {'gtec:875'});
      final updated = {
        'fee:one': {...snapshot['fee:one']!, 'amount': 250},
      };
      await a.observe(updated, {'gtec:875'});
      await a.observe(updated, {'gtec:875'});
      expect(a.updates, hasLength(1));
      expect(a.updates.single['changes'].single['before'], 100);
      expect(a.updates.single['changes'].single['after'], 250);
      a.updates.single['read'] = true;
      await a.persist();
      final b = StudentJourney();
      await b.load(resources);
      expect(b.updates.single['read'], true);
    },
  );

  test('Unknown and past official dates cannot look open', () {
    final now = DateTime(2026, 10, 25, 17);
    expect(deadlineState(null, now: now), 'Date not confirmed');
    expect(deadlineState('2026-04-17', now: now), 'Closed / date passed');
    expect(deadlineState('2026-10-25', now: now), 'Due today');
    expect(deadlineState('2026-10-26', now: now), '1 days remaining');
  });

  test('Calendar export is opt-in, all-day, escaped and UTF-8 line folded', () {
    final p = ApplicationPlan(
      id: '1',
      institutionId: 'gtec:875',
      programme: 'Programme, test; check\nMore',
    );
    expect(() => calendarReminder(p, 'GIMPA'), throwsStateError);
    p.targetDate = '2026-12-15';
    p.reminder = true;
    p.note = 'é' * 150;
    final text = calendarReminder(p, 'GIMPA', now: DateTime.utc(2026, 10, 25));
    expect(text, contains('DTSTART;VALUE=DATE:20261215\r\n'));
    expect(text, contains('DTEND;VALUE=DATE:20261216\r\n'));
    expect(text, contains('TRIGGER:-P1D'));
    expect(text, contains(r'Programme\, test\; check\nMore'));
    for (final line in text.split('\r\n')) {
      expect(utf8.encode(line).length, lessThanOrEqualTo(75));
    }
  });

  test('Corrupt saved progress is retained and never overwritten', () async {
    SharedPreferences.setMockInitialValues({
      StudentJourney.preferenceKey: '{broken',
    });
    final a = StudentJourney();
    await a.load(resources);
    expect(a.storageError, isNotNull);
    await expectLater(a.persist(), throwsStateError);
    expect(
      (await SharedPreferences.getInstance()).getString(
        StudentJourney.preferenceKey,
      ),
      '{broken',
    );
  });

  test(
    'Resource validation rejects negative fees and duplicate identities',
    () {
      final invalid = Map<String, dynamic>.from(
        jsonDecode(jsonEncode(resources)),
      );
      invalid['fees'][0]['amount'] = -1;
      expect(
        () => StudentJourney.validateResources(invalid),
        throwsFormatException,
      );
      final duplicate = Map<String, dynamic>.from(
        jsonDecode(jsonEncode(resources)),
      );
      duplicate['fees'].add(duplicate['fees'][0]);
      expect(
        () => StudentJourney.validateResources(duplicate),
        throwsFormatException,
      );
    },
  );

  test(
    'UPSA allows science OR social studies and keeps required electives',
    () {
      final rule = rules.firstWhere((r) => r.id == 'upsa-business-economics');
      final grades = {
        'English Language': 2,
        'Core Mathematics': 2,
        'Integrated Science': 9,
        'Social Studies': 3,
        'Economics': 4,
        'Elective Mathematics': 4,
        'Government': 2,
      };
      final result = assessRule(rule, grades, now: DateTime(2026, 10, 27, 12));
      expect(result.status, 'Meets checked academic minimum');
      expect(result.aggregate, 17);
      grades.remove('Economics');
      expect(
        assessRule(rule, grades, now: DateTime(2026, 10, 27, 12)).status,
        'More results needed',
      );
    },
  );

  test('Changed rule disables matching and does not promise admission', () {
    final rule = AdmissionRule({
      ...rules.last.data,
      'status': 'needs_source_review',
    });
    expect(
      assessRule(rule, {}, now: DateTime(2026, 10, 27, 12)).status,
      'Needs source review',
    );
  });
  test(
    'New and removed followed records are reported without inferring revoked approval',
    () async {
      final a = StudentJourney();
      await a.load(resources);
      a.followChanges = true;
      final first = {
        'record:1': <String, dynamic>{
          'institutionId': 'gtec:875',
          'title': 'Programme one',
          'sourceUrl': 'https://gimpa.edu.gh/',
          'status': 'listed',
        },
      };
      await a.observe(first, {'gtec:875'});
      await a.observe(
        {
          'record:2': <String, dynamic>{
            'institutionId': 'gtec:875',
            'title': 'Programme two',
            'sourceUrl': 'https://gimpa.edu.gh/',
            'status': 'listed',
          },
        },
        {'gtec:875'},
      );
      expect(a.updates, hasLength(2));
      expect(
        a.updates.any(
          (u) => u['changes'].first['field'] == 'New published record',
        ),
        true,
      );
      expect(
        a.updates.any(
          (u) => '${u['changes'].first['after']}'.contains(
            'not a revocation decision',
          ),
        ),
        true,
      );
    },
  );
  test(
    'Invalid student resources reject the entire feed before replacing rules',
    () {
      final feed = Map<String, dynamic>.from(
        jsonDecode(File('web/tertiary-feed.json').readAsStringSync()),
      );
      final store = TertiaryStore();
      store.applyFeed(feed);
      final old = store.rules;
      final invalid = Map<String, dynamic>.from(jsonDecode(jsonEncode(feed)));
      invalid['studentResources']['fees'][0]['institutionId'] = 'gtec:unknown';
      expect(() => store.applyFeed(invalid), throwsFormatException);
      expect(identical(store.rules, old), true);
    },
  );
}
