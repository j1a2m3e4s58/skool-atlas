import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
 final feed=jsonDecode(File(Platform.environment['ATLAS_TEST_FEED']??'web/tertiary-feed.json').readAsStringSync()) as Map<String,dynamic>;
 final store=TertiaryStore()..applyFeed(feed);
 final rule=store.rules.singleWhere((r)=>r.id=='college-20261104-winneba-nap');
 final now=DateTime(2026,11,4);
 final grades={'English Language':7,'Core Mathematics':4,'Integrated Science':4,'Biology':3,'Chemistry':3,'Physics':3};
 test('Winneba D7 and aggregate 24 pass, 25 fails',(){
  validateAdmissionRule(rule);
  final result=assessPathway(rule,grades,now:now);
  expect(result.academicPass,isTrue);expect(result.aggregate,24);
  expect(assessPathway(rule,{...grades,'Biology':4},now:now).academicPass,isFalse);
  expect(result.cutoff.status,'No verified programme cutoff');
 });
 test('E8, F9 and missing counted subjects fail even below aggregate 24',(){
  for(final subject in grades.keys){
   for(final grade in [8,9]){
    final sample=grades.map((k,v)=>MapEntry(k,1))..[subject]=grade;
    expect(assessPathway(rule,sample,now:now).academicPass,isFalse,reason:'$subject $grade');
   }
   expect(assessPathway(rule,{...grades}..remove(subject),now:now).academicPass,isFalse);
  }
  expect(assessPathway(rule,grades.map((k,v)=>MapEntry(k,8)),now:now).academicPass,isFalse);
  expect(assessPathway(rule,{...grades,'Integrated Science':9,'Social Studies':1},now:now).academicPass,isFalse);
 });
 test('stream requirements and alternatives are respected',(){
  final cores={'English Language':3,'Core Mathematics':3,'Integrated Science':3};
  bool passes(Map<String,int> electives)=>assessPathway(rule,{...cores,...electives},now:now).academicPass;
  expect(passes({'Agricultural Science':4,'Biology':4,'Chemistry':7}),isTrue);
  expect(passes({'Agricultural Science':4,'Biology':4,'Physics':7}),isTrue);
  expect(passes({'Agricultural Science':4,'Biology':4,'Elective Mathematics':4}),isFalse);
  expect(passes({'Food and Nutrition':7,'Management in Living':4,'Economics':4}),isTrue);
  expect(passes({'Management in Living':4,'Economics':4,'General Knowledge in Art':4}),isFalse);
  expect(passes({'Government':7,'History':4,'Economics':4}),isTrue);
  expect(passes({'Accounting':1,'Business Management':1,'Cost Accounting':1}),isFalse);
  expect(passes({'Biology':9,'Chemistry':4,'Physics':4,'Elective Mathematics':7}),isTrue);
 });
 test('changed or stale Winneba evidence and pending colleges never pass',(){
  expect(assessPathway(AdmissionRule({...rule.data,'status':'needs_source_review'}),grades,now:now).academicPass,isFalse);
  expect(assessPathway(rule,grades,now:DateTime(2027,6,1)).academicPass,isFalse);
  for(final id in ['nmc-indexing-20261104-kpembe-nap']){
   final held=store.rules.singleWhere((r)=>r.id==id);
   expect(held.data['status'],'needs_source_review');
   expect(assessPathway(held,grades,now:now).academicPass,isFalse);
  }
 });
}
