import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  final capture = File('.local-state/production-programme-feed.json');
  test(
    'production programme feed is atomically accepted by the real client',
    () {
      final store = TertiaryStore();
      store.applyFeed(
        Map<String, dynamic>.from(
          jsonDecode(
            File(
              '.local-state/production-programme-feed.json',
            ).readAsStringSync(),
          ),
        ),
      );
      expect(store.rules.length, 242);
    },
    skip: !capture.existsSync() ? 'Capture the official production feed to .local-state/production-programme-feed.json before this live integration check.' : false,
  );
}
