import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  test('all five nursing routes keep indexing separate from admission', () {
    final feed = jsonDecode(File('web/tertiary-feed.json').readAsStringSync())
        as Map<String, dynamic>;
    final store = TertiaryStore()..applyFeed(feed);
    final rules = store.rules.where((r) => r.id.startsWith('nmc-indexing-20261104-')).toList();
    expect(rules, hasLength(5));
    expect(rules.map((r) => r.data['campus']).toSet(), {'Kpembe', 'Damongo', 'Nalerigu'});
    final now = DateTime(2026, 11, 4);
    final grades = {
      'English Language': 1, 'Core Mathematics': 1, 'Integrated Science': 1,
      'Biology': 1, 'Chemistry': 1, 'Physics': 1,
    };
    for (final rule in rules) {
      validateAdmissionRule(rule);
      expect(rule.data['maxAggregate'], isNull);
      expect((rule.data['electiveRoutes'] as List).length, 4);
      final indexing = assessPathway(rule, grades, now: now);
      expect(indexing.aggregate, 6);
      expect(indexing.countedSubjects, hasLength(6));
      for (final input in [
        grades,
        {...grades, 'Chemistry': 7},
        {...grades, 'Integrated Science': 7, 'Social Studies': 1},
        {...grades}..remove('Physics'),
      ]) {
        expect(assessPathway(rule, input, now: now).academicPass, isFalse);
      }
    }
  });
}
