import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  test('UBIDS degree checks arts or business credits and holds other routes', () {
    final feed = jsonDecode(File('web/tertiary-feed.json').readAsStringSync())
        as Map<String, dynamic>;
    final store = TertiaryStore()..applyFeed(feed);
    final rule = store.rules.singleWhere(
      (r) => r.id == 'upper-west-20261104-ubids-governance-migration-security',
    );
    validateAdmissionRule(rule);
    final now = DateTime(2026, 11, 4);
    final cores = {
      'English Language': 6,
      'Core Mathematics': 6,
      'Integrated Science': 6,
    };
    final arts = {'Government': 6, 'History': 6, 'Geography': 6};
    final business = {'Accounting': 6, 'Business Management': 6, 'Economics': 6};
    for (final electives in [arts, business]) {
      final result = assessPathway(rule, {...cores, ...electives}, now: now);
      expect(result.academicPass, isTrue);
      expect(result.aggregate, 36);
    }
    for (final grades in [
      {...cores, ...arts, 'Government': 7},
      {...cores, ...business, 'English Language': 7},
      {...cores, ...arts, 'Integrated Science': 7, 'Social Studies': 1},
      {...cores, 'Physics': 1, 'Chemistry': 1, 'Biology': 1},
      {...cores, 'Accounting': 1, 'History': 1, 'Biology': 1},
      {...cores, 'Government': 1, 'History': 1},
    ]) {
      expect(assessPathway(rule, grades, now: now).academicPass, isFalse);
    }
    final held = AdmissionRule({...rule.data, 'status': 'needs_source_review'});
    expect(assessPathway(held, {...cores, ...arts}, now: now).academicPass, isFalse);
  });
}
