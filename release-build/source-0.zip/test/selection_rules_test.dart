import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/planning.dart';
import 'package:skoolatlas/school.dart';

void main() {
  late List<School> original;
  setUp(() {
    original = schools;
    schools = [
      for (final category in ['Category A', 'Category B', 'Category C'])
        for (var i = 0; i < 8; i++)
          School({
            'id': '$category-$i',
            'name': '$category school $i',
            'category': category,
            'region': 'Central',
            'location': 'Cape Coast',
            'gender': 'Mixed',
            'residency': 'Day/Boarding',
            'registerYear': 2026,
            'code': '$category-$i',
            'programs': ['General Science'],
            'images': <String>[],
            'sources': <Map<String, dynamic>>[],
          }),
    ];
  });
  tearDown(() => schools = original);
  test('WAEC Arabic can count among the best two other subjects', () {
    expect(otherSubjects, contains('Arabic'));
    expect(
      resultsAggregate({
        for (final subject in coreSubjects) subject: 2,
        'Arabic': 1,
        'Computing': 3,
        'French': 8,
      }),
      12,
    );
  });
  for (final grade in [2, 4, 7, 9]) {
    test('grade $grade scenario explains fit without inventing category eligibility', () {
      final grades = {
        for (final subject in coreSubjects) subject: grade,
        'Computing': grade, 'French': grade,
      };
      expect(resultsAggregate(grades), grade * 6);
      final options = resultsSchoolOptions(
        programme: 'General Science', region: 'Central', district: '',
        town: 'Cape Coast', gender: 'Male', grades: grades,
      );
      expect(options, isNotEmpty);
      expect(options.first.reasons.join(' '), contains('Mathematics $grade'));
      expect(options.first.reasons.join(' '), contains('not establish admission eligibility'));
      final draft = buildSuggestedChoices(
        options: options.map((m) => m.school).toList(),
        programme: 'General Science', region: 'Central',
        town: 'Cape Coast', gender: 'Male',
      );
      expect(draft.length, 8);
      expect(draft.map((c) => c.selectionCategory).toList(), [
        'Category A', 'Category A', 'Category B', 'Category B',
        'Category B', 'Category C', 'Category C', 'Category C',
      ]);
      expect(draft.last.residence, 'Day');
      final reasons = choiceFitReasons(draft.last,
        grades: grades, region: 'Central', town: 'Cape Coast');
      expect(reasons.join(' '), contains('catchment eligibility'));
      expect(reasons.join(' ').contains('extra learning support'), grade >= 7);
    });
  }
  test('different subject strengths change study paths without school cut-offs', () {
    final science = {
      'English Language': 4, 'Mathematics': 1, 'Science': 1,
      'Social Studies': 5, 'Ghanaian Language': 5, 'Career Technology': 3,
    };
    final arts = {
      'English Language': 1, 'Mathematics': 6, 'Science': 6,
      'Social Studies': 1, 'Ghanaian Language': 1, 'Career Technology': 6,
    };
    expect(gradeStudyPaths(science).first.programme, 'General Science');
    expect(gradeStudyPaths(arts).first.programme, 'General Arts');
    expect(programmeGradeReasons('General Science', arts).join(' '),
      contains('Other entered subject combinations are stronger'));
    expect(programmeGradeReasons('STEM', science).join(' '), contains('Science 1'));
    expect(programmeGradeReasons('Business', {'Mathematics': 2}).join(' '),
      contains('Not enough relevant subject grades'));
  });
  List<SchoolChoice> generate({String style = 'Balanced categories'}) =>
      buildSuggestedChoices(
        options: schools,
        programme: 'General Science',
        region: 'Central',
        town: 'Cape Coast',
        gender: 'Male',
        style: style,
      );
  List<ChoiceCheck> check(List<SchoolChoice> draft) => validateSchoolChoices(
    draft,
    gender: 'Male',
    town: 'Cape Coast',
    region: 'Central',
    now: DateTime(2026, 10, 16),
  );
  test('balanced draft meets official category and boarding maximums', () {
    expect(
      buildSuggestedChoices(
        options: schools,
        programme: 'General Science',
        region: 'Central',
        town: 'Cape Coast',
        gender: 'Not entered',
      ),
      isEmpty,
    );
    final draft = generate();
    expect(draft.length, 8);
    expect(draft.where((c) => c.selectionCategory == 'Category A').length, 2);
    expect(draft.where((c) => c.selectionCategory == 'Category B').length, 3);
    expect(draft.where((c) => c.selectionCategory == 'Category C').length, 3);
    expect(draft.where((c) => c.residence == 'Boarding').length, 5);
    expect(draft.where((c) => c.residence == 'Day').length, 3);
    expect(draft.map((c) => c.selectionCategory).toList(), [
      'Category A',
      'Category A',
      'Category B',
      'Category B',
      'Category B',
      'Category C',
      'Category C',
      'Category C',
    ]);
    expect(draft.map((c) => c.residence).toList(), [
      'Boarding',
      'Day',
      'Boarding',
      'Boarding',
      'Day',
      'Boarding',
      'Boarding',
      'Day',
    ]);
    expect(check(draft).where((c) => c.error).map((c) => c.code).toSet(), {
      'commute',
      'catchment',
    });
  });
  test('all eight category C and all Day are valid alternatives', () {
    final draft = generate(style: 'Category C focus');
    expect(draft.length, 8);
    expect(draft.every((c) => c.selectionCategory == 'Category C'), isTrue);
    final day = generate(style: 'Day-only draft');
    expect(day.length, 8);
    expect(day.every((c) => c.residence == 'Day'), isTrue);
    for (final choice in day) {
      choice.commuteConfirmed = true;
      choice.catchmentConfirmed = true;
    }
    expect(check(day).where((c) => c.error), isEmpty);
  });
  test('no compulsory A/B quota and Day is not a separate category', () {
    final draft = generate(style: 'Category C focus');
    for (final choice in draft) {
      choice.commuteConfirmed = true;
      choice.catchmentConfirmed = true;
    }
    expect(check(draft).where((c) => c.error), isEmpty);
    draft.firstWhere((c) => c.residence == 'Day').residence = 'Boarding';
    expect(check(draft).any((c) => c.code == 'boarding'), isTrue);
  });
  test('automatic Day choices never use region alone to fill the draft', () {
    for (final school in schools) {
      school.data['location'] = 'Distant town, Central, Ghana';
      school.data['district'] = 'Distant district';
    }
    final partial = generate();
    expect(partial.where((c) => c.residence == 'Day'), isEmpty);
    expect(partial.length, 5);
    expect(check(partial).any((c) => c.code == 'count'), isTrue);
    final local = buildSuggestedChoices(
      options: schools, programme: 'General Science', region: 'Central',
      town: 'Cape Coast', district: 'Distant district', gender: 'Male',
    );
    expect(local.where((c) => c.residence == 'Day').length, 3);
  });
  test(
    'builder skips ambiguous schools and does not invent extra Day choices',
    () {
      schools[0].data['identityNeedsReview'] = true;
      schools[1].data['registerCodeConflict'] = true;
      final draft = generate();
      expect(
        draft.any((c) => [schools[0].id, schools[1].id].contains(c.schoolId)),
        isFalse,
      );
      for (final school in schools) {
        school.data['residency'] = 'Boarding';
      }
      final incomplete = generate();
      expect(incomplete.length, 5);
      expect(check(incomplete).any((c) => c.code == 'count'), isTrue);
    },
  );
}
