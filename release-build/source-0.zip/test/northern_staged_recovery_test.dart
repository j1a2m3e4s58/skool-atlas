import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

// Staged evidence remains unpublished. Synthetic approved copies test arithmetic
// only and must never be written to the catalogue or treated as source approval.
void main() {
  final staged = jsonDecode(File('reports/northern-next-review/staged-requirements.json').readAsStringSync());
  final feed = jsonDecode(File(Platform.environment['ATLAS_TEST_FEED'] ?? 'web/tertiary-feed.json').readAsStringSync()) as Map<String, dynamic>;
  final store = TertiaryStore()..applyFeed(feed);
  final drafts = (staged['walewale']['proposedRules'] as List)
      .map((r) => AdmissionRule(Map<String, dynamic>.from(r))).toList();
  final now = DateTime(2026, 11, 6);
  final grades = {'English Language': 6, 'Core Mathematics': 6,
    'Integrated Science': 6, 'Biology': 6, 'Chemistry': 6, 'Physics': 6};
  AdmissionRule btu(String level) => store.rules.singleWhere(
      (r) => r.id == 'technical-20261028-btu-$level-general');

  test('Walewale held drafts cannot suggest eligibility even with all A1', () {
    expect(drafts, hasLength(2));
    for (final r in drafts) {
      expect(r.data['status'], 'needs_source_review');
      expect(store.rules.any((live) => live.id == r.id), isFalse);
      final result = assessPathway(r, grades.map((k, v) => MapEntry(k, 1)), now: now);
      expect(result.academicPass, isFalse);
      expect(result.aggregate, isNull);
    }
  });
  test('Synthetic Walewale policy accepts C6 aggregate 36 only after approval', () {
    for (final draft in drafts) {
      final r = AdmissionRule({...draft.data, 'status': 'source_checked'});
      final result = assessPathway(r, grades, now: now);
      expect(result.aggregate, 36);
      expect(result.academicPass, isTrue);
      expect(draft.data['status'], 'needs_source_review');
    }
  });
  test('Synthetic Walewale policy rejects grade, aggregate and missing-core boundaries', () {
    for (final draft in drafts) {
      final r = AdmissionRule({...draft.data, 'status': 'source_checked'});
      final over = assessPathway(r, {...grades, 'English Language': 7}, now: now);
      expect(over.aggregate, 37);
      expect(over.academicPass, isFalse);
      for (final grade in [8, 9]) {
        expect(assessPathway(r, {...grades, 'Biology': grade}, now: now).academicPass, isFalse);
      }
      expect(assessPathway(r, {...grades}..remove('Core Mathematics'), now: now).academicPass, isFalse);
      expect(assessPathway(r, {...grades, 'Integrated Science': 9, 'Social Studies': 1}, now: now).academicPass, isFalse);
    }
  });
  test('BTU degree C6 is a general minimum only', () {
    final result = assessPathway(btu('degree'), grades, now: now);
    expect(result.academicPass, isTrue);
    expect(result.status, 'Meets general entry minimum only');
  });
  test('BTU HND D7 core passes but D7 elective and E8 or F9 core fail', () {
    final r = btu('hnd');
    expect(r.data['scope'], 'institution_general');
    expect(assessPathway(r, {...grades, 'English Language': 7}, now: now).academicPass, isTrue);
    expect(assessPathway(r, {...grades, 'Biology': 7}, now: now).academicPass, isFalse);
    for (final grade in [8, 9]) {
      expect(assessPathway(r, {...grades, 'English Language': grade}, now: now).academicPass, isFalse);
    }
  });
  test('DHLTU historical advert has not created an unsupported programme rule', () {
    expect(store.rules.where((r) => r.data['institutionId'] == 'gtec:832'), isEmpty);
  });
  test('Changed-source BTU rules cannot produce a positive suggestion', () {
    for (final level in ['degree', 'hnd']) {
      final held = AdmissionRule({...btu(level).data, 'status': 'needs_source_review'});
      final result = assessPathway(held, grades, now: now);
      expect(result.academicPass, isFalse);
      expect(result.aggregate, isNull);
    }
  });
}
