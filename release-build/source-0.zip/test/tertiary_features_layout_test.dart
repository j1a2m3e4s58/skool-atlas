import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skoolatlas/tertiary_data.dart';
import 'package:skoolatlas/student_hub.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  Map<String, dynamic> read(String name) => Map<String, dynamic>.from(
    jsonDecode(File('assets/tertiary/$name.json').readAsStringSync()),
  );
  for (final width in [390.0, 768.0, 1280.0]) {
    testWidgets('Journey tabs fit at width $width', (tester) async {
      tester.view.physicalSize = Size(width, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({});
      final store = TertiaryStore();
      store.institutions = [
        for (final r in read('catalogue')['institutions'])
          TertiaryInstitution.fromJson(Map<String, dynamic>.from(r)),
      ];
      store.rules = [
        for (final r in read('admissions')['rules'])
          AdmissionRule(Map<String, dynamic>.from(r)),
      ];
      store.media = read('media');
      await store.journey.load(read('student_resources'));
      final a = await store.journey.track('gtec:875', 'Public administration');
      final b = await store.journey.track('gtec:884', 'BSc Business Economics');
      await store.journey.compare(a.id);
      await store.journey.compare(b.id);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: StudentHub(store: store, onGrades: () {}, onProfile: (_) {}),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      for (final tab in [
        'Compare',
        'Costs & scholarships',
        'Galleries',
        'Updates',
        'Applications',
      ]) {
        await tester.ensureVisible(find.widgetWithText(ChoiceChip, tab));
        await tester.tap(find.widgetWithText(ChoiceChip, tab));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull, reason: '$tab at $width');
      }
    });
  }
}
