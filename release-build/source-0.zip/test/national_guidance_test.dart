import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';
import 'package:skoolatlas/student_guidance.dart';
import 'package:skoolatlas/student_journey.dart';
import 'package:skoolatlas/parent_report.dart';
import 'package:shared_preferences/shared_preferences.dart';

Map<String, dynamic> feed() => Map<String, dynamic>.from(
  jsonDecode(File('web/tertiary-feed.json').readAsStringSync()),
);
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  final now = DateTime(2026, 10, 30, 12);
  TertiaryStore store() => TertiaryStore()..applyFeed(feed());
  test(
    'official UENR and UCC requirements enforce named electives and distinct six subjects',
    () {
      final s = store();
      final grades = {
        'English Language': 6,
        'Core Mathematics': 6,
        'Integrated Science': 6,
        'Elective Mathematics': 6,
        'Economics': 6,
        'Geography': 6,
      };
      AdmissionRule r(String suffix) =>
          s.rules.singleWhere((r) => r.id == 'national-20261027-$suffix');
      expect(assessRule(r('uenr-it'), grades, now: now).academicPass, isTrue);
      expect(assessRule(r('uenr-cs'), grades, now: now).academicPass, isFalse);
      expect(
        assessRule(r('uenr-cs'), {
          ...grades,
          'Physics': 6,
        }, now: now).academicPass,
        isTrue,
      );
      expect(assessRule(r('ucc-it'), grades, now: now).aggregate, 36);
      expect(
        assessRule(r('ucc-cs'), {
          ...grades,
          'Physics': 1,
        }, now: now).academicPass,
        isFalse,
      );
      expect(
        assessRule(r('uenr-it'), {
          ...grades,
          'Elective Mathematics': 7,
        }, now: now).academicPass,
        isFalse,
      );
    },
  );
  test(
    'UTAS laboratory science requires chemistry, biology and physics or mathematics',
    () {
      final r = store().rules.singleWhere(
        (r) => r.id == 'national-20261027-utas-mls',
      );
      final g = {
        'English Language': 2,
        'Core Mathematics': 2,
        'Integrated Science': 2,
        'Chemistry': 2,
        'Biology': 2,
        'Elective Mathematics': 2,
      };
      expect(assessRule(r, g, now: now).academicPass, isTrue);
      expect(
        assessRule(r, {...g}..remove('Biology'), now: now).academicPass,
        isFalse,
      );
      expect(
        assessRule(
          r,
          {...g}
            ..remove('Elective Mathematics')
            ..['Physics'] = 3,
          now: now,
        ).academicPass,
        isTrue,
      );
    },
  );
  test(
    'fashion accepts Social Studies alternative without requiring science',
    () {
      final r = store().rules.singleWhere(
        (r) => r.id == 'national-20261027-htu-fashion',
      );
      final g = {
        'English Language': 6,
        'Core Mathematics': 6,
        'Social Studies': 6,
        'Textiles': 6,
        'Graphic Design': 6,
        'French': 6,
      };
      final a = assessRule(r, g, now: now);
      expect(a.academicPass, isTrue);
      expect(a.countedSubjects.length, 6);
      expect(r.matchesProgramme('BTech · Fashion Design and Textiles'), isTrue);
    },
  );
  test(
    'scholarships explain unknown, failed, potential and paused evidence states',
    () {
      final row = Map<String, dynamic>.from(
        (store().guidance['scholarships'] as List).first,
      );
      final yes = {for (final c in row['criteria']) c as String: true};
      expect(scholarshipDecision(row, {}, now), contains('More information'));
      expect(
        scholarshipDecision(row, yes, now),
        contains('Potential policy fit'),
      );
      expect(
        scholarshipDecision(row, {...yes, yes.keys.first: false}, now),
        contains('not met'),
      );
      expect(
        scholarshipDecision(
          {...row, 'status': 'needs_source_review'},
          yes,
          now,
        ),
        startsWith('Paused'),
      );
      expect(
        scholarshipDecision(row, yes, DateTime(2027, 10, 27)),
        startsWith('Paused'),
      );
    },
  );
  test('invalid guidance rejects the entire feed atomically', () {
    final s = store();
    final original = s.rules;
    final old = s.guidance;
    final bad = feed();
    bad['studentGuidance']['campus'][0]['institutionId'] = 'unknown';
    expect(() => s.applyFeed(bad), throwsFormatException);
    expect(identical(s.rules, original), isTrue);
    expect(identical(s.guidance, old), isTrue);
    final duplicate = feed();
    duplicate['studentGuidance']['careers'].add(
      duplicate['studentGuidance']['careers'][0],
    );
    expect(() => s.applyFeed(duplicate), throwsFormatException);
    final phishing = feed();
    phishing['studentGuidance']['campus'][0]['sourceUrl'] =
        'https://university.example.test';
    expect(() => s.applyFeed(phishing), throwsFormatException);
  });
  test(
    'followed guidance records report real changes and ignore timestamp-only refreshes',
    () async {
      final s = store()..saved = {'gtec:881'};
      s.journey.followChanges = true;
      await s.observeJourney();
      expect(s.journey.updates, isEmpty);
      s.guidance['campus'][0]['checkedAt'] = '2026-10-28';
      await s.observeJourney();
      expect(s.journey.updates, isEmpty);
      s.guidance['campus'][0]['status'] = 'needs_source_review';
      await s.observeJourney();
      expect(s.journey.updates.length, 1);
      expect(s.journey.updates.single['title'], 'UG accommodation planning');
    },
  );
  test(
    'PDF creates six application report with private grades excluded by default',
    () async {
      final s = store();
      s.sessionGrades.addAll({'English Language': 2});
      final plans = s.rules
          .where((r) => r.id.startsWith('national-20261027-'))
          .take(6)
          .map(
            (r) => ApplicationPlan(
              id: r.id,
              institutionId: s.ruleInstitutionId(r)!,
              programme: r.programme,
              note: 'PRIVATE_NOTE_MUST_NOT_EXPORT',
            ),
          )
          .toList();
      final bytes = await buildParentReport(s, plans);
      expect(bytes.take(5).toList(), [37, 80, 68, 70, 45]);
      Directory('output/pdf').createSync(recursive: true);
      File(
        'output/pdf/tertiary-parent-report-sample.pdf',
      ).writeAsBytesSync(bytes);
      File(
        'output/pdf/tertiary-parent-report-with-grades.pdf',
      ).writeAsBytesSync(
        await buildParentReport(s, plans, includeGrades: true),
      );
      await expectLater(buildParentReport(s, []), throwsArgumentError);
    },
  );
  for (final width in [320.0, 1280.0]) {
    testWidgets(
      'all four guidance panels render at $width without layout exceptions',
      (tester) async {
        tester.view.physicalSize = Size(width, 900);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        for (final section in [5, 6, 7, 8]) {
          await tester.pumpWidget(
            MaterialApp(
              home: Scaffold(
                body: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: GuidancePanel(
                      key: ValueKey(section),
                      store: store(),
                      section: section,
                    ),
                  ),
                ),
              ),
            ),
          );
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
        }
      },
    );
  }
}
