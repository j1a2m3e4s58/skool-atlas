import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';
void main(){
 final feed=jsonDecode(File(Platform.environment['ATLAS_TEST_FEED']??'web/tertiary-feed.json').readAsStringSync()) as Map<String,dynamic>;
 final store=TertiaryStore()..applyFeed(feed),now=DateTime(2026,11,4);
 final rules=store.rules.where((r)=>['dadiesoaba','kete-krachi'].any((c)=>r.id=='moh-20261104-$c-nac')).toList();
 final grades={'English Language':8,'Core Mathematics':8,'Integrated Science':8,'Biology':8,'Chemistry':8,'Physics':8};
 test('two explicitly listed NAC routes accept E8 aggregate48 and better',(){
  expect(rules,hasLength(2));for(final r in rules){validateAdmissionRule(r);expect(r.data['cycle'],'2026/2027');expect(r.data['maxAggregate'],48);
   for(final g in [1,6,7,8]){final a=assessPathway(r,grades.map((k,v)=>MapEntry(k,g)),now:now);expect(a.aggregate,g*6);expect(a.academicPass,isTrue);expect(a.status,'Meets checked academic minimum');}
   expect(assessPathway(r,{...grades,'English Language':7},now:now).aggregate,47);
  }
 });
 test('F9 counted subjects and missing subjects fail; aggregate49 fails',(){
  for(final r in rules){for(final subject in grades.keys){
   final a=assessPathway(r,{...grades,subject:9},now:now);expect({...grades,subject:9}.values.reduce((a,b)=>a+b),49);expect(a.academicPass,isFalse);
   expect(assessPathway(r,{...grades}..remove(subject),now:now).academicPass,isFalse);
  }
  expect(assessPathway(r,{...grades,'Integrated Science':9,'Social Studies':1},now:now).academicPass,isFalse);
  expect(assessPathway(r,{...grades,'Physics':9,'Elective Mathematics':8},now:now).academicPass,isTrue);
  expect(assessPathway(r,grades.map((k,v)=>MapEntry(k,k=='Biology'?9:1)),now:now).academicPass,isFalse);
  }
 });
 test('published auxiliary electives pass; unsupported business subjects and duplicate alternatives fail',(){
  final core={'English Language':8,'Core Mathematics':8,'Integrated Science':8};
  for(final r in rules){for(final electives in [
   {'Economics':8,'French':8,'ICT':8},
   {'Dagaare':8,'Government':8,'History':8},
   {'Agricultural Science':8,'Biology':8,'ICT':8},
   {'Management in Living':8,'Food and Nutrition':8,'Economics':8},
  ]){expect(assessPathway(r,{...core,...electives},now:now).academicPass,isTrue);}
  for(final electives in [
   {'Accounting':1,'Cost Accounting':1,'Business Management':1},
   {'French':1,'Arabic':1,'Government':1},
   {'Dagaare':1,'Dagbani':1,'Government':1},
   {'Christian Religious Studies':1,'Islamic Religious Studies':1,'West Africa Traditional Religion':1},
  ]){expect(assessPathway(r,{...core,...electives},now:now).academicPass,isFalse);}
  }
 });
 test('changed or stale NAC evidence never matches and unrelated NAP stays pending',(){
  for(final r in rules){expect(assessPathway(AdmissionRule({...r.data,'status':'needs_source_review'}),grades,now:now).academicPass,isFalse);expect(assessPathway(r,grades,now:DateTime(2027,6,1)).academicPass,isFalse);}
  for(final id in ['nmc-indexing-20261104-kpembe-nap']){final r=store.rules.firstWhere((r)=>r.id==id);expect(r.data['status'],'needs_source_review');expect(assessPathway(r,grades,now:now).academicPass,isFalse);}
 });
}
