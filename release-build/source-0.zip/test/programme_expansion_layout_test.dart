import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';
import 'package:skoolatlas/pathway_result_card.dart';
import 'atlas_test_fonts.dart';

void main() {
  for (final width in [320.0, 1280.0]) {
    testWidgets(
      'new programme cards explain location, route floors and conditional evidence at $width',
      (tester) async {
        await loadAtlasTestFonts();
        tester.view.physicalSize = Size(width, 1000);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.reset);
        final store = TertiaryStore()
          ..applyFeed(
            Map<String, dynamic>.from(
              jsonDecode(File('web/tertiary-feed.json').readAsStringSync()),
            ),
          );
        for (final id in [
          'gimpa-computer-science',
          'knust-industrial-engineering',
          'coe-742',
        ]) {
          final rule = store.rules.singleWhere(
            (r) => r.id == 'expanded-20261027-$id',
          );
          final grades = {
            'English Language': 2,
            'Core Mathematics': 2,
            'Integrated Science': 4,
            'Social Studies': 2,
            'Elective Mathematics': 2,
            'Physics': 2,
            'Technical Drawing': 3,
          };
          final a = assessPathway(
            rule,
            grades,
            now: DateTime(2026, 10, 27, 12),
          );
          await tester.pumpWidget(
            MaterialApp(
              theme: ThemeData(fontFamily: 'SkoolSans'),
              builder: (ctx, child) => MediaQuery(
                data: MediaQuery.of(ctx).copyWith(
                  textScaler: TextScaler.linear(width == 320 ? 1.25 : 1),
                ),
                child: child!,
              ),
              home: Scaffold(
                body: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: PathwayResultCard(
                      key: ValueKey(id),
                      recommendation: PathwayRecommendation(rule, a, 0, [], []),
                      confirmed: a.academicPass,
                      awaiting: [],
                      notTaken: [],
                      nextSteps: [],
                      alternatives: [],
                      openSource: (_) {},
                      openAlternative: (_) {},
                    ),
                  ),
                ),
              ),
            ),
          );
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
          expect(find.textContaining('Teaching location:'), findsOneWidget);
          expect(find.text(a.status), findsOneWidget);
          await tester.ensureVisible(
            find.text('What the published rule checks'),
          );
          await tester.tap(find.text('What the published rule checks'));
          await tester.pumpAndSettle();
          if (id == 'knust-industrial-engineering') {
            expect(
              find.textContaining('Integrated Science must be B3'),
              findsOneWidget,
            );
          }
          if (id == 'coe-742') {
            expect(
              find.textContaining('Confirmation required:'),
              findsOneWidget,
            );
          }
          expect(tester.takeException(), isNull);
        }
      },
    );
  }
}
