import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:skoolatlas/tertiary_data.dart';

void main() {
  final candidate = Platform.environment['ATLAS_REVIEW_FEED'];
  test(
    'a proposed source review passes the complete rule and atomic feed validation',
    () {
      final feed = Map<String, dynamic>.from(
        jsonDecode(File(candidate!).readAsStringSync()),
      );
      final store = TertiaryStore()..applyFeed(feed);
      expect(store.rules, isNotEmpty);
      for (final rule in store.rules) {
        validateAdmissionRule(rule);
      }
      expect(
        store.institutions.map((i) => i.id).toSet().length,
        store.institutions.length,
      );
    },
    skip: candidate == null
        ? 'Set ATLAS_REVIEW_FEED to the private draft-feed.json after human source review.'
        : false,
  );
}
