"""Create an app-versioned offline shell after a successful Flutter web build."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WEB=(ROOT/(sys.argv[1] if len(sys.argv)>1 else 'build/tertiary-web')).resolve()
if not WEB.is_relative_to((ROOT/'build').resolve()):raise ValueError('Offline output must remain inside this project build directory')
core=['/atlas-reminders.js','/index.html','/offline-status.html','/flutter_bootstrap.js','/flutter.js','/main.dart.js','/manifest.json','/icons/apple-touch-icon.png','/favicon.png','/assets/AssetManifest.bin',
 '/assets/AssetManifest.bin.json','/assets/FontManifest.json',
 '/assets/assets/branding/launcher-mark.png','/icons/Icon-192.png','/icons/Icon-512.png']
core=[p for p in core if (WEB/p.lstrip('/')).exists()]
for name in ['catalogue','admissions','media','ug_cutoffs','student_resources','student_guidance']:
 core.append('/assets/assets/tertiary/'+name+'.json')
media=['/'+p.relative_to(WEB).as_posix() for p in (WEB/'assets/assets/tertiary/media').rglob('*') if p.is_file()]
for folder in ['assets/fonts','assets/assets/fonts','assets/packages/cupertino_icons']:
 for p in (WEB/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.js','.wasm','.ttf','.otf') and p.stat().st_size<12000000:core.append('/'+p.relative_to(WEB).as_posix())
# The JavaScript build uses CanvasKit. Do not download unused Wasm-build,
# heavy, webparagraph and wimp renderers on every phone's first visit.
for name in ['canvaskit.js','canvaskit.wasm','chromium/canvaskit.js','chromium/canvaskit.wasm']:
 p=WEB/'canvaskit'/name
 if p.exists():core.append('/canvaskit/'+name)
core=sorted(set(core));media=sorted(set(media))
template=(ROOT/'web/sw.template.js').read_text(encoding='utf-8')
hasher=hashlib.sha256(template.encode('utf-8'))
for p in core+media:
 hasher.update(p.encode());hasher.update((WEB/p.lstrip('/')).read_bytes())
version=hasher.hexdigest()[:16]
media_bytes=sum((WEB/p.lstrip('/')).stat().st_size for p in media)
media_hash=hashlib.sha256()
for p in media:
 media_hash.update(p.encode());media_hash.update((WEB/p.lstrip('/')).read_bytes())
(WEB/'sw.js').write_text(template.replace("__ATLAS_VERSION__",version).replace('__ATLAS_CORE__',json.dumps(core)).replace('__ATLAS_MEDIA__',json.dumps(media)).replace('__ATLAS_MEDIA_BYTES__',str(media_bytes)).replace('__ATLAS_MEDIA_VERSION__',media_hash.hexdigest()[:16]),encoding='utf-8')
print(f'Offline shell {version}: {len(core)} essential assets ({sum((WEB/p.lstrip("/")).stat().st_size for p in core)} bytes); {len(media)} optional offline images ({media_bytes} bytes). APIs and external media never cache.')
